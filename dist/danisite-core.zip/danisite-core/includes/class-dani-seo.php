<?php
/**
 * Technical SEO: meta description, canonical, Open Graph, schema and robots.
 * Steps aside automatically when Yoast SEO or Rank Math is active.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * SEO output.
 */
class Dani_Seo {

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'head' ), 2 );
		add_filter( 'wp_robots', array( __CLASS__, 'robots' ) );
		add_filter( 'document_title_separator', array( __CLASS__, 'title_separator' ) );
	}

	/**
	 * Is another SEO plugin handling the meta tags?
	 *
	 * @return bool
	 */
	public static function third_party_active() {
		return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) || defined( 'SEOPRESS_VERSION' );
	}

	/**
	 * Title separator.
	 *
	 * @param string $sep Current separator.
	 * @return string
	 */
	public static function title_separator( $sep ) {
		return '|';
	}

	/**
	 * Meta description for the current view.
	 *
	 * @return string
	 */
	public static function description() {
		if ( is_singular() ) {
			$excerpt = get_the_excerpt();
			if ( $excerpt ) {
				return wp_trim_words( wp_strip_all_tags( $excerpt ), 30, '…' );
			}
			$content = wp_strip_all_tags( get_the_content() );
			if ( $content ) {
				return wp_trim_words( $content, 30, '…' );
			}
		}

		if ( is_category() || is_tag() || is_tax() ) {
			$desc = term_description();
			if ( $desc ) {
				return wp_trim_words( wp_strip_all_tags( $desc ), 30, '…' );
			}
		}

		return dani_option( 'seo_description', get_bloginfo( 'description' ) );
	}

	/**
	 * Open Graph image.
	 *
	 * @return string
	 */
	public static function og_image() {
		if ( is_singular() && has_post_thumbnail() ) {
			$url = get_the_post_thumbnail_url( get_the_ID(), 'dani-wide' );
			if ( $url ) {
				return $url;
			}
		}

		return (string) dani_option( 'seo_og_image', '' );
	}

	/**
	 * Current canonical URL.
	 *
	 * @return string
	 */
	public static function canonical() {
		if ( is_singular() ) {
			return get_permalink();
		}
		if ( is_front_page() ) {
			return home_url( '/' );
		}
		if ( is_home() && get_option( 'page_for_posts' ) ) {
			return get_permalink( get_option( 'page_for_posts' ) );
		}
		if ( is_category() || is_tag() || is_tax() ) {
			$link = get_term_link( get_queried_object() );
			return is_wp_error( $link ) ? '' : $link;
		}
		if ( is_post_type_archive() ) {
			return (string) get_post_type_archive_link( get_post_type() );
		}

		return '';
	}

	/**
	 * Print the head tags.
	 *
	 * @return void
	 */
	public static function head() {
		if ( is_admin() || self::third_party_active() ) {
			return;
		}

		$desc = self::description();
		$url  = self::canonical();

		if ( $desc ) {
			printf( '<meta name="description" content="%s">' . "\n", esc_attr( $desc ) );
		}

		if ( $url && ! is_404() ) {
			printf( '<link rel="canonical" href="%s">' . "\n", esc_url( $url ) );
		}

		$title = wp_get_document_title();
		$image = self::og_image();
		$type  = is_singular( 'post' ) ? 'article' : 'website';

		printf( '<meta property="og:locale" content="fa_IR">' . "\n" );
		printf( '<meta property="og:type" content="%s">' . "\n", esc_attr( $type ) );
		printf( '<meta property="og:title" content="%s">' . "\n", esc_attr( $title ) );
		printf( '<meta property="og:description" content="%s">' . "\n", esc_attr( $desc ) );
		printf( '<meta property="og:site_name" content="%s">' . "\n", esc_attr( get_bloginfo( 'name' ) ) );
		if ( $url ) {
			printf( '<meta property="og:url" content="%s">' . "\n", esc_url( $url ) );
		}
		if ( $image ) {
			printf( '<meta property="og:image" content="%s">' . "\n", esc_url( $image ) );
		}
		printf( '<meta name="twitter:card" content="%s">' . "\n", $image ? 'summary_large_image' : 'summary' );
		printf( '<meta name="twitter:title" content="%s">' . "\n", esc_attr( $title ) );
		printf( '<meta name="twitter:description" content="%s">' . "\n", esc_attr( $desc ) );

		$google = dani_option( 'seo_google', '' );
		if ( $google ) {
			printf( '<meta name="google-site-verification" content="%s">' . "\n", esc_attr( $google ) );
		}

		self::schema( $desc, $url, $image );
	}

	/**
	 * JSON-LD graph.
	 *
	 * @param string $desc  Description.
	 * @param string $url   Canonical URL.
	 * @param string $image Social image.
	 * @return void
	 */
	public static function schema( $desc, $url, $image ) {
		$site = array(
			'@type'       => 'WebSite',
			'@id'         => home_url( '/#website' ),
			'url'         => home_url( '/' ),
			'name'        => get_bloginfo( 'name' ),
			'description' => $desc,
			'inLanguage'  => 'fa-IR',
			'potentialAction' => array(
				'@type'       => 'SearchAction',
				'target'      => array(
					'@type'       => 'EntryPoint',
					'urlTemplate' => home_url( '/?s={search_term_string}' ),
				),
				'query-input' => 'required name=search_term_string',
			),
		);

		$org = array(
			'@type'  => 'Organization',
			'@id'    => home_url( '/#organization' ),
			'name'   => dani_option( 'site_name', get_bloginfo( 'name' ) ),
			'url'    => home_url( '/' ),
			'email'  => dani_option( 'email' ),
			'description' => dani_option( 'brand_desc' ),
		);

		if ( $image ) {
			$org['logo'] = array( '@type' => 'ImageObject', 'url' => $image );
		}

		$graph = array( $org, $site );

		if ( is_singular( 'post' ) ) {
			$graph[] = array(
				'@type'         => 'Article',
				'headline'      => get_the_title(),
				'description'   => $desc,
				'datePublished' => get_the_date( 'c' ),
				'dateModified'  => get_the_modified_date( 'c' ),
				'mainEntityOfPage' => array( '@type' => 'WebPage', '@id' => get_permalink() ),
				'author'        => array( '@type' => 'Person', 'name' => get_the_author() ),
				'publisher'     => array( '@id' => home_url( '/#organization' ) ),
				'image'         => $image ? array( $image ) : array(),
				'inLanguage'    => 'fa-IR',
			);
		}

		if ( is_singular( 'dani_service' ) ) {
			$graph[] = array(
				'@type'       => 'Service',
				'name'        => get_the_title(),
				'description' => $desc,
				'provider'    => array( '@id' => home_url( '/#organization' ) ),
				'areaServed'  => 'IR',
			);
		}

		if ( is_front_page() ) {
			$faqs = Dani_Query::faqs( 6 );
			if ( ! empty( $faqs ) && empty( $faqs[0]['demo'] ) ) {
				$items = array();
				foreach ( $faqs as $faq ) {
					$items[] = array(
						'@type'          => 'Question',
						'name'           => $faq['question'],
						'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $faq['answer'] ),
					);
				}
				$graph[] = array( '@type' => 'FAQPage', 'mainEntity' => $items );
			}
		}

		printf(
			'<script type="application/ld+json">%s</script>' . "\n",
			wp_json_encode(
				array(
					'@context' => 'https://schema.org',
					'@graph'   => $graph,
				),
				JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
			)
		);
	}

	/**
	 * Robots directives for pages that should stay out of the index.
	 *
	 * @param array $robots Robots directives.
	 * @return array
	 */
	public static function robots( $robots ) {
		$noindex = is_search() || is_404() || is_attachment() || is_singular( array( 'dani_faq', 'dani_quote' ) );

		if ( $noindex || ( dani_option( 'seo_index_search' ) && is_search() ) ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
			unset( $robots['index'] );
		}

		return $robots;
	}
}
