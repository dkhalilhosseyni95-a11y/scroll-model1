<?php
/**
 * Structured fields for the DaniSite content types (native meta boxes).
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Meta box field rendering, saving and sanitisation.
 */
class Dani_Fields {

	/**
	 * Cache of the field map.
	 *
	 * @var array|null
	 */
	private static $map = null;

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
	}

	/**
	 * Icon choices shared with the widgets.
	 *
	 * @return array
	 */
	public static function icon_choices() {
		return array(
			'palette'     => 'طراحی و برندینگ',
			'sparkles'    => 'خلاقیت',
			'code'        => 'کدنویسی',
			'layers'      => 'طراحی رابط',
			'bag'         => 'فروشگاه',
			'gauge'       => 'سرعت',
			'shield'      => 'امنیت',
			'trending-up' => 'رشد و سئو',
			'globe'       => 'وب',
			'monitor'     => 'دستگاه',
			'rocket'      => 'راه‌اندازی',
			'message'     => 'پشتیبانی',
			'user'        => 'کاربر',
			'search'      => 'جست‌وجو',
			'sliders'     => 'تنظیمات',
			'star'        => 'کیفیت',
		);
	}

	/**
	 * Field definitions per post type.
	 *
	 * @return array
	 */
	public static function map() {
		if ( null !== self::$map ) {
			return self::$map;
		}

		self::$map = array(
			'dani_service' => array(
				'title'  => 'جزئیات خدمت',
				'fields' => array(
					'icon'     => array( 'type' => 'select', 'label' => 'آیکون', 'options' => self::icon_choices() ),
					'price'    => array( 'type' => 'text', 'label' => 'قیمت یا بازه قیمت', 'help' => 'مثال: از ۲۵ میلیون تومان' ),
					'features' => array( 'type' => 'lines', 'label' => 'ویژگی‌ها', 'help' => 'هر خط یک ویژگی.' ),
					'cta_url'  => array( 'type' => 'url', 'label' => 'لینک دکمه' ),
				),
			),
			'dani_project' => array(
				'title'  => 'مشخصات نمونه‌کار',
				'fields' => array(
					'client'   => array( 'type' => 'text', 'label' => 'نام مشتری' ),
					'year'     => array( 'type' => 'text', 'label' => 'سال اجرا' ),
					'url'      => array( 'type' => 'url', 'label' => 'نشانی وب‌سایت' ),
					'scope'    => array( 'type' => 'text', 'label' => 'خدمات ارائه‌شده', 'help' => 'مثال: طراحی رابط، توسعه وردپرس' ),
					'ratio'    => array(
						'type'    => 'select',
						'label'   => 'نسبت تصویر کارت',
						'options' => array(
							'16-10' => 'افقی (۱۶:۱۰)',
							'4-5'   => 'عمودی (۴:۵)',
							'4-3'   => 'مربع‌تر (۴:۳)',
							'16-9'  => 'پهن (۱۶:۹)',
						),
					),
					'featured' => array( 'type' => 'checkbox', 'label' => 'نمایش در صفحه اصلی' ),
				),
			),
			'dani_team' => array(
				'title'  => 'مشخصات عضو تیم',
				'fields' => array(
					'role'      => array( 'type' => 'text', 'label' => 'سمت' ),
					'instagram' => array( 'type' => 'url', 'label' => 'اینستاگرام' ),
					'linkedin'  => array( 'type' => 'url', 'label' => 'لینکدین' ),
					'x'         => array( 'type' => 'url', 'label' => 'ایکس (توییتر)' ),
				),
			),
			'dani_quote' => array(
				'title'  => 'مشخصات نظر',
				'fields' => array(
					'author'  => array( 'type' => 'text', 'label' => 'نام مشتری' ),
					'role'    => array( 'type' => 'text', 'label' => 'سمت یا شرکت' ),
					'company' => array( 'type' => 'text', 'label' => 'نام پروژه' ),
					'rating'  => array(
						'type'    => 'select',
						'label'   => 'امتیاز',
						'options' => array( '5' => '۵ از ۵', '4' => '۴ از ۵', '3' => '۳ از ۵', '2' => '۲ از ۵', '1' => '۱ از ۵' ),
					),
				),
			),
			'dani_faq' => array(
				'title'  => 'تنظیمات پرسش',
				'fields' => array(
					'group' => array( 'type' => 'text', 'label' => 'گروه', 'help' => 'برای دسته‌بندی پرسش‌ها در صفحه سؤالات متداول.' ),
				),
			),
		);

		return self::$map;
	}

	/**
	 * Register one meta box per content type.
	 *
	 * @return void
	 */
	public static function add_meta_boxes() {
		foreach ( self::map() as $post_type => $box ) {
			add_meta_box(
				'dani_fields_' . $post_type,
				$box['title'],
				array( __CLASS__, 'render_box' ),
				$post_type,
				'normal',
				'high',
				array( 'post_type' => $post_type )
			);
		}
	}

	/**
	 * Render the meta box.
	 *
	 * @param WP_Post $post Current post.
	 * @param array   $box  Meta box args.
	 * @return void
	 */
	public static function render_box( $post, $box ) {
		$post_type = isset( $box['args']['post_type'] ) ? $box['args']['post_type'] : $post->post_type;
		$map       = self::map();

		if ( empty( $map[ $post_type ] ) ) {
			return;
		}

		wp_nonce_field( 'dani_save_fields', 'dani_fields_nonce' );

		echo '<table class="form-table dani-fields"><tbody>';
		foreach ( $map[ $post_type ]['fields'] as $key => $field ) {
			$value = get_post_meta( $post->ID, '_dani_' . $key, true );
			echo '<tr><th scope="row"><label for="dani-' . esc_attr( $key ) . '">' . esc_html( $field['label'] ) . '</label></th><td>';
			self::render_input( $key, $field, $value );
			if ( ! empty( $field['help'] ) ) {
				echo '<p class="description">' . esc_html( $field['help'] ) . '</p>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	/**
	 * Render a single input.
	 *
	 * @param string $key   Field key.
	 * @param array  $field Field config.
	 * @param mixed  $value Current value.
	 * @return void
	 */
	private static function render_input( $key, $field, $value ) {
		$id   = 'dani-' . $key;
		$name = 'dani_field[' . $key . ']';
		$type = isset( $field['type'] ) ? $field['type'] : 'text';

		switch ( $type ) {
			case 'textarea':
				printf( '<textarea id="%1$s" name="%2$s" rows="5" class="large-text">%3$s</textarea>', esc_attr( $id ), esc_attr( $name ), esc_textarea( (string) $value ) );
				break;

			case 'lines':
				printf( '<textarea id="%1$s" name="%2$s" rows="5" class="large-text">%3$s</textarea>', esc_attr( $id ), esc_attr( $name ), esc_textarea( (string) $value ) );
				break;

			case 'select':
				echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '">';
				foreach ( (array) $field['options'] as $option_value => $label ) {
					printf(
						'<option value="%1$s"%2$s>%3$s</option>',
						esc_attr( $option_value ),
						selected( (string) $value, (string) $option_value, false ),
						esc_html( $label )
					);
				}
				echo '</select>';
				break;

			case 'checkbox':
				printf(
					'<label><input type="checkbox" id="%1$s" name="%2$s" value="1"%3$s> %4$s</label>',
					esc_attr( $id ),
					esc_attr( $name ),
					checked( (string) $value, '1', false ),
					esc_html__( 'فعال', 'danisite-core' )
				);
				break;

			case 'media':
				$url = $value ? wp_get_attachment_image_url( (int) $value, 'medium' ) : '';
				echo '<div class="dani-media-field">';
				printf( '<input type="hidden" id="%1$s" name="%2$s" value="%3$s" data-dani-media-input>', esc_attr( $id ), esc_attr( $name ), esc_attr( (string) $value ) );
				echo '<span class="dani-media-preview">' . ( $url ? '<img src="' . esc_url( $url ) . '" alt="">' : '' ) . '</span>';
				echo ' <button type="button" class="button" data-dani-media-select>' . esc_html__( 'انتخاب تصویر', 'danisite-core' ) . '</button>';
				echo ' <button type="button" class="button-link" data-dani-media-clear>' . esc_html__( 'حذف', 'danisite-core' ) . '</button>';
				echo '</div>';
				break;

			case 'url':
				printf( '<input type="url" id="%1$s" name="%2$s" value="%3$s" class="regular-text" dir="ltr">', esc_attr( $id ), esc_attr( $name ), esc_attr( (string) $value ) );
				break;

			default:
				printf( '<input type="text" id="%1$s" name="%2$s" value="%3$s" class="regular-text">', esc_attr( $id ), esc_attr( $name ), esc_attr( (string) $value ) );
				break;
		}
	}

	/**
	 * Save the submitted field values.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @return void
	 */
	public static function save( $post_id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}
		if ( ! isset( $_POST['dani_fields_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['dani_fields_nonce'] ) ), 'dani_save_fields' ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$map = self::map();
		if ( empty( $map[ $post->post_type ] ) || ! isset( $_POST['dani_field'] ) ) {
			return;
		}

		$submitted = wp_unslash( (array) $_POST['dani_field'] );

		foreach ( $map[ $post->post_type ]['fields'] as $key => $field ) {
			$raw  = isset( $submitted[ $key ] ) ? $submitted[ $key ] : '';
			$type = isset( $field['type'] ) ? $field['type'] : 'text';
			$clean = self::sanitize( $raw, $type, $field );

			if ( '' === $clean || ( 'checkbox' === $type && '1' !== $clean ) ) {
				delete_post_meta( $post_id, '_dani_' . $key );
			} else {
				update_post_meta( $post_id, '_dani_' . $key, $clean );
			}
		}
	}

	/**
	 * Sanitise a value according to its field type.
	 *
	 * @param mixed  $raw   Raw value.
	 * @param string $type  Field type.
	 * @param array  $field Field config.
	 * @return string
	 */
	public static function sanitize( $raw, $type, $field = array() ) {
		switch ( $type ) {
			case 'url':
				return esc_url_raw( (string) $raw );
			case 'email':
				return sanitize_email( (string) $raw );
			case 'textarea':
			case 'lines':
				return sanitize_textarea_field( (string) $raw );
			case 'checkbox':
				return '1' === (string) $raw ? '1' : '';
			case 'select':
				$options = isset( $field['options'] ) ? array_keys( (array) $field['options'] ) : array();
				$value   = sanitize_text_field( (string) $raw );
				return in_array( $value, array_map( 'strval', $options ), true ) ? $value : '';
			case 'media':
			case 'number':
				return (string) absint( $raw );
			default:
				return sanitize_text_field( (string) $raw );
		}
	}

	/**
	 * Media picker script for the meta boxes.
	 *
	 * @param string $hook Current admin page.
	 * @return void
	 */
	public static function admin_assets( $hook ) {
		if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_script( 'dani-admin', DANI_CORE_URL . 'assets/js/dani-admin.js', array( 'jquery' ), DANI_CORE_VERSION, true );
		wp_localize_script(
			'dani-admin',
			'daniAdmin',
			array(
				'choose' => __( 'انتخاب تصویر', 'danisite-core' ),
				'use'    => __( 'استفاده از این تصویر', 'danisite-core' ),
			)
		);
	}
}
