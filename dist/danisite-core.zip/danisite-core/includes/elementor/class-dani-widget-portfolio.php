<?php
/**
 * Portfolio widgets: masonry grid, carousel and a single card.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Dani_Widget_Base' ) ) {
	return;
}

/**
 * Category select options.
 *
 * @return array
 */
function dani_widget_project_categories() {
	$options = array( '' => 'همه دسته‌ها' );

	foreach ( Dani_Query::project_categories() as $term ) {
		$options[ $term['slug'] ] = $term['name'];
	}

	return $options;
}

/**
 * Portfolio grid.
 */
class Dani_Widget_Portfolio extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'portfolio';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_portfolio';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'نمونه‌کارها — گرید (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-gallery-masonry';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'SELECTED WORK' );
		$this->text( 'title', 'عنوان', 'نتیجه، خودش حرف می‌زند.' );
		$this->text( 'text', 'توضیح', 'مجموعه‌ای از تجربه‌ها و پروژه‌هایی که با نگاه متفاوت و توجه به جزئیات خلق شده‌اند.', 'textarea' );
		$this->text( 'limit', 'تعداد', 5, 'number' );

		$this->add_control(
			'category',
			array(
				'label'   => 'دسته نمونه‌کار',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => dani_widget_project_categories(),
				'default' => '',
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => 'چیدمان',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'masonry' => 'آرایش هنری (مطابق صفحه اصلی)',
					'grid'    => 'گرید منظم',
				),
				'default' => 'masonry',
			)
		);

		$this->toggle( 'filters', 'نمایش فیلتر دسته‌ها', false );
		$this->toggle( 'button', 'نمایش دکمه «همه پروژه‌ها»', true );
		$this->text( 'button_text', 'متن دکمه', 'مشاهده همه پروژه‌ها' );
		$this->text( 'button_url', 'لینک دکمه', '', 'url' );
		$this->toggle( 'surface', 'پس‌زمینه روشن', false );
		$this->end_controls_section();

		$this->content_section( 'پروژه‌های دستی (اختیاری)', 'items' );
		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'item_title', array( 'label' => 'عنوان', 'type' => \Elementor\Controls_Manager::TEXT ) );
		$repeater->add_control( 'item_text', array( 'label' => 'توضیح', 'type' => \Elementor\Controls_Manager::TEXTAREA ) );
		$repeater->add_control( 'item_image', array( 'label' => 'تصویر', 'type' => \Elementor\Controls_Manager::MEDIA ) );
		$repeater->add_control( 'item_category', array( 'label' => 'دسته (نمایشی)', 'type' => \Elementor\Controls_Manager::TEXT ) );
		$repeater->add_control( 'item_url', array( 'label' => 'لینک', 'type' => \Elementor\Controls_Manager::URL, 'show_external' => false ) );

		$this->add_control(
			'items',
			array(
				'label'       => 'پروژه‌ها',
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ item_title }}}',
				'description' => 'اگر خالی بماند، نمونه‌کارها از بخش «نمونه‌کارها» وردپرس نمایش داده می‌شود.',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map(
			$s,
			array(
				'eyebrow'     => 'eyebrow',
				'title'       => 'title',
				'text'        => 'text',
				'category'    => 'category',
				'layout'      => 'layout',
				'button_text' => 'button_text',
			)
		);

		$args['limit']    = isset( $s['limit'] ) ? absint( $s['limit'] ) : 5;
		$args['filters']  = ! empty( $s['filters'] );
		$args['button']   = ! empty( $s['button'] );
		$args['surface']  = ! empty( $s['surface'] );
		$args['button_url'] = $this->link_url( $s, 'button_url' );

		$items = $this->repeater(
			$s,
			'items',
			array(
				'item_title'    => 'title',
				'item_text'     => 'desc',
				'item_category' => 'category',
			)
		);

		if ( $items ) {
			foreach ( $s['items'] as $index => $row ) {
				if ( ! isset( $items[ $index ] ) ) {
					continue;
				}
				$items[ $index ]['thumb'] = isset( $row['item_image']['url'] ) ? $row['item_image']['url'] : '';
				$items[ $index ]['url']   = isset( $row['item_url']['url'] ) ? $row['item_url']['url'] : '';
			}
			$args['items'] = $items;
		}

		return $args;
	}
}

/**
 * Portfolio carousel.
 */
class Dani_Widget_Portfolio_Carousel extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'portfolio_carousel';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_portfolio_carousel';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'نمونه‌کارها — اسلایدر (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-carousel';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'SELECTED WORK' );
		$this->text( 'title', 'عنوان', 'پروژه‌هایی که دوستشان داریم.' );
		$this->text( 'text', 'توضیح', '', 'textarea' );
		$this->text( 'limit', 'تعداد', 8, 'number' );
		$this->add_control(
			'category',
			array(
				'label'   => 'دسته',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => dani_widget_project_categories(),
				'default' => '',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map( $s, array( 'eyebrow' => 'eyebrow', 'title' => 'title', 'text' => 'text', 'category' => 'category' ) );
		$args['limit'] = isset( $s['limit'] ) ? absint( $s['limit'] ) : 8;

		return $args;
	}
}

/**
 * Single portfolio card.
 */
class Dani_Widget_Portfolio_Card extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'portfolio_card';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_portfolio_card';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'کارت نمونه‌کار (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image-box';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'کارت' );
		$this->text( 'title', 'عنوان', 'فروشگاه اینترنتی کفش' );
		$this->text( 'desc', 'توضیح', 'ویترینی مینیمال که محصول را در مرکز توجه نگه می‌دارد.', 'textarea' );
		$this->text( 'category', 'دسته', 'فروشگاهی · نمونه نمایشی' );
		$this->media( 'image', 'تصویر' );
		$this->text( 'url', 'لینک', '', 'url' );
		$this->add_control(
			'ratio',
			array(
				'label'   => 'نسبت تصویر',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'16-10' => '۱۶:۱۰',
					'4-5'   => '۴:۵',
					'4-3'   => '۴:۳',
					'16-9'  => '۱۶:۹',
				),
				'default' => '4-3',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-project' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		return array(
			'item' => array(
				'title'    => isset( $s['title'] ) ? $s['title'] : '',
				'desc'     => isset( $s['desc'] ) ? $s['desc'] : '',
				'category' => isset( $s['category'] ) ? $s['category'] : '',
				'thumb'    => $this->media_url( $s, 'image' ),
				'url'      => $this->link_url( $s, 'url' ),
				'ratio'    => isset( $s['ratio'] ) ? $s['ratio'] : '4-3',
			),
		);
	}
}
