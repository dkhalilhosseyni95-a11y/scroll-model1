<?php
/**
 * Services widgets: numbered list, cards grid and a single card.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Dani_Widget_Base' ) ) {
	return;
}

/**
 * Numbered services list (the homepage "SERVICES" section).
 */
class Dani_Widget_Services extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'services';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_services';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'خدمات — فهرست شماره‌دار (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-number-field';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'SERVICES' );
		$this->text( 'title', 'عنوان', 'از ایده تا تجربه‌ای که کار می‌کند.' );
		$this->text( 'text', 'توضیح', 'هر کسب‌وکار به راهکاری متناسب با اهداف، مخاطبان و هویت خودش نیاز دارد.', 'textarea' );
		$this->text( 'limit', 'تعداد خدمت', 6, 'number' );
		$this->toggle( 'surface', 'پس‌زمینه روشن', true );
		$this->end_controls_section();

		$this->content_section( 'خدمات دستی (اختیاری)', 'items' );
		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'item_title', array( 'label' => 'عنوان', 'type' => \Elementor\Controls_Manager::TEXT ) );
		$repeater->add_control( 'item_text', array( 'label' => 'توضیح', 'type' => \Elementor\Controls_Manager::TEXTAREA ) );
		$repeater->add_control( 'item_url', array( 'label' => 'لینک', 'type' => \Elementor\Controls_Manager::URL, 'show_external' => false ) );
		$repeater->add_control( 'item_number', array( 'label' => 'شماره', 'type' => \Elementor\Controls_Manager::TEXT ) );

		$this->add_control(
			'items',
			array(
				'label'       => 'خدمات',
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ item_title }}}',
				'description' => 'اگر خالی بماند، خدمات از بخش «خدمات» وردپرس نمایش داده می‌شود.',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map(
			$s,
			array(
				'eyebrow' => 'eyebrow',
				'title'   => 'title',
				'text'    => 'text',
			)
		);

		$args['limit']   = isset( $s['limit'] ) ? absint( $s['limit'] ) : 6;
		$args['surface'] = ! empty( $s['surface'] );
		$items           = $this->repeater(
			$s,
			'items',
			array(
				'item_title'  => 'title',
				'item_text'   => 'desc',
				'item_number' => 'n',
			)
		);

		if ( $items ) {
			foreach ( $s['items'] as $index => $row ) {
				if ( isset( $row['item_url']['url'] ) && isset( $items[ $index ] ) ) {
					$items[ $index ]['url'] = $row['item_url']['url'];
				}
			}
			$args['items'] = $items;
		}

		return $args;
	}
}

/**
 * Service cards grid.
 */
class Dani_Widget_Service_Cards extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'service_cards';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_service_cards';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'کارت‌های خدمات (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'SERVICES' );
		$this->text( 'title', 'عنوان', 'خدماتی که مسیر رشد را هموار می‌کنند.' );
		$this->text( 'text', 'توضیح', '', 'textarea' );
		$this->text( 'limit', 'تعداد', 6, 'number' );
		$this->add_control(
			'columns',
			array(
				'label'   => 'تعداد ستون',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array( '2' => '۲', '3' => '۳' ),
				'default' => '3',
			)
		);
		$this->toggle( 'surface', 'پس‌زمینه روشن', false );
		$this->end_controls_section();

		$this->content_section( 'کارت‌های دستی (اختیاری)', 'items' );
		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'item_title', array( 'label' => 'عنوان', 'type' => \Elementor\Controls_Manager::TEXT ) );
		$repeater->add_control( 'item_text', array( 'label' => 'توضیح', 'type' => \Elementor\Controls_Manager::TEXTAREA ) );
		$repeater->add_control( 'item_icon', array( 'label' => 'آیکون', 'type' => \Elementor\Controls_Manager::ICONS, 'default' => array( 'value' => 'fas fa-star', 'library' => 'fa-solid' ) ) );
		$repeater->add_control( 'item_url', array( 'label' => 'لینک', 'type' => \Elementor\Controls_Manager::URL, 'show_external' => false ) );

		$this->add_control(
			'items',
			array(
				'label'       => 'کارت‌ها',
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ item_title }}}',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map( $s, array( 'eyebrow' => 'eyebrow', 'title' => 'title', 'text' => 'text' ) );

		$args['limit']   = isset( $s['limit'] ) ? absint( $s['limit'] ) : 6;
		$args['columns'] = isset( $s['columns'] ) ? (int) $s['columns'] : 3;
		$args['surface'] = ! empty( $s['surface'] );

		$items = $this->repeater( $s, 'items', array( 'item_title' => 'title', 'item_text' => 'desc' ) );
		if ( $items ) {
			foreach ( $s['items'] as $index => $row ) {
				if ( isset( $items[ $index ] ) ) {
					$items[ $index ]['url'] = isset( $row['item_url']['url'] ) ? $row['item_url']['url'] : '';
				}
			}
			$args['items'] = $items;
		}

		return $args;
	}
}

/**
 * Single service card.
 */
class Dani_Widget_Service_Card extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'service_card';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_service_card';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'کارت خدمت (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-icon-box';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'کارت' );
		$this->text( 'title', 'عنوان', 'طراحی رابط و تجربه کاربری' );
		$this->text( 'desc', 'توضیح', 'طراحی رابط‌هایی که بدون توضیح فهمیده می‌شوند؛ از وایرفریم تا دیزاین سیستم.', 'textarea' );
		$this->add_control(
			'icon',
			array(
				'label'   => 'آیکون',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => Dani_Fields::icon_choices(),
				'default' => 'palette',
			)
		);
		$this->text( 'price', 'قیمت / بازه' );
		$this->text( 'url', 'لینک', '', 'url' );
		$this->text( 'features', 'ویژگی‌ها (هر خط یک مورد)', '', 'textarea' );
		$this->end_controls_section();

		$this->style_section( '.dani-card' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$features = array_filter( array_map( 'trim', explode( "\n", isset( $s['features'] ) ? $s['features'] : '' ) ) );

		return array(
			'item' => array(
				'title'    => isset( $s['title'] ) ? $s['title'] : '',
				'desc'     => isset( $s['desc'] ) ? $s['desc'] : '',
				'icon'     => isset( $s['icon'] ) ? $s['icon'] : 'sparkles',
				'price'    => isset( $s['price'] ) ? $s['price'] : '',
				'url'      => $this->link_url( $s, 'url' ),
				'features' => $features,
			),
		);
	}
}
