<?php
/**
 * Header, navigation and footer widgets.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Dani_Widget_Base' ) ) {
	return;
}

/**
 * Glass header bar.
 */
class Dani_Widget_Header extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'header';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_header';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'هدر (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-header';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'هدر' );
		$this->text( 'cta_label', 'متن دکمه', dani_option( 'cta_label' ) );
		$this->text( 'cta_url', 'لینک دکمه', dani_option( 'cta_url' ) );
		$this->toggle( 'inline', 'نمایش درون صفحه (بدون چسبیدن به بالا)', true );
		$this->end_controls_section();

		$this->style_section( '.dani-header' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		return array(
			'cta_label' => isset( $s['cta_label'] ) ? $s['cta_label'] : '',
			'cta_url'   => isset( $s['cta_url'] ) && $s['cta_url'] ? $s['cta_url'] : dani_option( 'cta_url' ),
			'inline'    => ! empty( $s['inline'] ),
		);
	}
}

/**
 * Plain navigation links.
 */
class Dani_Widget_Navigation extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'navigation';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_navigation';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'ناوبری (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-nav-menu';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'ناوبری' );
		$this->add_control(
			'note',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => 'این ویجت پیوندهای منوی «منوی اصلی» وردپرس را نمایش می‌دهد. برای ویرایش، از نمایش ← فهرست‌ها استفاده کنید.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}
}

/**
 * Footer widget.
 */
class Dani_Widget_Footer extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'footer';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_footer';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'فوتر (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-footer';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'فوتر' );
		$this->add_control(
			'note',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => 'محتوای فوتر (لینک‌ها، خدمات، اطلاعات تماس و شبکه‌های اجتماعی) از «DaniSite ← تنظیمات» و فهرست‌های وردپرس خوانده می‌شود.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);
		$this->end_controls_section();
	}
}
