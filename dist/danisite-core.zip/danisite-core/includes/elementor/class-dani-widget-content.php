<?php
/**
 * Content widgets: experience, about, workflow, team, testimonials, stats,
 * FAQ and the final call to action.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Dani_Widget_Base' ) ) {
	return;
}

/**
 * Digital experience section.
 */
class Dani_Widget_Experience extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'experience';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_experience';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'تجربه دیجیتال (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-video-playlist';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'DIGITAL EXPERIENCE' );
		$this->text( 'title', 'عنوان', 'فقط یک وب‌سایت نسازید؛ یک تجربه خلق کنید.' );
		$this->text( 'text', 'توضیح', 'حرکت، تعامل و جزئیات بصری می‌توانند نحوه ارتباط مخاطب با یک برند را تغییر دهند. ما به طراحی به چشم فرصتی برای خلق تجربه‌ای ماندگار نگاه می‌کنیم.', 'textarea' );
		$this->media( 'image', 'تصویر' );
		$this->text( 'caption', 'متن روی تصویر', 'حرکت ظریف، عمق و نور؛ سه ابزاری که هر رابط را به تجربه‌ای به یادماندنی تبدیل می‌کنند.', 'textarea' );
		$this->end_controls_section();

		$this->content_section( 'سه ویژگی', 'traits' );
		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'trait_title', array( 'label' => 'عنوان', 'type' => \Elementor\Controls_Manager::TEXT ) );
		$repeater->add_control( 'trait_text', array( 'label' => 'توضیح', 'type' => \Elementor\Controls_Manager::TEXT ) );
		$this->add_control(
			'traits',
			array(
				'label'       => 'ویژگی‌ها',
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ trait_title }}}',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map( $s, array( 'eyebrow' => 'eyebrow', 'title' => 'title', 'text' => 'text', 'caption' => 'caption' ) );

		$image = $this->media_url( $s, 'image' );
		if ( $image ) {
			$args['image'] = $image;
		}

		$traits = $this->repeater( $s, 'traits', array( 'trait_title' => 'title', 'trait_text' => 'text' ) );
		if ( $traits ) {
			$args['traits'] = $traits;
		}

		return $args;
	}
}

/**
 * About / founder section.
 */
class Dani_Widget_About extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'about';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_about';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'درباره ما (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image-rollover';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'ABOUT DANISITE' );
		$this->text( 'title', 'عنوان', 'طراحی خوب، از یک تفکر خوب شروع می‌شود.' );
		$this->text( 'text', 'توضیح', 'در دنی سایت، هر پروژه با شناخت نیاز واقعی کسب‌وکار و درک تجربه مخاطب آغاز می‌شود.', 'textarea' );
		$this->media( 'image', 'تصویر' );
		$this->text( 'badge_label', 'برچسب کارت تصویر', 'بنیان‌گذار' );
		$this->text( 'badge_name', 'نام کارت تصویر', 'دانیال حسینی' );
		$this->text( 'quote_name', 'نام در نقل‌قول', 'دانیال حسینی' );
		$this->text( 'quote', 'ادامه نقل‌قول', '، بنیان‌گذار DaniSite، طراح و توسعه‌دهنده‌ای است که طراحی را نقطه تلاقی استراتژی، زیبایی و فناوری می‌داند.', 'textarea' );
		$this->text( 'tags', 'برچسب‌ها (با کاما جدا شود)', 'طراحی UI/UX، وردپرس و ووکامرس، توسعه فرانت‌اند، هویت دیجیتال، بهینه‌سازی سرعت' );
		$this->text( 'button_text', 'متن دکمه', 'بیشتر درباره ما' );
		$this->text( 'button_url', 'لینک دکمه', '', 'url' );
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map(
			$s,
			array(
				'eyebrow'    => 'eyebrow',
				'title'      => 'title',
				'text'       => 'text',
				'badge_label' => 'badge_label',
				'badge_name'  => 'badge_name',
				'quote_name'  => 'quote_name',
				'quote'       => 'quote',
				'button_text' => 'button_text',
			)
		);

		$image = $this->media_url( $s, 'image' );
		if ( $image ) {
			$args['image'] = $image;
		}

		if ( ! empty( $s['tags'] ) ) {
			$args['tags'] = array_filter( array_map( 'trim', explode( '،', $s['tags'] ) ) );
		}

		$args['button_url'] = $this->link_url( $s, 'button_url' );

		return $args;
	}
}

/**
 * Process steps.
 */
class Dani_Widget_Workflow extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'workflow';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_workflow';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'فرایند کار (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-time-line';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'PROCESS' );
		$this->text( 'title', 'عنوان', 'از اولین گفت‌وگو تا لحظه رونمایی.' );
		$this->text( 'text', 'توضیح', '', 'textarea' );
		$this->end_controls_section();

		$this->content_section( 'مراحل (اختیاری)', 'steps' );
		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'step_number', array( 'label' => 'شماره', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => '۰۱' ) );
		$repeater->add_control( 'step_title', array( 'label' => 'عنوان', 'type' => \Elementor\Controls_Manager::TEXT ) );
		$repeater->add_control( 'step_text', array( 'label' => 'توضیح', 'type' => \Elementor\Controls_Manager::TEXTAREA ) );
		$this->add_control(
			'steps',
			array(
				'label'       => 'مراحل',
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ step_number }}} — {{{ step_title }}}',
				'description' => 'اگر خالی بماند، مراحل پیش‌فرض نمایش داده می‌شود.',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args  = $this->map( $s, array( 'eyebrow' => 'eyebrow', 'title' => 'title', 'text' => 'text' ) );
		$steps = $this->repeater( $s, 'steps', array( 'step_number' => 'n', 'step_title' => 'title', 'step_text' => 'desc' ) );

		if ( $steps ) {
			$args['steps'] = $steps;
		}

		return $args;
	}
}

/**
 * Team grid.
 */
class Dani_Widget_Team extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'team';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_team';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'اعضای تیم (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-person';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'TEAM' );
		$this->text( 'title', 'عنوان', 'آدم‌هایی که پشت هر پروژه هستند.' );
		$this->text( 'text', 'توضیح', '', 'textarea' );
		$this->text( 'limit', 'تعداد', 6, 'number' );
		$this->toggle( 'surface', 'پس‌زمینه روشن', false );
		$this->end_controls_section();

		$this->content_section( 'اعضای دستی (اختیاری)', 'items' );
		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'item_title', array( 'label' => 'نام', 'type' => \Elementor\Controls_Manager::TEXT ) );
		$repeater->add_control( 'item_role', array( 'label' => 'سمت', 'type' => \Elementor\Controls_Manager::TEXT ) );
		$repeater->add_control( 'item_text', array( 'label' => 'بیوگرافی کوتاه', 'type' => \Elementor\Controls_Manager::TEXTAREA ) );
		$repeater->add_control( 'item_image', array( 'label' => 'تصویر', 'type' => \Elementor\Controls_Manager::MEDIA ) );
		$repeater->add_control( 'item_instagram', array( 'label' => 'اینستاگرام', 'type' => \Elementor\Controls_Manager::URL, 'show_external' => false ) );
		$this->add_control(
			'items',
			array(
				'label'       => 'اعضا',
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ item_title }}}',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map( $s, array( 'eyebrow' => 'eyebrow', 'title' => 'title', 'text' => 'text' ) );
		$args['limit']   = isset( $s['limit'] ) ? absint( $s['limit'] ) : 6;
		$args['surface'] = ! empty( $s['surface'] );

		$items = $this->repeater(
			$s,
			'items',
			array(
				'item_title' => 'title',
				'item_role'  => 'role',
				'item_text'  => 'desc',
			)
		);

		if ( $items ) {
			foreach ( $s['items'] as $index => $row ) {
				if ( ! isset( $items[ $index ] ) ) {
					continue;
				}
				$items[ $index ]['thumb']     = isset( $row['item_image']['url'] ) ? $row['item_image']['url'] : '';
				$items[ $index ]['instagram'] = isset( $row['item_instagram']['url'] ) ? $row['item_instagram']['url'] : '';
			}
			$args['items'] = $items;
		}

		return $args;
	}
}

/**
 * Testimonials slider.
 */
class Dani_Widget_Testimonials extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'testimonials';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_testimonials';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'نظرات مشتریان (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-testimonial';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'TESTIMONIALS' );
		$this->text( 'title', 'عنوان', 'اعتماد، با تجربه واقعی ساخته می‌شود.' );
		$this->text( 'text', 'توضیح', '', 'textarea' );
		$this->text( 'limit', 'تعداد', 5, 'number' );
		$this->toggle( 'surface', 'پس‌زمینه روشن', true );
		$this->end_controls_section();

		$this->content_section( 'نظرات دستی (اختیاری)', 'items' );
		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'item_text', array( 'label' => 'متن نظر', 'type' => \Elementor\Controls_Manager::TEXTAREA ) );
		$repeater->add_control( 'item_author', array( 'label' => 'نام مشتری', 'type' => \Elementor\Controls_Manager::TEXT ) );
		$repeater->add_control( 'item_role', array( 'label' => 'سمت / شرکت', 'type' => \Elementor\Controls_Manager::TEXT ) );
		$this->add_control(
			'items',
			array(
				'label'       => 'نظرات',
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ item_author }}}',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map( $s, array( 'eyebrow' => 'eyebrow', 'title' => 'title', 'text' => 'text' ) );
		$args['limit']   = isset( $s['limit'] ) ? absint( $s['limit'] ) : 5;
		$args['surface'] = ! empty( $s['surface'] );

		$items = $this->repeater( $s, 'items', array( 'item_text' => 'text', 'item_author' => 'author', 'item_role' => 'role' ) );
		if ( $items ) {
			$args['items'] = $items;
		}

		return $args;
	}
}

/**
 * Statistics row.
 */
class Dani_Widget_Stats extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'stats';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_stats';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'آمار (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-counter';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'آمار' );
		$this->toggle( 'surface', 'پس‌زمینه روشن', false );

		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'stat_value', array( 'label' => 'عدد', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => '۴۰+' ) );
		$repeater->add_control( 'stat_label', array( 'label' => 'برچسب', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'پروژه تحویل‌شده' ) );

		$this->add_control(
			'items',
			array(
				'label'       => 'موارد',
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ stat_value }}} — {{{ stat_label }}}',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args  = array( 'surface' => ! empty( $s['surface'] ) );
		$items = $this->repeater( $s, 'items', array( 'stat_value' => 'value', 'stat_label' => 'label' ) );

		if ( $items ) {
			$args['items'] = $items;
		}

		return $args;
	}
}

/**
 * FAQ accordion.
 */
class Dani_Widget_Faq extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'faq';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_faq';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'پرسش‌های متداول (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-accordion';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'FAQ' );
		$this->text( 'title', 'عنوان', 'پرسش‌هایی که پیش از شروع می‌پرسید.' );
		$this->text( 'text', 'توضیح', 'اگر پاسخ سؤال‌تان این‌جا نبود، در تماس با ما با کمال میل پاسخ می‌دهیم.', 'textarea' );
		$this->text( 'limit', 'تعداد', 8, 'number' );
		$this->toggle( 'surface', 'پس‌زمینه روشن', false );
		$this->end_controls_section();

		$this->content_section( 'پرسش‌های دستی (اختیاری)', 'items' );
		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'item_question', array( 'label' => 'پرسش', 'type' => \Elementor\Controls_Manager::TEXT ) );
		$repeater->add_control( 'item_answer', array( 'label' => 'پاسخ', 'type' => \Elementor\Controls_Manager::TEXTAREA ) );
		$this->add_control(
			'items',
			array(
				'label'       => 'پرسش‌ها',
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ item_question }}}',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map( $s, array( 'eyebrow' => 'eyebrow', 'title' => 'title', 'text' => 'text' ) );
		$args['limit']   = isset( $s['limit'] ) ? absint( $s['limit'] ) : 8;
		$args['surface'] = ! empty( $s['surface'] );

		$items = $this->repeater( $s, 'items', array( 'item_question' => 'question', 'item_answer' => 'answer' ) );
		if ( $items ) {
			$args['items'] = $items;
		}

		return $args;
	}
}

/**
 * Final call to action.
 */
class Dani_Widget_Cta extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'cta';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_cta';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'دعوت به همکاری (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-call-to-action';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'title', 'عنوان', 'شاید این، شروع یک همکاری متفاوت باشد.' );
		$this->text( 'text', 'توضیح', 'ایده‌تان را با ما در میان بگذارید. برای ساختن تجربه دیجیتال بعدی آماده‌ایم.', 'textarea' );
		$this->text( 'primary_label', 'متن دکمه اول', 'شروع یک پروژه جدید' );
		$this->text( 'primary_url', 'لینک دکمه اول', '', 'url' );
		$this->text( 'second_label', 'متن دکمه دوم', '' );
		$this->text( 'second_url', 'لینک دکمه دوم', '', 'url' );
		$this->end_controls_section();

		$this->style_section( '.dani-cta' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map(
			$s,
			array(
				'title'         => 'title',
				'text'          => 'text',
				'primary_label' => 'primary_label',
				'second_label'  => 'second_label',
			)
		);

		$args['primary_url'] = $this->link_url( $s, 'primary_url' );
		$args['second_url']  = $this->link_url( $s, 'second_url' );

		return $args;
	}
}
