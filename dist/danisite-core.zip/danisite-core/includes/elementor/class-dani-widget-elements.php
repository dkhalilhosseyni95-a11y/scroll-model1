<?php
/**
 * Small element widgets: contact, socials, logo, button, image, video,
 * scroll animation and a heading block.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Dani_Widget_Base' ) ) {
	return;
}

/**
 * Contact section with the styled form.
 */
class Dani_Widget_Contact extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'contact';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_contact';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'تماس با ما (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'CONTACT' );
		$this->text( 'title', 'عنوان', 'درباره پروژه‌تان حرف بزنیم.' );
		$this->text( 'text', 'توضیح', 'هر همکاری از یک گفت‌وگوی کوتاه شروع می‌شود. فرم را پر کنید یا مستقیم تماس بگیرید.', 'textarea' );
		$this->toggle( 'surface', 'پس‌زمینه روشن', false );
		$this->add_control(
			'note',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => 'اطلاعات تماس و شبکه‌های اجتماعی از «DaniSite ← تنظیمات» خوانده می‌شود. پیام‌های فرم در «پیام‌های تماس» ذخیره می‌شوند.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map( $s, array( 'eyebrow' => 'eyebrow', 'title' => 'title', 'text' => 'text' ) );
		$args['surface'] = ! empty( $s['surface'] );

		return $args;
	}
}

/**
 * Social links.
 */
class Dani_Widget_Social extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'social';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_social';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'شبکه‌های اجتماعی (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'پیوندها' );
		$this->toggle( 'center', 'وسط‌چین', false );

		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'social_label', array( 'label' => 'عنوان', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'اینستاگرام' ) );
		$repeater->add_control( 'social_url', array( 'label' => 'لینک', 'type' => \Elementor\Controls_Manager::URL, 'show_external' => false ) );
		$repeater->add_control(
			'social_icon',
			array(
				'label'   => 'آیکون',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'instagram' => 'اینستاگرام',
					'linkedin'  => 'لینکدین',
					'telegram'  => 'تلگرام',
					'whatsapp'  => 'واتس‌اپ',
					'x-social'  => 'ایکس',
					'globe'     => 'وب‌سایت',
					'mail'      => 'ایمیل',
				),
				'default' => 'instagram',
			)
		);

		$this->add_control(
			'items',
			array(
				'label'       => 'شبکه‌ها',
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ social_label }}}',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Render: social links live in a small container.
	 *
	 * @return void
	 */
	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = $this->repeater( $s, 'items', array( 'social_label' => 'label', 'social_icon' => 'icon' ) );

		if ( ! $items ) {
			$items = dani_get_socials();
		}

		if ( $items ) {
			foreach ( $s['items'] as $index => $row ) {
				if ( isset( $items[ $index ] ) && isset( $row['social_url']['url'] ) && $row['social_url']['url'] ) {
					$items[ $index ]['url'] = $row['social_url']['url'];
				}
			}
		}

		echo '<div class="dani-section dani-section--tight"><div class="dani-container"><div class="dani-socials' . ( ! empty( $s['center'] ) ? ' dani-socials--center' : '' ) . '">';
		foreach ( $items as $item ) {
			if ( empty( $item['url'] ) ) {
				continue;
			}
			echo Dani_Blocks::render_social( array( 'item' => $item ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</div></div></div>';
	}
}

/**
 * Site logo.
 */
class Dani_Widget_Logo extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'logo';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_logo';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'لوگو (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-logo';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'لوگو' );
		$this->toggle( 'center', 'وسط‌چین', false );
		$this->add_control(
			'note',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => 'لوگوی سفارشی از «سفارشی‌سازی ← هویت سایت ← لوگو» خوانده می‌شود؛ در غیر این صورت نشان دنی سایت نمایش داده می‌شود.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'dani_logo_style',
			array( 'label' => 'استایل', 'tab' => \Elementor\Controls_Manager::TAB_STYLE )
		);
		$this->add_responsive_control(
			'logo_width',
			array(
				'label'      => 'عرض نشان',
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 24, 'max' => 120 ) ),
				'selectors'  => array( '{{WRAPPER}} .dani-logo__mark' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->end_controls_section();
	}

	/**
	 * Render.
	 *
	 * @return void
	 */
	protected function render() {
		$s = $this->get_settings_for_display();

		echo '<div class="dani-section dani-section--tight"' . ( ! empty( $s['center'] ) ? ' style="text-align:center"' : '' ) . '><div class="dani-container">';
		echo dani_logo( array( 'echo' => false ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div></div>';
	}
}

/**
 * Site button.
 */
class Dani_Widget_Button extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'button';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_button';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'دکمه (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'دکمه' );
		$this->text( 'label', 'متن', 'شروع همکاری' );
		$this->text( 'url', 'لینک', '#', 'url' );
		$this->add_control(
			'variant',
			array(
				'label'   => 'نوع',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'primary' => 'اصلی (گرادیان برند)',
					'ghost'   => 'خط‌دار',
					'glass'   => 'شیشه‌ای',
				),
				'default' => 'primary',
			)
		);
		$this->add_control(
			'size',
			array(
				'label'   => 'اندازه',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array( 'md' => 'معمولی', 'lg' => 'بزرگ' ),
				'default' => 'lg',
			)
		);
		$this->add_control(
			'icon',
			array(
				'label'   => 'آیکون',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					''            => 'بدون آیکون',
					'arrow-left'  => 'فلش چپ',
					'arrow-right' => 'فلش راست',
					'mail'        => 'ایمیل',
					'phone'       => 'تلفن',
					'search'      => 'جست‌وجو',
					'calendar'    => 'تقویم',
				),
				'default' => 'arrow-left',
			)
		);
		$this->add_control(
			'icon_pos',
			array(
				'label'   => 'جای آیکون',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array( 'start' => 'ابتدای دکمه', 'end' => 'انتهای دکمه' ),
				'default' => 'end',
				'condition' => array( 'icon!' => '' ),
			)
		);
		$this->add_control(
			'align',
			array(
				'label'   => 'چیدمان',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array( 'start' => 'راست‌چین', 'center' => 'وسط‌چین', 'end' => 'چپ‌چین' ),
				'default' => 'start',
			)
		);
		$this->toggle( 'surface', 'پس‌زمینه روشن', false );
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Render.
	 *
	 * @return void
	 */
	protected function render() {
		$s = $this->get_settings_for_display();

		$justify = array( 'start' => 'start', 'center' => 'center', 'end' => 'end' );

		echo '<div class="dani-section dani-section--tight' . ( ! empty( $s['surface'] ) ? ' dani-section--surface' : '' ) . '"><div class="dani-container" style="display:flex;justify-content:' . esc_attr( $justify[ $s['align'] ] ) . '">';
		echo Dani_Blocks::render_button( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array(
				'label'    => $s['label'],
				'url'      => $this->link_url( $s, 'url' ),
				'variant'  => $s['variant'],
				'size'     => $s['size'],
				'icon'     => $s['icon'],
				'icon_pos' => $s['icon_pos'],
			)
		);
		echo '</div></div>';
	}
}

/**
 * Image element.
 */
class Dani_Widget_Image extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'image';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_image';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'تصویر (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'تصویر' );
		$this->media( 'image', 'تصویر' );
		$this->text( 'alt', 'متن جایگزین (Alt)', '' );
		$this->add_control(
			'ratio',
			array(
				'label'   => 'نسبت تصویر',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array( '' => 'طبیعی', '16/9' => '۱۶:۹', '4/3' => '۴:۳', '1/1' => 'مربع', '4/5' => '۴:۵' ),
				'default' => '',
			)
		);
		$this->add_control(
			'radius',
			array(
				'label'      => 'شعاع گوشه (px)',
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
				'default'    => array( 'size' => 24 ),
				'selectors'  => array( '{{WRAPPER}} img' => 'border-radius: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->end_controls_section();

		$this->style_section( 'figure' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		return array(
			'url'   => $this->media_url( $s, 'image' ),
			'alt'   => isset( $s['alt'] ) ? $s['alt'] : '',
			'ratio' => isset( $s['ratio'] ) ? $s['ratio'] : '',
		);
	}
}

/**
 * Video element.
 */
class Dani_Widget_Video extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'video';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_video';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'ویدیو (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-youtube';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'ویدیو' );
		$this->media( 'video', 'فایل MP4 (میزبانی خودی)', array( 'video' ) );
		$this->media( 'poster', 'پوستر' );
		$this->text( 'embed', 'لینک ویدیو (یوتیوب/آپارات)', '', 'url' );
		$this->add_control(
			'note',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => 'اگر فایل MP4 انتخاب شود، همان نمایش داده می‌شود؛ در غیر این صورت لینک ویدیوی بیرونی. برای حفظ سرعت، ویدیو با preload="metadata" بارگذاری می‌شود.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		return array(
			'url'    => $this->media_url( $s, 'video' ),
			'poster' => $this->media_url( $s, 'poster' ),
			'embed'  => $this->link_url( $s, 'embed' ),
		);
	}
}

/**
 * Scroll animation block.
 */
class Dani_Widget_Scroll_Animation extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'scroll_animation';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_scroll_animation';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'انیمیشن اسکرول (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-animation';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', '' );
		$this->text( 'title', 'عنوان', 'حرکت، زمانی معنا دارد که دیده شود.' );
		$this->text( 'text', 'توضیح', 'این بلوک با ورود به دید کاربر به‌آرامی ظاهر می‌شود؛ همان الگوی انیمیشن صفحه اصلی.', 'textarea' );
		$this->toggle( 'surface', 'پس‌زمینه روشن', false );
		$this->end_controls_section();

		$this->content_section( 'انیمیشن', 'animation' );
		$this->add_control(
			'direction',
			array(
				'label'   => 'جهت ورود',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'up'    => 'از پایین',
					'down'  => 'از بالا',
					'start' => 'از راست',
					'end'   => 'از چپ',
					'zoom'  => 'بزرگ‌نمایی',
				),
				'default' => 'up',
			)
		);
		$this->add_control(
			'delay',
			array(
				'label'   => 'تأخیر (میلی‌ثانیه)',
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 2000,
				'step'    => 50,
				'default' => 0,
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map(
			$s,
			array(
				'eyebrow'   => 'eyebrow',
				'title'     => 'title',
				'text'      => 'text',
				'direction' => 'direction',
			)
		);

		$args['delay']   = isset( $s['delay'] ) ? absint( $s['delay'] ) : 0;
		$args['surface'] = ! empty( $s['surface'] );

		return $args;
	}
}

/**
 * Heading block.
 */
class Dani_Widget_Heading extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'heading';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_heading';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'عنوان بخش (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-heading';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'DANISITE' );
		$this->text( 'title', 'عنوان', 'عنوان بخش' );
		$this->text( 'text', 'توضیح', '', 'textarea' );
		$this->add_control(
			'tag',
			array(
				'label'   => 'سطح عنوان',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array( 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3' ),
				'default' => 'h2',
			)
		);
		$this->add_control(
			'align',
			array(
				'label'   => 'چیدمان',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array( 'start' => 'راست‌چین', 'center' => 'وسط‌چین' ),
				'default' => 'start',
			)
		);
		$this->toggle( 'surface', 'پس‌زمینه روشن', false );
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Render.
	 *
	 * @return void
	 */
	protected function render() {
		$s     = $this->get_settings_for_display();
		$align = isset( $s['align'] ) ? $s['align'] : 'start';

		echo '<section class="dani-section dani-section--tight' . ( ! empty( $s['surface'] ) ? ' dani-section--surface' : '' ) . '"><div class="dani-container">';
		echo Dani_Blocks::render_head( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array(
				'eyebrow' => $s['eyebrow'],
				'title'   => $s['title'],
				'text'    => $s['text'],
				'tag'     => $s['tag'],
				'center'  => 'center' === $align,
			)
		);
		echo '</div></section>';
	}
}

/**
 * Inner page hero.
 */
class Dani_Widget_Page_Hero extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'page_hero';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_page_hero';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'هیروی صفحه داخلی (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-page-title';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'DANISITE' );
		$this->text( 'title', 'عنوان صفحه', 'عنوان صفحه' );
		$this->text( 'text', 'توضیح', '', 'textarea' );
		$this->toggle( 'crumbs', 'نمایش مسیر صفحه', true );
		$this->end_controls_section();

		$this->style_section( '.dani-page-hero' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map( $s, array( 'eyebrow' => 'eyebrow', 'title' => 'title', 'text' => 'text' ) );
		$args['crumbs'] = ! empty( $s['crumbs'] );

		return $args;
	}
}
