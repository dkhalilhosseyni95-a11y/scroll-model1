<?php
/**
 * Blog, gallery and before/after widgets.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Dani_Widget_Base' ) ) {
	return;
}

/**
 * Blog grid.
 */
class Dani_Widget_Blog extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'blog';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_blog';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'گرید وبلاگ (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'JOURNAL' );
		$this->text( 'title', 'عنوان', 'تازه‌ترین نوشته‌ها' );
		$this->text( 'text', 'توضیح', 'محتوایی برای کسب‌وکارهایی که می‌خواهند در فضای دیجیتال متمایز دیده شوند.', 'textarea' );
		$this->text( 'limit', 'تعداد', 3, 'number' );
		$this->text( 'category', 'نامک دسته (اختیاری)', '' );
		$this->add_control(
			'columns',
			array(
				'label'   => 'تعداد ستون',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array( '2' => '۲', '3' => '۳' ),
				'default' => '3',
			)
		);
		$this->toggle( 'button', 'نمایش دکمه', true );
		$this->text( 'button_text', 'متن دکمه', 'همه نوشته‌ها' );
		$this->text( 'button_url', 'لینک دکمه', '', 'url' );
		$this->toggle( 'surface', 'پس‌زمینه روشن', true );
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map(
			$s,
			array(
				'eyebrow'     => 'eyebrow',
				'title'       => 'title',
				'text'        => 'text',
				'category'    => 'category',
				'button_text' => 'button_text',
			)
		);

		$args['limit']      = isset( $s['limit'] ) ? absint( $s['limit'] ) : 3;
		$args['columns']    = isset( $s['columns'] ) ? (int) $s['columns'] : 3;
		$args['button']     = ! empty( $s['button'] );
		$args['surface']    = ! empty( $s['surface'] );
		$args['button_url'] = $this->link_url( $s, 'button_url' );

		return $args;
	}
}

/**
 * Gallery grid.
 */
class Dani_Widget_Gallery extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'gallery';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_gallery';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'گالری تصاویر (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'GALLERY' );
		$this->text( 'title', 'عنوان', 'نگاهی به جزئیات پروژه‌ها' );
		$this->text( 'text', 'توضیح', '', 'textarea' );
		$this->toggle( 'surface', 'پس‌زمینه روشن', false );
		$this->end_controls_section();

		$this->content_section( 'تصاویر', 'images' );
		$this->add_control(
			'images',
			array(
				'label'      => 'گالری',
				'type'       => \Elementor\Controls_Manager::GALLERY,
				'show_label' => false,
			)
		);
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map( $s, array( 'eyebrow' => 'eyebrow', 'title' => 'title', 'text' => 'text' ) );
		$args['surface'] = ! empty( $s['surface'] );

		$images = array();
		if ( ! empty( $s['images'] ) && is_array( $s['images'] ) ) {
			foreach ( $s['images'] as $image ) {
				if ( ! empty( $image['url'] ) ) {
					$images[] = array(
						'url' => $image['url'],
						'alt' => get_post_meta( isset( $image['id'] ) ? $image['id'] : 0, '_wp_attachment_image_alt', true ),
					);
				}
			}
		}

		if ( $images ) {
			$args['images'] = $images;
		}

		return $args;
	}
}

/**
 * Before / after comparison.
 */
class Dani_Widget_Before_After extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'before_after';

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_before_after';
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'قبل و بعد (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image-before-after';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );
		$this->text( 'eyebrow', 'برچسب بالا', 'TRANSFORMATION' );
		$this->text( 'title', 'عنوان', 'قبل و بعد یک بازطراحی.' );
		$this->text( 'text', 'توضیح', 'دستگیره را بکشید و تفاوت را ببینید.', 'textarea' );
		$this->media( 'before', 'تصویر قبل' );
		$this->media( 'after', 'تصویر بعد' );
		$this->text( 'before_label', 'برچسب قبل', 'قبل' );
		$this->text( 'after_label', 'برچسب بعد', 'بعد' );
		$this->toggle( 'surface', 'پس‌زمینه روشن', true );
		$this->end_controls_section();

		$this->style_section( '.dani-section' );
	}

	/**
	 * Args.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map(
			$s,
			array(
				'eyebrow'      => 'eyebrow',
				'title'        => 'title',
				'text'         => 'text',
				'before_label' => 'before_label',
				'after_label'  => 'after_label',
			)
		);

		$args['before']  = $this->media_url( $s, 'before' );
		$args['after']   = $this->media_url( $s, 'after' );
		$args['surface'] = ! empty( $s['surface'] );

		return $args;
	}
}
