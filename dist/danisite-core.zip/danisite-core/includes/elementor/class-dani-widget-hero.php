<?php
/**
 * Hero widgets.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Dani_Widget_Base' ) ) {
	return;
}

/**
 * Homepage hero with background video support.
 */
class Dani_Widget_Hero extends Dani_Widget_Base {

	/**
	 * Renderer.
	 *
	 * @var string
	 */
	protected $section_type = 'hero';

	/**
	 * Widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_hero';
	}

	/**
	 * Widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'هیرو (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-slider-full-screen';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->content_section( 'محتوا' );

		$this->text( 'eyebrow', 'متن بالای عنوان', 'DANISITE STUDIO · DIGITAL EXPERIENCE' );
		$this->text( 'title', 'عنوان اصلی', 'معمولی دیده نشوید.' );
		$this->text( 'highlight', 'بخش گرادیانتی عنوان', 'متفاوت به یاد بمانید.' );
		$this->text( 'text', 'توضیح', 'هر همکاری، فرصتی برای ساختن یک تجربه متفاوت است. ما با ترکیب خلاقیت، طراحی و تکنولوژی، تصویری ماندگار از برند شما در دنیای دیجیتال می‌سازیم.', 'textarea' );
		$this->text( 'primary_label', 'متن دکمه اول', 'مشاهده نمونه‌کارها' );
		$this->text( 'primary_url', 'لینک دکمه اول', '', 'url' );
		$this->text( 'second_label', 'متن دکمه دوم', 'شروع همکاری' );
		$this->text( 'second_url', 'لینک دکمه دوم', '', 'url' );
		$this->toggle( 'compact', 'حالت کوتاه (بدون تمام‌صفحه)', false );
		$this->text( 'badge', 'نشان زیر دکمه‌ها' );

		$this->end_controls_section();

		$this->content_section( 'ویدیو پس‌زمینه', 'video' );
		$this->media( 'video', 'ویدیو دسکتاپ (MP4)', array( 'video' ) );
		$this->media( 'video_mobile', 'ویدیو موبایل (MP4)', array( 'video' ) );
		$this->media( 'poster', 'پوستر ویدیو' );
		$this->end_controls_section();

		$this->style_section( '.dani-hero' );

		$this->start_controls_section(
			'dani_hero_style',
			array(
				'label' => 'هیرو',
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'hero_min_height',
			array(
				'label'      => 'حداقل ارتفاع',
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'svh', 'vh' ),
				'range'      => array( 'px' => array( 'min' => 320, 'max' => 1200 ) ),
				'selectors'  => array( '{{WRAPPER}} .dani-hero' => 'min-height: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_control(
			'hero_overlay',
			array(
				'label'      => 'شفافیت پوشش',
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( '%' ),
				'range'      => array( '%' => array( 'min' => 0, 'max' => 100 ) ),
				'selectors'  => array( '{{WRAPPER}} .dani-hero__overlay' => 'opacity: calc({{SIZE}} / 100);' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'hero_text_typo',
				'label'    => 'تایپوگرافی توضیح',
				'selector' => '{{WRAPPER}} .dani-hero__text',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Map settings.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	protected function build_args( $s ) {
		$args = $this->map(
			$s,
			array(
				'eyebrow'       => 'eyebrow',
				'title'         => 'title',
				'highlight'     => 'highlight',
				'text'          => 'text',
				'primary_label' => 'primary_label',
				'second_label'  => 'second_label',
				'badge'         => 'badge',
			)
		);

		$args['primary_url']  = $this->link_url( $s, 'primary_url' );
		$args['second_url']   = $this->link_url( $s, 'second_url' );
		$args['video']        = $this->media_url( $s, 'video' );
		$args['video_mobile'] = $this->media_url( $s, 'video_mobile' );
		$args['poster']       = $this->media_url( $s, 'poster' );
		$args['compact']      = ! empty( $s['compact'] );

		return $args;
	}
}

/**
 * Hero that always uses a background video.
 */
class Dani_Widget_Hero_Video extends Dani_Widget_Hero {

	/**
	 * Widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'dani_hero_video';
	}

	/**
	 * Widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'هیرو ویدیویی (DaniSite)';
	}

	/**
	 * Icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-video-camera';
	}

	/**
	 * Controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		parent::register_controls();

		$this->update_control(
			'video',
			array(
				'label'       => 'ویدیو دسکتاپ (الزامی)',
				'description' => 'برای نمایش هیرو ویدیویی، یک فایل MP4 انتخاب کنید.',
			)
		);
	}
}
