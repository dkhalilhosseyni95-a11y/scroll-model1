<?php
/**
 * Elementor integration manager: category, widget registration, editor assets.
 *
 * Loads nothing when Elementor is inactive, so the plugin never breaks a site.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Elementor bootstrap.
 */
class Dani_Elementor {

	/**
	 * Widget classes, loaded on demand.
	 *
	 * @return array
	 */
	public static function widget_files() {
		return array(
			'hero'      => array( 'Dani_Widget_Hero', 'Dani_Widget_Hero_Video' ),
			'layout'    => array( 'Dani_Widget_Header', 'Dani_Widget_Navigation', 'Dani_Widget_Footer' ),
			'services'  => array( 'Dani_Widget_Services', 'Dani_Widget_Service_Cards', 'Dani_Widget_Service_Card' ),
			'portfolio' => array( 'Dani_Widget_Portfolio', 'Dani_Widget_Portfolio_Carousel', 'Dani_Widget_Portfolio_Card' ),
			'content'   => array( 'Dani_Widget_Experience', 'Dani_Widget_About', 'Dani_Widget_Workflow', 'Dani_Widget_Team', 'Dani_Widget_Testimonials', 'Dani_Widget_Stats', 'Dani_Widget_Faq', 'Dani_Widget_Cta' ),
			'blog'      => array( 'Dani_Widget_Blog', 'Dani_Widget_Gallery', 'Dani_Widget_Before_After' ),
			'elements'  => array( 'Dani_Widget_Page_Hero', 'Dani_Widget_Contact', 'Dani_Widget_Social', 'Dani_Widget_Logo', 'Dani_Widget_Button', 'Dani_Widget_Image', 'Dani_Widget_Video', 'Dani_Widget_Scroll_Animation', 'Dani_Widget_Heading' ),
		);
	}

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_category' ) );
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register_widgets' ) );
		add_action( 'elementor/preview/enqueue_styles', array( __CLASS__, 'preview_styles' ) );
	}

	/**
	 * Widget category shown in the Elementor panel.
	 *
	 * @param object $elements_manager Elementor elements manager.
	 * @return void
	 */
	public static function register_category( $elements_manager ) {
		$elements_manager->add_category(
			'danisite',
			array(
				'title' => 'دنی سایت',
				'icon'  => 'eicon-nerd',
			)
		);
	}

	/**
	 * Register every DaniSite widget.
	 *
	 * @param object $widgets_manager Elementor widgets manager.
	 * @return void
	 */
	public static function register_widgets( $widgets_manager ) {
		require_once DANI_CORE_PATH . 'includes/elementor/class-dani-widget-base.php';

		foreach ( self::widget_files() as $file => $classes ) {
			$path = DANI_CORE_PATH . 'includes/elementor/class-dani-widget-' . $file . '.php';
			if ( file_exists( $path ) ) {
				require_once $path;
			}

			foreach ( $classes as $class ) {
				if ( class_exists( $class ) ) {
					$widgets_manager->register( new $class() );
				}
			}
		}
	}

	/**
	 * Theme styles inside the Elementor editor preview.
	 *
	 * @return void
	 */
	public static function preview_styles() {
		wp_enqueue_style( 'dani-base', get_template_directory_uri() . '/assets/css/dani-base.css', array(), DANI_VERSION );
		wp_enqueue_style( 'dani-components', get_template_directory_uri() . '/assets/css/dani-components.css', array( 'dani-base' ), DANI_VERSION );
	}
}
