<?php
/**
 * Site settings: one DaniSite menu with a settings screen for every piece of
 * content the design exposes (contact details, socials, hero, footer, SEO).
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Settings screen.
 */
class Dani_Settings {

	/**
	 * Option key.
	 */
	const OPTION = 'dani_options';

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( DANI_CORE_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Field definitions grouped by tab.
	 *
	 * @return array
	 */
	public static function fields() {
		return array(
			'general' => array(
				'label'  => 'عمومی',
				'icon'   => 'dashicons-admin-settings',
				'fields' => array(
					'site_name'  => array( 'type' => 'text', 'label' => 'نام سایت', 'default' => 'DaniSite' ),
					'tagline'    => array( 'type' => 'text', 'label' => 'شعار کوتاه', 'default' => 'DaniSite — طراحی برای متمایز بودن.' ),
					'brand_desc' => array( 'type' => 'textarea', 'label' => 'توضیح کوتاه برند (فوتر)', 'default' => 'استودیوی طراحی و توسعه وب که تجربه‌های دیجیتال متمایز می‌سازد.' ),
				),
			),
			'contact' => array(
				'label'  => 'اطلاعات تماس',
				'icon'   => 'dashicons-phone',
				'fields' => array(
					'email'      => array( 'type' => 'email', 'label' => 'ایمیل', 'default' => 'info@danisite.ir' ),
					'phone'      => array( 'type' => 'text', 'label' => 'شماره تماس (نمایشی)', 'default' => '۰۹۰۰ ۰۰۰ ۰۰۰۰' ),
					'phone_link' => array( 'type' => 'tel', 'label' => 'شماره تماس (لینک tel)', 'default' => '+989000000000' ),
					'address'    => array( 'type' => 'text', 'label' => 'نشانی', 'default' => 'تهران، ایران' ),
					'hours'      => array( 'type' => 'text', 'label' => 'ساعات پاسخ‌گویی', 'default' => 'شنبه تا چهارشنبه، ۹ تا ۱۸' ),
				),
			),
			'social' => array(
				'label'  => 'شبکه‌های اجتماعی',
				'icon'   => 'dashicons-share',
				'fields' => array(
					'social_instagram' => array( 'type' => 'url', 'label' => 'اینستاگرام', 'default' => 'https://instagram.com' ),
					'social_linkedin'  => array( 'type' => 'url', 'label' => 'لینکدین', 'default' => 'https://linkedin.com' ),
					'social_telegram'  => array( 'type' => 'url', 'label' => 'تلگرام', 'default' => 'https://t.me' ),
					'social_whatsapp'  => array( 'type' => 'url', 'label' => 'واتس‌اپ', 'default' => '' ),
				),
			),
			'cta' => array(
				'label'  => 'دکمه اقدام',
				'icon'   => 'dashicons-arrow-right-alt',
				'fields' => array(
					'cta_label'   => array( 'type' => 'text', 'label' => 'متن دکمه سراسری', 'default' => 'شروع همکاری' ),
					'cta_url'     => array( 'type' => 'text', 'label' => 'لینک دکمه سراسری', 'default' => '/contact/' ),
					'footer_note' => array( 'type' => 'text', 'label' => 'متن پایین فوتر', 'default' => 'DaniSite — طراحی برای متمایز بودن.' ),
					'copyright'   => array( 'type' => 'text', 'label' => 'کپی‌رایت', 'default' => '© ۱۴۰۵ تمامی حقوق محفوظ است.' ),
				),
			),
			'hero' => array(
				'label'  => 'هیرو',
				'icon'   => 'dashicons-cover-image',
				'fields' => array(
					'hero_eyebrow'      => array( 'type' => 'text', 'label' => 'متن بالای عنوان هیرو', 'default' => 'DANISITE STUDIO · DIGITAL EXPERIENCE' ),
					'hero_video'        => array( 'type' => 'url', 'label' => 'ویدیو هیرو (MP4)', 'default' => '' ),
					'hero_video_mobile' => array( 'type' => 'url', 'label' => 'ویدیو هیرو — موبایل', 'default' => '' ),
					'hero_video_poster' => array( 'type' => 'url', 'label' => 'پوستر ویدیو هیرو', 'default' => '' ),
				),
			),
			'seo' => array(
				'label'  => 'سئو',
				'icon'   => 'dashicons-search',
				'fields' => array(
					'seo_description'  => array( 'type' => 'textarea', 'label' => 'توضیح متای پیش‌فرض', 'default' => 'استودیوی طراحی و توسعه وب دنی سایت؛ طراحی رابط کاربری، توسعه وردپرس و ساخت تجربه‌های دیجیتال متمایز.' ),
					'seo_og_image'     => array( 'type' => 'url', 'label' => 'تصویر Open Graph پیش‌فرض', 'default' => '' ),
					'seo_google'       => array( 'type' => 'text', 'label' => 'کد تأیید گوگل سرچ کنسول', 'default' => '' ),
					'seo_index_search' => array( 'type' => 'checkbox', 'label' => 'صفحات جست‌وجو ایندکس نشوند', 'default' => '1' ),
				),
			),
		);
	}

	/**
	 * Admin menu.
	 *
	 * @return void
	 */
	public static function menu() {
		add_menu_page(
			'DaniSite',
			'DaniSite',
			'manage_options',
			'dani-settings',
			array( __CLASS__, 'render_page' ),
			'dashicons-art',
			58
		);
	}

	/**
	 * Register the option and its fields.
	 *
	 * @return void
	 */
	public static function register() {
		register_setting(
			'dani_settings_group',
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => array(),
			)
		);
	}

	/**
	 * Sanitise the submitted option.
	 *
	 * @param array $input Raw input.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$input  = is_array( $input ) ? $input : array();
		$clean  = array();
		$allowed = self::allowed_fields();

		foreach ( $allowed as $key ) {
			$raw = isset( $input[ $key ] ) ? $input[ $key ] : '';

			switch ( $key ) {
				case 'seo_description':
				case 'brand_desc':
					$clean[ $key ] = sanitize_textarea_field( $raw );
					break;
				case 'email':
					$clean[ $key ] = sanitize_email( $raw );
					break;
				case 'seo_og_image':
				case 'hero_video':
				case 'hero_video_mobile':
				case 'hero_video_poster':
				case 'social_instagram':
				case 'social_linkedin':
				case 'social_telegram':
				case 'social_whatsapp':
					$clean[ $key ] = esc_url_raw( $raw );
					break;
				case 'seo_index_search':
					$clean[ $key ] = $raw ? '1' : '';
					break;
				default:
					$clean[ $key ] = sanitize_text_field( $raw );
					break;
			}
		}

		return $clean;
	}

	/**
	 * Flat list of allowed field keys.
	 *
	 * @return array
	 */
	public static function allowed_fields() {
		$keys = array();
		foreach ( self::fields() as $group ) {
			$keys = array_merge( $keys, array_keys( $group['fields'] ) );
		}

		return $keys;
	}

	/**
	 * Settings screen.
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$options = get_option( self::OPTION, array() );
		$tab     = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general';
		$groups  = self::fields();

		if ( ! isset( $groups[ $tab ] ) ) {
			$tab = 'general';
		}
		?>
		<div class="wrap dani-admin-wrap">
			<h1><?php esc_html_e( 'تنظیمات دنی سایت', 'danisite-core' ); ?></h1>
			<p class="description" style="max-width:62ch">
				<?php esc_html_e( 'این تنظیمات در هدر، فوتر، صفحه تماس و اطلاعات ساختاریافته سایت استفاده می‌شوند.', 'danisite-core' ); ?>
			</p>

			<?php if ( isset( $_GET['settings-updated'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'تنظیمات ذخیره شد.', 'danisite-core' ); ?></p></div>
			<?php endif; ?>

			<h2 class="nav-tab-wrapper">
				<?php foreach ( $groups as $key => $group ) : ?>
					<a class="nav-tab<?php echo $key === $tab ? ' nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=dani-settings&tab=' . $key ) ); ?>"><?php echo esc_html( $group['label'] ); ?></a>
				<?php endforeach; ?>
			</h2>

			<form action="<?php echo esc_url( admin_url( 'options.php' ) ); ?>" method="post">
				<?php settings_fields( 'dani_settings_group' ); ?>
				<table class="form-table" role="presentation"><tbody>
					<?php foreach ( $groups[ $tab ]['fields'] as $key => $field ) : ?>
						<?php $value = isset( $options[ $key ] ) ? $options[ $key ] : ( isset( $field['default'] ) ? $field['default'] : '' ); ?>
						<tr>
							<th scope="row"><label for="dani-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
							<td>
								<?php if ( 'textarea' === $field['type'] ) : ?>
									<textarea class="large-text" rows="4" id="dani-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( self::OPTION . '[' . $key . ']' ); ?>"><?php echo esc_textarea( (string) $value ); ?></textarea>
								<?php elseif ( 'checkbox' === $field['type'] ) : ?>
									<label>
										<input type="checkbox" id="dani-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( self::OPTION . '[' . $key . ']' ); ?>" value="1" <?php checked( (string) $value, '1' ); ?>>
										<?php esc_html_e( 'فعال', 'danisite-core' ); ?>
									</label>
								<?php else : ?>
									<input class="regular-text" type="<?php echo esc_attr( 'email' === $field['type'] ? 'email' : ( 'tel' === $field['type'] ? 'tel' : ( 'url' === $field['type'] ? 'url' : 'text' ) ) ); ?>"
										id="dani-<?php echo esc_attr( $key ); ?>"
										name="<?php echo esc_attr( self::OPTION . '[' . $key . ']' ); ?>"
										value="<?php echo esc_attr( (string) $value ); ?>"
										<?php echo in_array( $field['type'], array( 'url', 'tel', 'email' ), true ) ? 'dir="ltr"' : ''; ?>>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody></table>
				<?php submit_button( __( 'ذخیره تنظیمات', 'danisite-core' ) ); ?>
			</form>

			<hr>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=dani-importer' ) ); ?>"><?php esc_html_e( 'راه‌اندازی و درون‌ریزی سایت', 'danisite-core' ); ?></a>
				<a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'مشاهده سایت', 'danisite-core' ); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Settings link on the plugins screen.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public static function action_links( $links ) {
		$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=dani-settings' ) ) . '">' . esc_html__( 'تنظیمات', 'danisite-core' ) . '</a>';

		return $links;
	}
}
