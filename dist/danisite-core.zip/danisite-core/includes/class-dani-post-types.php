<?php
/**
 * Custom post types and taxonomies.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers every DaniSite content type.
 */
class Dani_Post_Types {

	/**
	 * Hook registration.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_filter( 'use_block_editor_for_post_type', array( __CLASS__, 'disable_block_editor' ), 10, 2 );
		add_action( 'add_meta_boxes', array( __CLASS__, 'featured_image_box' ) );
	}

	/**
	 * Register the post types.
	 *
	 * @return void
	 */
	public static function register() {
		self::register_service();
		self::register_project();
		self::register_team();
		self::register_testimonial();
		self::register_faq();

		register_taxonomy(
			'dani_project_cat',
			array( 'dani_project' ),
			array(
				'labels'            => array(
					'name'          => 'دسته‌بندی نمونه‌کارها',
					'singular_name' => 'دسته نمونه‌کار',
					'add_new_item'  => 'افزودن دسته نمونه‌کار',
					'edit_item'     => 'ویرایش دسته نمونه‌کار',
					'search_items'  => 'جست‌وجوی دسته‌ها',
				),
				'public'            => true,
				'hierarchical'      => true,
				'show_admin_column' => true,
				'show_in_rest'      => true,
				'rewrite'           => array( 'slug' => 'portfolio-category', 'with_front' => false ),
			)
		);
	}

	/**
	 * Shared arguments for repeatable content types.
	 *
	 * @param string $singular Singular label.
	 * @param string $plural   Plural label.
	 * @param array  $extra    Overrides.
	 * @return array
	 */
	private static function args( $singular, $plural, $extra = array() ) {
		return array_merge(
			array(
				'labels'       => array(
					'name'               => $plural,
					'singular_name'      => $singular,
					'add_new_item'       => 'افزودن ' . $singular,
					'edit_item'          => 'ویرایش ' . $singular,
					'new_item'           => $singular . ' جدید',
					'view_item'          => 'نمایش ' . $singular,
					'search_items'       => 'جست‌وجوی ' . $plural,
					'not_found'          => 'موردی یافت نشد',
					'not_found_in_trash' => 'در زباله‌دان یافت نشد',
					'all_items'          => 'همه ' . $plural,
					'menu_name'          => $plural,
				),
				'public'       => true,
				'has_archive'  => false,
				'show_in_rest' => true,
				'menu_position' => 21,
				'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes', 'thumbnail' ),
				'rewrite'      => array( 'with_front' => false ),
			),
			$extra
		);
	}

	/**
	 * Services.
	 *
	 * @return void
	 */
	private static function register_service() {
		register_post_type(
			'dani_service',
			self::args(
				'خدمت',
				'خدمات',
				array(
					'menu_icon'   => 'dashicons-lightbulb',
					'has_archive' => true,
					'rewrite'     => array( 'slug' => 'services', 'with_front' => false ),
				)
			)
		);
	}

	/**
	 * Portfolio projects.
	 *
	 * @return void
	 */
	private static function register_project() {
		register_post_type(
			'dani_project',
			self::args(
				'نمونه‌کار',
				'نمونه‌کارها',
				array(
					'menu_icon'   => 'dashicons-portfolio',
					'has_archive' => true,
					'rewrite'     => array( 'slug' => 'portfolio', 'with_front' => false ),
				)
			)
		);
	}

	/**
	 * Team members.
	 *
	 * @return void
	 */
	private static function register_team() {
		register_post_type(
			'dani_team',
			self::args(
				'عضو تیم',
				'اعضای تیم',
				array(
					'menu_icon' => 'dashicons-groups',
					'rewrite'   => array( 'slug' => 'team', 'with_front' => false ),
				)
			)
		);
	}

	/**
	 * Client testimonials.
	 *
	 * @return void
	 */
	private static function register_testimonial() {
		register_post_type(
			'dani_quote',
			self::args(
				'نظر مشتری',
				'نظرات مشتریان',
				array(
					'menu_icon'           => 'dashicons-format-quote',
					'exclude_from_search' => true,
					'rewrite'             => array( 'slug' => 'testimonials', 'with_front' => false ),
				)
			)
		);
	}

	/**
	 * FAQ entries.
	 *
	 * @return void
	 */
	private static function register_faq() {
		register_post_type(
			'dani_faq',
			self::args(
				'پرسش متداول',
				'پرسش‌های متداول',
				array(
					'menu_icon'           => 'dashicons-editor-help',
					'exclude_from_search' => true,
					'supports'            => array( 'title', 'editor', 'page-attributes' ),
					'rewrite'             => array( 'slug' => 'faq-item', 'with_front' => false ),
				)
			)
		);
	}

	/**
	 * These content types are structured records, so the classic editor keeps
	 * their fields predictable (Elementor is enabled for pages only).
	 *
	 * @param bool   $use_block_editor Whether to use the block editor.
	 * @param string $post_type        Post type name.
	 * @return bool
	 */
	public static function disable_block_editor( $use_block_editor, $post_type ) {
		$types = array( 'dani_service', 'dani_project', 'dani_team', 'dani_quote', 'dani_faq' );

		return in_array( $post_type, $types, true ) ? false : $use_block_editor;
	}

	/**
	 * Make sure the featured image panel is visible for records that use it.
	 *
	 * @return void
	 */
	public static function featured_image_box() {
		$types = array( 'dani_project', 'dani_team', 'dani_service' );
		foreach ( $types as $type ) {
			add_post_type_support( $type, 'thumbnail' );
		}
	}
}
