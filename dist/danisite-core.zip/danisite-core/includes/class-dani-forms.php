<?php
/**
 * Contact form: styled markup, nonce-protected handler, spam guard, stored
 * submissions and email notification.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Contact form handling.
 */
class Dani_Forms {

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_messages' ) );
		add_action( 'admin_post_dani_contact', array( __CLASS__, 'handle' ) );
		add_action( 'admin_post_nopriv_dani_contact', array( __CLASS__, 'handle' ) );
	}

	/**
	 * Store submissions so nothing is lost if email fails.
	 *
	 * @return void
	 */
	public static function register_messages() {
		register_post_type(
			'dani_message',
			array(
				'labels'          => array(
					'name'          => 'پیام‌های تماس',
					'singular_name' => 'پیام تماس',
					'menu_name'     => 'پیام‌های تماس',
					'edit_item'     => 'مشاهده پیام',
					'all_items'     => 'پیام‌های تماس',
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => 'dani-settings',
				'capability_type' => 'post',
				'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
				'map_meta_cap'    => true,
				'supports'        => array( 'title', 'editor' ),
				'menu_icon'       => 'dashicons-email-alt',
			)
		);
	}

	/**
	 * The contact form markup.
	 *
	 * @return string
	 */
	public static function form() {
		$status  = isset( $_GET['dani_contact'] ) ? sanitize_key( wp_unslash( $_GET['dani_contact'] ) ) : '';
		$error   = isset( $_GET['dani_error'] ) ? sanitize_key( wp_unslash( $_GET['dani_error'] ) ) : '';

		$html = '';

		if ( 'success' === $status ) {
			$html .= '<div class="dani-notice dani-notice--success" role="status">پیام شما ارسال شد. به‌زودی پاسخ می‌دهیم.</div>';
		} elseif ( 'error' === $status ) {
			$messages = array(
				'invalid'  => 'اطلاعات وارد‌شده کامل یا معتبر نیست. لطفاً فیلدهای ضروری را بررسی کنید.',
				'email'    => 'ایمیل وارد‌شده معتبر نیست.',
				'nonce'    => 'نشست شما منقضی شده است. صفحه را تازه کنید و دوباره تلاش کنید.',
				'spam'     => 'ارسال شما به‌عنوان هرزنامه شناسایی شد.',
				'throttle' => 'تعداد ارسال‌ها زیاد است. چند دقیقه بعد دوباره تلاش کنید.',
				'send'     => 'ارسال پیام با خطا مواجه شد. لطفاً از طریق ایمیل مستقیم تماس بگیرید.',
			);
			$text     = isset( $messages[ $error ] ) ? $messages[ $error ] : $messages['invalid'];
			$html    .= '<div class="dani-notice dani-notice--error" role="alert">' . esc_html( $text ) . '</div>';
		}

		$html .= '<form class="dani-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		$html .= '<input type="hidden" name="action" value="dani_contact">';
		$html .= wp_nonce_field( 'dani_contact_form', 'dani_contact_nonce', true, false );
		$html .= '<input type="hidden" name="dani_referer" value="' . esc_url( wp_get_referer() ? wp_get_referer() : home_url( '/' ) ) . '">';

		$html .= '<div class="dani-hp" aria-hidden="true"><label for="dani-website">وب‌سایت</label><input type="text" id="dani-website" name="dani_website" tabindex="-1" autocomplete="off"></div>';

		$html .= '<div class="dani-field"><label class="dani-field__label" for="dani-name">نام و نام خانوادگی <span>*</span></label>';
		$html .= '<input class="dani-input" type="text" id="dani-name" name="dani_name" required maxlength="80" autocomplete="name"></div>';

		$html .= '<div class="dani-form__row dani-form__row--2">';
		$html .= '<div class="dani-field"><label class="dani-field__label" for="dani-email">ایمیل <span>*</span></label>';
		$html .= '<input class="dani-input" type="email" id="dani-email" name="dani_email" required maxlength="120" dir="ltr" autocomplete="email"></div>';
		$html .= '<div class="dani-field"><label class="dani-field__label" for="dani-phone">شماره تماس</label>';
		$html .= '<input class="dani-input" type="tel" id="dani-phone" name="dani_phone" maxlength="30" dir="ltr" autocomplete="tel"></div>';
		$html .= '</div>';

		$html .= '<div class="dani-field"><label class="dani-field__label" for="dani-subject">موضوع</label>';
		$html .= '<select class="dani-select" id="dani-subject" name="dani_subject">';
		foreach ( array( 'طراحی و توسعه وب‌سایت', 'طراحی رابط و تجربه کاربری', 'فروشگاه اینترنتی', 'بهینه‌سازی سرعت و سئو', 'همکاری و مشاوره', 'سایر' ) as $option ) {
			$html .= '<option value="' . esc_attr( $option ) . '">' . esc_html( $option ) . '</option>';
		}
		$html .= '</select></div>';

		$html .= '<div class="dani-field"><label class="dani-field__label" for="dani-message">توضیح پروژه <span>*</span></label>';
		$html .= '<textarea class="dani-textarea" id="dani-message" name="dani_message" required maxlength="4000" rows="6"></textarea></div>';

		$html .= '<p class="dani-form__hint">با ارسال این فرم، با تماس تیم دنی سایت درباره پروژه‌تان موافقت می‌کنید. اطلاعات شما منتشر نمی‌شود.</p>';
		$html .= '<button type="submit" class="dani-btn dani-btn--primary dani-btn--lg dani-form__submit">ارسال درخواست' . dani_icon( 'arrow-left' ) . '</button>';
		$html .= '</form>';

		return $html;
	}

	/**
	 * Handle the submission.
	 *
	 * @return void
	 */
	public static function handle() {
		$referer = isset( $_POST['dani_referer'] ) ? esc_url_raw( wp_unslash( $_POST['dani_referer'] ) ) : home_url( '/' );
		$back    = $referer ? $referer : home_url( '/' );

		if ( ! isset( $_POST['dani_contact_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['dani_contact_nonce'] ) ), 'dani_contact_form' ) ) {
			self::redirect( $back, 'error', 'nonce' );
		}

		// Honeypot: real visitors never fill this field.
		if ( ! empty( $_POST['dani_website'] ) ) {
			self::redirect( $back, 'error', 'spam' );
		}

		$name    = isset( $_POST['dani_name'] ) ? sanitize_text_field( wp_unslash( $_POST['dani_name'] ) ) : '';
		$email   = isset( $_POST['dani_email'] ) ? sanitize_email( wp_unslash( $_POST['dani_email'] ) ) : '';
		$phone   = isset( $_POST['dani_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['dani_phone'] ) ) : '';
		$subject = isset( $_POST['dani_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['dani_subject'] ) ) : '';
		$message = isset( $_POST['dani_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['dani_message'] ) ) : '';

		if ( '' === $name || '' === $message ) {
			self::redirect( $back, 'error', 'invalid' );
		}
		if ( ! is_email( $email ) ) {
			self::redirect( $back, 'error', 'email' );
		}

		$key = 'dani_throttle_' . md5( self::client_ip() );
		if ( get_transient( $key ) ) {
			self::redirect( $back, 'error', 'throttle' );
		}
		set_transient( $key, 1, 60 );

		$post_id = wp_insert_post(
			array(
				'post_type'    => 'dani_message',
				'post_status'  => 'private',
				'post_title'   => sprintf( '%s — %s', $name, $subject ? $subject : 'تماس' ),
				'post_content' => $message . "\n\n" . sprintf( 'ایمیل: %s', $email ) . "\n" . sprintf( 'تلفن: %s', $phone ),
				'meta_input'   => array(
					'_dani_email'   => $email,
					'_dani_phone'   => $phone,
					'_dani_subject' => $subject,
				),
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			self::redirect( $back, 'error', 'send' );
		}

		$to      = dani_option( 'email', get_option( 'admin_email' ) );
		$body    = "پیام جدید از فرم تماس سایت:\n\n";
		$body   .= "نام: {$name}\nایمیل: {$email}\nتلفن: {$phone}\nموضوع: {$subject}\n\n{$message}\n";
		$headers = array( 'Content-Type: text/plain; charset=UTF-8' );

		if ( is_email( $email ) ) {
			$headers[] = 'Reply-To: ' . $name . ' <' . $email . '>';
		}

		wp_mail( $to, 'پیام جدید فرم تماس — ' . get_bloginfo( 'name' ), $body, $headers );

		self::redirect( $back, 'success' );
	}

	/**
	 * Redirect back with a status flag.
	 *
	 * @param string $url     Destination.
	 * @param string $status  success|error.
	 * @param string $code    Error code.
	 * @return void
	 */
	private static function redirect( $url, $status, $code = '' ) {
		$args = array( 'dani_contact' => $status );
		if ( $code ) {
			$args['dani_error'] = $code;
		}

		wp_safe_redirect( add_query_arg( $args, $url ) . '#contact' );
		exit;
	}

	/**
	 * Hashed client IP for throttling only (never stored as-is).
	 *
	 * @return string
	 */
	private static function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		return $ip ? wp_hash( $ip ) : 'unknown';
	}
}
