<?php
/**
 * Shortcodes that expose every designed section to the classic editor and act
 * as the Elementor-independent fallback for imported pages.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shortcode registration.
 */
class Dani_Shortcodes {

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		$map = array(
			'dani_home'              => array( 'Dani_Sections', 'render_home' ),
			'dani_hero'              => array( 'Dani_Sections', 'render_hero' ),
			'dani_services'          => array( 'Dani_Sections', 'render_services' ),
			'dani_service_cards'     => array( 'Dani_Sections', 'render_service_cards' ),
			'dani_experience'        => array( 'Dani_Sections', 'render_experience' ),
			'dani_portfolio'         => array( 'Dani_Sections', 'render_portfolio' ),
			'dani_portfolio_carousel' => array( 'Dani_Sections', 'render_portfolio_carousel' ),
			'dani_about'             => array( 'Dani_Sections', 'render_about' ),
			'dani_workflow'          => array( 'Dani_Sections', 'render_workflow' ),
			'dani_team'              => array( 'Dani_Sections', 'render_team' ),
			'dani_testimonials'      => array( 'Dani_Sections', 'render_testimonials' ),
			'dani_stats'             => array( 'Dani_Sections', 'render_stats' ),
			'dani_faq'               => array( 'Dani_Sections', 'render_faq' ),
			'dani_cta'               => array( 'Dani_Sections', 'render_cta' ),
			'dani_blog'              => array( 'Dani_Sections', 'render_blog' ),
			'dani_contact'           => array( 'Dani_Sections', 'render_contact' ),
			'dani_gallery'           => array( 'Dani_Sections', 'render_gallery' ),
			'dani_before_after'      => array( 'Dani_Sections', 'render_before_after' ),
			'dani_scroll'            => array( 'Dani_Sections', 'render_scroll_animation' ),
		);

		foreach ( $map as $tag => $callback ) {
			add_shortcode(
				$tag,
				function ( $atts = array(), $content = '' ) use ( $callback ) {
					$atts = is_array( $atts ) ? $atts : array();

					return call_user_func( $callback, self::normalise( $atts ) );
				}
			);
		}
	}

	/**
	 * Convert shortcode attributes to renderer arguments.
	 *
	 * @param array $atts Attributes.
	 * @return array
	 */
	private static function normalise( $atts ) {
		$args = array();

		foreach ( $atts as $key => $value ) {
			if ( '' === $value ) {
				continue;
			}
			switch ( $key ) {
				case 'limit':
				case 'columns':
				case 'delay':
					$args[ $key ] = absint( $value );
					break;
				case 'surface':
				case 'center':
				case 'filters':
				case 'compact':
				case 'button':
					$args[ $key ] = ( '0' !== (string) $value && 'false' !== $value );
					break;
				default:
					$args[ $key ] = sanitize_text_field( $value );
					break;
			}
		}

		return $args;
	}
}
