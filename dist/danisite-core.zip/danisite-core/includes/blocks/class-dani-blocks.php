<?php
/**
 * Shared markup atoms used by sections, shortcodes and Elementor widgets.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Markup primitives.
 */
class Dani_Blocks {

	/**
	 * Render an atom.
	 *
	 * @param string $type Atom type.
	 * @param array  $args Arguments.
	 * @return string
	 */
	public static function render( $type, $args = array() ) {
		$method = 'render_' . str_replace( '-', '_', $type );

		if ( ! method_exists( __CLASS__, $method ) ) {
			return '';
		}

		return (string) call_user_func( array( __CLASS__, $method ), (array) $args );
	}

	/**
	 * Icon markup with an optional wrapper.
	 *
	 * @param array $args name, class, size.
	 * @return string
	 */
	public static function render_icon( $args = array() ) {
		$name = isset( $args['name'] ) ? $args['name'] : 'sparkles';

		return dani_icon( $name, array( 'class' => isset( $args['class'] ) ? $args['class'] : '' ) );
	}

	/**
	 * Section heading.
	 *
	 * @param array $args eyebrow, title, text, center, tag, class.
	 * @return string
	 */
	public static function render_head( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => '',
				'title'   => '',
				'text'    => '',
				'center'  => false,
				'tag'     => 'h2',
				'class'   => '',
			)
		);

		$tag = preg_match( '/^h[1-6]$/', $args['tag'] ) ? $args['tag'] : 'h2';

		$html  = '<div class="dani-head' . ( $args['center'] ? ' dani-head--center' : '' ) . ( $args['class'] ? ' ' . esc_attr( $args['class'] ) : '' ) . '">';
		$html .= $args['eyebrow'] ? '<p class="dani-eyebrow">' . esc_html( $args['eyebrow'] ) . '</p>' : '';
		$html .= $args['title'] ? '<' . $tag . ' class="dani-head__title">' . esc_html( $args['title'] ) . '</' . $tag . '>' : '';
		$html .= $args['text'] ? '<p class="dani-head__text">' . esc_html( $args['text'] ) . '</p>' : '';
		$html .= '</div>';

		return $html;
	}

	/**
	 * Pill button.
	 *
	 * @param array $args label, url, variant, size, class, icon, target.
	 * @return string
	 */
	public static function render_button( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'label'   => '',
				'url'     => '',
				'variant' => 'primary',
				'size'    => 'md',
				'class'   => '',
				'icon'    => '',
				'icon_pos' => 'start',
				'target'  => '',
				'rel'     => '',
			)
		);

		if ( '' === $args['label'] ) {
			return '';
		}

		$variant = in_array( $args['variant'], array( 'primary', 'ghost', 'glass' ), true ) ? $args['variant'] : 'primary';
		$class   = 'dani-btn dani-btn--' . $variant . ( 'lg' === $args['size'] ? ' dani-btn--lg' : '' );
		if ( $args['class'] ) {
			$class .= ' ' . $args['class'];
		}

		$icon = $args['icon'] ? dani_icon( $args['icon'] ) : '';

		return sprintf(
			'<a class="%1$s" href="%2$s"%3$s>%4$s<span>%5$s</span>%6$s</a>',
			esc_attr( $class ),
			esc_url( $args['url'] ? $args['url'] : '#' ),
			$args['target'] ? ' target="' . esc_attr( $args['target'] ) . '" rel="' . esc_attr( $args['rel'] ? $args['rel'] : 'noopener noreferrer' ) . '"' : '',
			'start' === $args['icon_pos'] ? $icon : '',
			esc_html( $args['label'] ),
			'end' === $args['icon_pos'] ? $icon : ''
		);
	}

	/**
	 * Numbered service row.
	 *
	 * @param array $args item, index.
	 * @return string
	 */
	public static function render_service_row( $args = array() ) {
		$item  = isset( $args['item'] ) ? $args['item'] : array();
		$index = isset( $args['index'] ) ? (int) $args['index'] : 1;
		$num   = isset( $item['n'] ) ? $item['n'] : dani_fa_number( str_pad( (string) $index, 2, '0', STR_PAD_LEFT ) );

		$html  = '<li class="dani-service-row dani-reveal" data-dani-delay="' . esc_attr( (string) ( ( $index - 1 ) * 60 ) ) . '">';
		$html .= '<a class="dani-service-row__link" href="' . esc_url( isset( $item['url'] ) ? $item['url'] : '#' ) . '">';
		$html .= '<span class="dani-service-row__num">' . esc_html( $num ) . '</span>';
		$html .= '<span class="dani-service-row__body">';
		$html .= '<span class="dani-service-row__title" style="display:block">' . esc_html( isset( $item['title'] ) ? $item['title'] : '' ) . '</span>';
		if ( ! empty( $item['desc'] ) ) {
			$html .= '<span class="dani-service-row__desc" style="display:block">' . esc_html( $item['desc'] ) . '</span>';
		}
		$html .= '</span>';
		$html .= dani_icon( 'arrow-left', array( 'class' => 'dani-service-row__arrow' ) );
		$html .= '</a></li>';

		return $html;
	}

	/**
	 * Service card.
	 *
	 * @param array $args item.
	 * @return string
	 */
	public static function render_service_card( $args = array() ) {
		$item = isset( $args['item'] ) ? $args['item'] : $args;
		$icon = isset( $item['icon'] ) && $item['icon'] ? $item['icon'] : 'sparkles';

		$html  = '<article class="dani-card dani-reveal">';
		$html .= '<span class="dani-card__icon">' . dani_icon( $icon ) . '</span>';
		$html .= '<h3 class="dani-card__title"><a href="' . esc_url( isset( $item['url'] ) ? $item['url'] : '#' ) . '">' . esc_html( isset( $item['title'] ) ? $item['title'] : '' ) . '</a></h3>';
		if ( ! empty( $item['desc'] ) ) {
			$html .= '<p class="dani-card__text">' . esc_html( $item['desc'] ) . '</p>';
		}
		if ( ! empty( $item['features'] ) ) {
			$html .= '<ul class="dani-card__list" style="display:grid;gap:.4rem;font-size:.8125rem;color:var(--muted-foreground)">';
			foreach ( (array) $item['features'] as $feature ) {
				$html .= '<li style="display:flex;gap:.45rem;align-items:flex-start">' . dani_icon( 'check' ) . '<span>' . esc_html( $feature ) . '</span></li>';
			}
			$html .= '</ul>';
		}
		if ( ! empty( $item['price'] ) ) {
			$html .= '<p class="dani-card__price">' . esc_html( $item['price'] ) . '</p>';
		}
		$html .= '<a class="dani-card__link" href="' . esc_url( isset( $item['url'] ) ? $item['url'] : '#' ) . '">' . esc_html( isset( $args['link_label'] ) ? $args['link_label'] : 'جزئیات خدمت' ) . dani_icon( 'arrow-left' ) . '</a>';
		$html .= '</article>';

		return $html;
	}

	/**
	 * Portfolio project card.
	 *
	 * @param array $args item, span, offset, aspect.
	 * @return string
	 */
	public static function render_project_card( $args = array() ) {
		$item   = isset( $args['item'] ) ? $args['item'] : array();
		$ratio  = ! empty( $item['ratio'] ) ? $item['ratio'] : '4-3';
		$span   = isset( $args['span'] ) ? (int) $args['span'] : 0;
		$offset = isset( $args['offset'] ) ? (string) $args['offset'] : '';

		$classes = array( 'dani-project', 'dani-reveal' );
		if ( $span ) {
			$classes[] = 'dani-project--span-' . $span;
		}
		if ( '24' === $offset ) {
			$classes[] = 'dani-project--offset-24';
		}
		if ( '32' === $offset ) {
			$classes[] = 'dani-project--offset-32';
		}
		if ( ! empty( $args['center'] ) ) {
			$classes[] = 'dani-project--start-2';
		}

		$html  = '<article class="' . esc_attr( implode( ' ', $classes ) ) . '">';
		$html .= '<a class="dani-project__link" href="' . esc_url( isset( $item['url'] ) ? $item['url'] : '#' ) . '" aria-label="' . esc_attr( isset( $item['title'] ) ? $item['title'] : '' ) . '">';
		$html .= '<div class="dani-project__media dani-project__aspect-' . esc_attr( $ratio ) . '">';
		if ( ! empty( $item['thumb'] ) ) {
			$html .= '<img src="' . esc_url( $item['thumb'] ) . '" alt="' . esc_attr( sprintf( 'پیش‌نمایش %s', isset( $item['title'] ) ? $item['title'] : '' ) ) . '" loading="lazy" decoding="async" width="1200" height="900">';
		} else {
			$html .= '<span class="dani-post__media--empty">' . dani_icon( 'image' ) . '</span>';
		}
		if ( ! empty( $item['category'] ) ) {
			$html .= '<span class="dani-glass dani-project__badge">' . esc_html( $item['category'] ) . '</span>';
		}
		$html .= '<span class="dani-project__go" aria-hidden="true">' . dani_icon( 'arrow-up-left' ) . '</span>';
		$html .= '</div>';
		$html .= '<div class="dani-project__foot"><div>';
		$html .= '<h3 class="dani-project__title">' . esc_html( isset( $item['title'] ) ? $item['title'] : '' ) . '</h3>';
		if ( ! empty( $item['desc'] ) ) {
			$html .= '<p class="dani-project__desc">' . esc_html( $item['desc'] ) . '</p>';
		}
		$html .= '</div>';
		if ( ! empty( $item['client'] ) ) {
			$html .= '<span class="dani-project__cat">' . esc_html( $item['client'] ) . '</span>';
		}
		$html .= '</div></a></article>';

		return $html;
	}

	/**
	 * Blog post card.
	 *
	 * @param array $args item.
	 * @return string
	 */
	public static function render_post_card( $args = array() ) {
		$item = isset( $args['item'] ) ? $args['item'] : array();

		$html  = '<article class="dani-post">';
		$html .= '<a class="dani-post__media' . ( empty( $item['thumb'] ) ? ' dani-post__media--empty' : '' ) . '" href="' . esc_url( isset( $item['url'] ) ? $item['url'] : '#' ) . '" tabindex="-1" aria-hidden="true">';
		$html .= ! empty( $item['thumb'] )
			? '<img src="' . esc_url( $item['thumb'] ) . '" alt="' . esc_attr( isset( $item['title'] ) ? $item['title'] : '' ) . '" loading="lazy" decoding="async" width="800" height="500">'
			: dani_icon( 'image' );
		$html .= '</a>';
		$html .= '<div class="dani-post__body">';
		$html .= '<div class="dani-post__meta">';
		if ( ! empty( $item['date'] ) ) {
			$html .= '<span>' . esc_html( $item['date'] ) . '</span>';
		}
		if ( ! empty( $item['cat'] ) ) {
			$html .= '<span aria-hidden="true">·</span><span class="dani-post__cat">' . esc_html( $item['cat'] ) . '</span>';
		}
		$html .= '</div>';
		$html .= '<h3 class="dani-post__title"><a href="' . esc_url( isset( $item['url'] ) ? $item['url'] : '#' ) . '">' . esc_html( isset( $item['title'] ) ? $item['title'] : '' ) . '</a></h3>';
		if ( ! empty( $item['excerpt'] ) ) {
			$html .= '<p class="dani-post__excerpt">' . esc_html( $item['excerpt'] ) . '</p>';
		}
		$html .= '<a class="dani-post__more" href="' . esc_url( isset( $item['url'] ) ? $item['url'] : '#' ) . '">ادامه مطلب' . dani_icon( 'arrow-left' ) . '</a>';
		$html .= '</div></article>';

		return $html;
	}

	/**
	 * Team member card.
	 *
	 * @param array $args item.
	 * @return string
	 */
	public static function render_member( $args = array() ) {
		$item = isset( $args['item'] ) ? $args['item'] : array();

		$html  = '<article class="dani-member dani-reveal">';
		$html .= '<div class="dani-member__photo">';
		if ( ! empty( $item['thumb'] ) ) {
			$html .= '<img src="' . esc_url( $item['thumb'] ) . '" alt="' . esc_attr( isset( $item['title'] ) ? $item['title'] : '' ) . '" loading="lazy" decoding="async" width="800" height="1000">';
		}
		$html .= '</div><div class="dani-member__body">';
		$html .= '<h3 class="dani-member__name">' . esc_html( isset( $item['title'] ) ? $item['title'] : '' ) . '</h3>';
		if ( ! empty( $item['role'] ) ) {
			$html .= '<p class="dani-member__role">' . esc_html( $item['role'] ) . '</p>';
		}
		if ( ! empty( $item['desc'] ) ) {
			$html .= '<p class="dani-member__bio">' . esc_html( $item['desc'] ) . '</p>';
		}
		$socials = array(
			'instagram' => 'instagram',
			'linkedin'  => 'linkedin',
			'x'         => 'x-social',
		);
		$links = '';
		foreach ( $socials as $key => $icon ) {
			if ( ! empty( $item[ $key ] ) ) {
				$links .= '<a href="' . esc_url( $item[ $key ] ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr( $key ) . '">' . dani_icon( $icon ) . '</a>';
			}
		}
		if ( $links ) {
			$html .= '<div class="dani-member__socials">' . $links . '</div>';
		}
		$html .= '</div></article>';

		return $html;
	}

	/**
	 * Single testimonial slide.
	 *
	 * @param array $args item, index.
	 * @return string
	 */
	public static function render_quote( $args = array() ) {
		$item  = isset( $args['item'] ) ? $args['item'] : array();
		$index = isset( $args['index'] ) ? (int) $args['index'] : 0;

		$meta = array_filter( array( isset( $item['author'] ) ? $item['author'] : '', isset( $item['role'] ) ? $item['role'] : '' ) );

		$html  = '<figure class="dani-quotes__figure" data-dani-quote' . ( $index > 0 ? ' hidden' : '' ) . '>';
		$html .= '<span class="dani-quotes__mark dani-gradient-text" aria-hidden="true">«</span>';
		$html .= '<blockquote class="dani-quotes__text">' . esc_html( isset( $item['text'] ) ? $item['text'] : '' ) . '</blockquote>';
		$html .= '<figcaption class="dani-quotes__meta">' . esc_html( implode( ' · ', $meta ) ) . '</figcaption>';
		$html .= '</figure>';

		return $html;
	}

	/**
	 * FAQ item.
	 *
	 * @param array $args item, index, open.
	 * @return string
	 */
	public static function render_faq_item( $args = array() ) {
		$item  = isset( $args['item'] ) ? $args['item'] : array();
		$id    = 'dani-faq-' . wp_rand( 1000, 9999 );
		$open  = ! empty( $args['open'] );

		$html  = '<div class="dani-faq__item' . ( $open ? ' is-open' : '' ) . '">';
		$html .= '<button type="button" class="dani-faq__q" aria-expanded="' . ( $open ? 'true' : 'false' ) . '" aria-controls="' . esc_attr( $id ) . '">';
		$html .= '<span>' . esc_html( isset( $item['question'] ) ? $item['question'] : '' ) . '</span>';
		$html .= '<span class="dani-faq__icon" aria-hidden="true">' . dani_icon( 'plus' ) . '</span>';
		$html .= '</button>';
		$html .= '<div class="dani-faq__a" id="' . esc_attr( $id ) . '"><div class="dani-faq__a-inner"><p>' . esc_html( isset( $item['answer'] ) ? $item['answer'] : '' ) . '</p></div></div>';
		$html .= '</div>';

		return $html;
	}

	/**
	 * Statistic.
	 *
	 * @param array $args item.
	 * @return string
	 */
	public static function render_stat( $args = array() ) {
		$item = isset( $args['item'] ) ? $args['item'] : array();

		return '<div class="dani-stat dani-reveal"><p class="dani-stat__num dani-gradient-text">' . esc_html( isset( $item['value'] ) ? $item['value'] : '' ) . '</p><p class="dani-stat__label">' . esc_html( isset( $item['label'] ) ? $item['label'] : '' ) . '</p></div>';
	}

	/**
	 * Social link chip.
	 *
	 * @param array $args item.
	 * @return string
	 */
	public static function render_social( $args = array() ) {
		$item = isset( $args['item'] ) ? $args['item'] : array();

		return sprintf(
			'<a class="dani-social" href="%1$s" target="_blank" rel="noopener noreferrer">%2$s<span>%3$s</span></a>',
			esc_url( isset( $item['url'] ) ? $item['url'] : '#' ),
			dani_icon( isset( $item['icon'] ) ? $item['icon'] : 'globe' ),
			esc_html( isset( $item['label'] ) ? $item['label'] : '' )
		);
	}

	/**
	 * Gallery item.
	 *
	 * @param array $args image, alt, wide.
	 * @return string
	 */
	public static function render_gallery_item( $args = array() ) {
		$image = isset( $args['image'] ) ? $args['image'] : '';
		$alt   = isset( $args['alt'] ) ? $args['alt'] : '';

		$html  = '<figure class="dani-gallery__item' . ( ! empty( $args['wide'] ) ? ' dani-gallery__item--wide' : '' ) . '">';
		$html .= '<img src="' . esc_url( $image ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy" decoding="async" width="800" height="600">';
		$html .= '</figure>';

		return $html;
	}

	/**
	 * Before / after comparison.
	 *
	 * @param array $args before, after, before_label, after_label, alt.
	 * @return string
	 */
	public static function render_before_after( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'before'       => '',
				'after'        => '',
				'before_label' => 'قبل',
				'after_label'  => 'بعد',
				'alt'          => 'مقایسه قبل و بعد',
			)
		);

		if ( ! $args['before'] || ! $args['after'] ) {
			return '<p class="dani-editor-placeholder">تصاویر قبل و بعد را انتخاب کنید.</p>';
		}

		$html  = '<div class="dani-ba" data-dani-ba>';
		$html .= '<img src="' . esc_url( $args['before'] ) . '" alt="' . esc_attr( $args['alt'] . ' — ' . $args['before_label'] ) . '" loading="lazy" decoding="async">';
		$html .= '<div class="dani-ba__after"><img src="' . esc_url( $args['after'] ) . '" alt="' . esc_attr( $args['alt'] . ' — ' . $args['after_label'] ) . '" loading="lazy" decoding="async"></div>';
		$html .= '<span class="dani-glass dani-ba__label dani-ba__label--before">' . esc_html( $args['before_label'] ) . '</span>';
		$html .= '<span class="dani-glass dani-ba__label dani-ba__label--after">' . esc_html( $args['after_label'] ) . '</span>';
		$html .= '<div class="dani-ba__handle"><span class="dani-ba__knob">' . dani_icon( 'sliders' ) . '</span></div>';
		$html .= '</div>';

		return $html;
	}
}
