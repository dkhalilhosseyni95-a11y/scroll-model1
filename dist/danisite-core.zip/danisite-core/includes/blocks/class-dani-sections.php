<?php
/**
 * Full page sections shared by shortcodes, the demo importer and the
 * Elementor widgets. Markup and classes mirror the Lovable design exactly.
 *
 * @package DaniSite_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Section renderer.
 */
class Dani_Sections {

	/**
	 * Render a section.
	 *
	 * @param string $type Section type.
	 * @param array  $args Arguments.
	 * @return string
	 */
	public static function render( $type, $args = array() ) {
		$method = 'render_' . str_replace( '-', '_', $type );

		if ( ! method_exists( __CLASS__, $method ) ) {
			return '';
		}

		return (string) call_user_func( array( __CLASS__, $method ), (array) $args );
	}

	/* ---------------------------------------------------------------------
	 * Hero
	 * ------------------------------------------------------------------ */

	/**
	 * Hero with optional background video.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_hero( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow'       => 'DANISITE STUDIO · DIGITAL EXPERIENCE',
				'title'         => 'معمولی دیده نشوید.',
				'highlight'     => 'متفاوت به یاد بمانید.',
				'text'          => 'هر همکاری، فرصتی برای ساختن یک تجربه متفاوت است. ما با ترکیب خلاقیت، طراحی و تکنولوژی، تصویری ماندگار از برند شما در دنیای دیجیتال می‌سازیم.',
				'primary_label' => 'مشاهده نمونه‌کارها',
				'primary_url'   => '',
				'second_label'  => 'شروع همکاری',
				'second_url'    => '',
				'video'         => '',
				'video_mobile'  => '',
				'poster'        => '',
				'compact'       => false,
				'badge'         => '',
				'id'            => 'home',
			)
		);

		if ( ! $args['primary_url'] ) {
			$args['primary_url'] = home_url( '/portfolio/' );
		}
		if ( ! $args['second_url'] ) {
			$args['second_url'] = dani_option( 'cta_url', home_url( '/contact/' ) );
		}

		$has_video = $args['video'] || $args['video_mobile'];

		$html  = '<section id="' . esc_attr( $args['id'] ) . '" class="dani-hero' . ( $args['compact'] ? ' dani-hero--compact' : '' ) . '">';
		$html .= '<div class="dani-hero__bg" aria-hidden="true"></div>';

		if ( $has_video ) {
			$html .= sprintf(
				'<video class="dani-hero__video" id="dani-hero-video" autoplay muted loop playsinline preload="metadata"%1$s data-dani-src="%2$s"%3$s aria-hidden="true"></video>',
				$args['poster'] ? ' poster="' . esc_url( $args['poster'] ) . '"' : '',
				esc_url( $args['video'] ? $args['video'] : $args['video_mobile'] ),
				$args['video_mobile'] ? ' data-dani-src-mobile="' . esc_url( $args['video_mobile'] ) . '"' : ''
			);
		} else {
			$html .= '<div class="dani-hero__blobs" aria-hidden="true"><span class="dani-hero__blob dani-hero__blob--1 dani-float"></span><span class="dani-hero__blob dani-hero__blob--2 dani-float"></span></div>';
		}

		$html .= '<div class="dani-hero__overlay" aria-hidden="true"></div>';

		if ( $has_video ) {
			$html .= '<button type="button" class="dani-glass dani-sound" data-dani-sound="dani-hero-video" data-muted="true" aria-label="پخش صدا">' . dani_icon( 'volume-x' ) . '<span>صدا خاموش</span></button>';
		}

		$html .= '<div class="dani-hero__content">';
		$html .= $args['eyebrow'] ? '<p class="dani-eyebrow dani-hero__eyebrow">' . esc_html( $args['eyebrow'] ) . '</p>' : '';
		$html .= '<h1 class="dani-hero__title">' . esc_html( $args['title'] );
		if ( $args['highlight'] ) {
			$html .= '<br><span class="dani-gradient-text">' . esc_html( $args['highlight'] ) . '</span>';
		}
		$html .= '</h1>';
		$html .= $args['text'] ? '<p class="dani-hero__text">' . esc_html( $args['text'] ) . '</p>' : '';

		$html .= '<div class="dani-hero__actions">';
		if ( $args['primary_label'] ) {
			$html .= Dani_Blocks::render_button( array( 'label' => $args['primary_label'], 'url' => $args['primary_url'], 'size' => 'lg' ) );
		}
		if ( $args['second_label'] ) {
			$html .= Dani_Blocks::render_button( array( 'label' => $args['second_label'], 'url' => $args['second_url'], 'variant' => 'glass', 'size' => 'lg' ) );
		}
		$html .= '</div>';

		if ( $args['badge'] ) {
			$html .= '<p class="dani-hero__badge">' . dani_icon( 'star' ) . '<span>' . esc_html( $args['badge'] ) . '</span></p>';
		}

		$html .= '</div></section>';

		return $html;
	}

	/**
	 * Hero video variant (same layout, video is the only background).
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_hero_video( $args = array() ) {
		$args['compact'] = false;

		return self::render_hero( $args );
	}

	/**
	 * Page hero for inner pages built with Elementor.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_page_hero( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => 'DANISITE',
				'title'   => '',
				'text'    => '',
				'crumbs'  => true,
			)
		);

		$html  = '<section class="dani-page-hero"><div class="dani-container dani-page-hero__inner">';
		if ( $args['crumbs'] ) {
			ob_start();
			dani_breadcrumbs();
			$html .= ob_get_clean();
		}
		$html .= $args['eyebrow'] ? '<p class="dani-eyebrow" style="margin-top:1.25rem">' . esc_html( $args['eyebrow'] ) . '</p>' : '';
		$html .= '<h1 class="dani-page-hero__title">' . esc_html( $args['title'] ) . '</h1>';
		$html .= $args['text'] ? '<p class="dani-page-hero__text">' . esc_html( $args['text'] ) . '</p>' : '';
		$html .= '</div></section>';

		return $html;
	}

	/* ---------------------------------------------------------------------
	 * Services
	 * ------------------------------------------------------------------ */

	/**
	 * Numbered services list with a sticky heading.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_services( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => 'SERVICES',
				'title'   => 'از ایده تا تجربه‌ای که کار می‌کند.',
				'text'    => 'هر کسب‌وکار به راهکاری متناسب با اهداف، مخاطبان و هویت خودش نیاز دارد.',
				'items'   => array(),
				'limit'   => 6,
				'surface' => true,
				'id'      => 'services',
			)
		);

		$items = ! empty( $args['items'] ) ? $args['items'] : Dani_Query::services( $args['limit'] );

		if ( empty( $items ) ) {
			return '';
		}

		$html  = '<section id="' . esc_attr( $args['id'] ) . '" class="dani-section' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '">';
		$html .= '<div class="dani-container dani-services__grid">';
		$html .= '<div class="dani-services__aside"><div class="dani-services__aside-inner">';
		$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'] ) );
		$html .= '</div></div>';
		$html .= '<ol class="dani-services__list">';
		foreach ( array_values( $items ) as $i => $item ) {
			$html .= Dani_Blocks::render_service_row( array( 'item' => $item, 'index' => $i + 1 ) );
		}
		$html .= '</ol></div></section>';

		return $html;
	}

	/**
	 * Service cards grid.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_service_cards( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => 'SERVICES',
				'title'   => 'خدماتی که مسیر رشد را هموار می‌کنند.',
				'text'    => '',
				'items'   => array(),
				'limit'   => 6,
				'columns' => 3,
				'surface' => false,
			)
		);

		$items = ! empty( $args['items'] ) ? $args['items'] : Dani_Query::services( $args['limit'] );

		$html  = '<section class="dani-section' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '">';
		$html .= '<div class="dani-container">';
		if ( $args['title'] ) {
			$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'] ) );
		}
		$html .= '<div class="dani-cards' . ( 3 === (int) $args['columns'] ? ' dani-cards--3' : '' ) . '" style="margin-top:3rem">';
		foreach ( $items as $item ) {
			$html .= Dani_Blocks::render_service_card( array( 'item' => $item ) );
		}
		$html .= '</div></div></section>';

		return $html;
	}

	/**
	 * Single service card.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_service_card( $args = array() ) {
		return '<div class="dani-container" style="padding-block:1rem">' . Dani_Blocks::render_service_card( $args ) . '</div>';
	}

	/* ---------------------------------------------------------------------
	 * Experience
	 * ------------------------------------------------------------------ */

	/**
	 * Digital experience section with image and three traits.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_experience( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => 'DIGITAL EXPERIENCE',
				'title'   => 'فقط یک وب‌سایت نسازید؛ یک تجربه خلق کنید.',
				'text'    => 'حرکت، تعامل و جزئیات بصری می‌توانند نحوه ارتباط مخاطب با یک برند را تغییر دهند. ما به طراحی به چشم فرصتی برای خلق تجربه‌ای ماندگار نگاه می‌کنیم.',
				'image'   => DANI_CORE_URL . 'assets/img/experience.jpg',
				'caption' => 'حرکت ظریف، عمق و نور؛ سه ابزاری که هر رابط را به تجربه‌ای به یادماندنی تبدیل می‌کنند.',
				'traits'  => array(
					array( 'title' => 'حرکت', 'text' => 'انیمیشن‌های سنجیده و سبک' ),
					array( 'title' => 'تعامل', 'text' => 'پاسخ‌گویی دقیق به هر لمس' ),
					array( 'title' => 'جزئیات', 'text' => 'تایپوگرافی و فاصله‌گذاری دقیق' ),
				),
			)
		);

		$html  = '<section class="dani-section" style="overflow:hidden">';
		$html .= '<div class="dani-container">';
		$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'], 'center' => true ) );
		$html .= '<div class="dani-experience__frame-wrap dani-reveal">';
		$html .= '<div class="dani-experience__glow" aria-hidden="true"></div>';
		$html .= '<div class="dani-experience__frame">';
		$html .= '<img src="' . esc_url( $args['image'] ) . '" alt="عناصر شیشه‌ای و پیش‌نمایش رابط‌های وب" width="1600" height="1008" loading="lazy" decoding="async">';
		if ( $args['caption'] ) {
			$html .= '<div class="dani-glass dani-experience__caption"><p>' . esc_html( $args['caption'] ) . '</p></div>';
		}
		$html .= '</div></div>';

		$html .= '<div class="dani-traits">';
		foreach ( (array) $args['traits'] as $i => $trait ) {
			$html .= '<div class="dani-reveal" data-dani-delay="' . esc_attr( (string) ( $i * 100 ) ) . '">';
			$html .= '<p class="dani-traits__item-title dani-gradient-text">' . esc_html( $trait['title'] ) . '</p>';
			$html .= '<p class="dani-traits__item-text">' . esc_html( $trait['text'] ) . '</p>';
			$html .= '</div>';
		}
		$html .= '</div></div></section>';

		return $html;
	}

	/* ---------------------------------------------------------------------
	 * Portfolio
	 * ------------------------------------------------------------------ */

	/**
	 * Default spans/offsets that reproduce the Lovable masonry composition.
	 *
	 * @param int $index Item index.
	 * @return array
	 */
	private static function project_layout( $index ) {
		$layouts = array(
			array( 'span' => 8, 'offset' => '' ),
			array( 'span' => 4, 'offset' => '24' ),
			array( 'span' => 5, 'offset' => '' ),
			array( 'span' => 7, 'offset' => '32' ),
			array( 'span' => 10, 'offset' => '', 'center' => true ),
		);

		if ( isset( $layouts[ $index ] ) ) {
			return $layouts[ $index ];
		}

		$cycle = array( array( 'span' => 6, 'offset' => '' ), array( 'span' => 6, 'offset' => '' ) );

		return $cycle[ $index % 2 ];
	}

	/**
	 * Portfolio grid.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_portfolio( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow'     => 'SELECTED WORK',
				'title'       => 'نتیجه، خودش حرف می‌زند.',
				'text'        => 'مجموعه‌ای از تجربه‌ها و پروژه‌هایی که با نگاه متفاوت و توجه به جزئیات خلق شده‌اند.',
				'items'       => array(),
				'limit'       => 5,
				'category'    => '',
				'layout'      => 'masonry',
				'button'      => true,
				'button_text' => 'مشاهده همه پروژه‌ها',
				'button_url'  => '',
				'filters'     => false,
				'id'          => 'work',
				'surface'     => false,
			)
		);

		$items = ! empty( $args['items'] ) ? $args['items'] : Dani_Query::projects( $args['limit'], $args['category'] );

		if ( empty( $items ) ) {
			return '';
		}

		$is_grid = 'grid' === $args['layout'];

		$html  = '<section id="' . esc_attr( $args['id'] ) . '" class="dani-section' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '"' . ( $args['filters'] ? ' data-dani-filter' : '' ) . '>';
		$html .= '<div class="dani-container">';
		$html .= '<div class="dani-work__head">';
		$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'] ) );
		if ( $args['button'] && ! $is_grid ) {
			$html .= Dani_Blocks::render_button( array(
				'label'   => $args['button_text'],
				'url'     => $args['button_url'] ? $args['button_url'] : get_post_type_archive_link( 'dani_project' ),
				'variant' => 'ghost',
				'class'   => 'dani-work__all',
			) );
		}
		$html .= '</div>';

		if ( $args['filters'] ) {
			$html .= '<div class="dani-chips">';
			$html .= '<button type="button" class="dani-chip is-active" data-dani-filter-chip="all">همه</button>';
			foreach ( Dani_Query::project_categories() as $term ) {
				$html .= '<button type="button" class="dani-chip" data-dani-filter-chip="' . esc_attr( $term['slug'] ) . '">' . esc_html( $term['name'] ) . '</button>';
			}
			$html .= '</div>';
		}

		$html .= $is_grid
			? '<div class="dani-work__grid dani-work__grid--archive" style="margin-top:3rem">'
			: '<div class="dani-work__grid">';

		foreach ( array_values( $items ) as $i => $item ) {
			$layout = $is_grid ? array( 'span' => 0, 'offset' => '' ) : self::project_layout( $i );
			$layout['item'] = $item;
			if ( $args['filters'] ) {
				$layout['filter'] = isset( $item['slug'] ) ? $item['slug'] : 'all';
			}
			$html .= Dani_Blocks::render_project_card( $layout );
		}

		$html .= '</div>';

		if ( $args['button'] && $is_grid ) {
			$html .= '<div style="margin-top:3rem">' . Dani_Blocks::render_button( array(
				'label'   => $args['button_text'],
				'url'     => $args['button_url'] ? $args['button_url'] : get_post_type_archive_link( 'dani_project' ),
				'variant' => 'ghost',
			) ) . '</div>';
		}

		$html .= '</div></section>';

		return $html;
	}

	/**
	 * Portfolio carousel.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_portfolio_carousel( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => 'SELECTED WORK',
				'title'   => 'پروژه‌هایی که دوستشان داریم.',
				'text'    => '',
				'items'   => array(),
				'limit'   => 8,
				'category' => '',
			)
		);

		$items = ! empty( $args['items'] ) ? $args['items'] : Dani_Query::projects( $args['limit'], $args['category'] );

		if ( empty( $items ) ) {
			return '';
		}

		$html  = '<section class="dani-section">';
		$html .= '<div class="dani-container">';
		if ( $args['title'] ) {
			$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'] ) );
		}
		$html .= '<div class="dani-carousel" data-dani-carousel>';
		$html .= '<div class="dani-carousel__viewport"><div class="dani-carousel__track">';
		foreach ( $items as $item ) {
			$html .= '<div class="dani-carousel__item">' . Dani_Blocks::render_project_card( array( 'item' => $item, 'span' => 0 ) ) . '</div>';
		}
		$html .= '</div></div>';
		$html .= '<div class="dani-carousel__nav">';
		$html .= '<button type="button" class="dani-icon-btn" data-dani-carousel-prev aria-label="قبلی">' . dani_icon( 'chevron-right' ) . '</button>';
		$html .= '<span class="dani-carousel__count" data-dani-carousel-count>۱ / ' . esc_html( dani_fa_number( count( $items ) ) ) . '</span>';
		$html .= '<button type="button" class="dani-icon-btn" data-dani-carousel-next aria-label="بعدی">' . dani_icon( 'chevron-left' ) . '</button>';
		$html .= '</div></div></div></section>';

		return $html;
	}

	/**
	 * Single portfolio card row.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_portfolio_card( $args = array() ) {
		if ( empty( $args['item'] ) ) {
			$items = Dani_Query::projects( 1 );
			$args['item'] = $items[0];
		}

		return '<div class="dani-container" style="padding-block:1rem">' . Dani_Blocks::render_project_card( $args ) . '</div>';
	}

	/* ---------------------------------------------------------------------
	 * About
	 * ------------------------------------------------------------------ */

	/**
	 * About / founder section.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_about( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow'    => 'ABOUT DANISITE',
				'title'      => 'طراحی خوب، از یک تفکر خوب شروع می‌شود.',
				'text'       => 'در دنی سایت، هر پروژه با شناخت نیاز واقعی کسب‌وکار و درک تجربه مخاطب آغاز می‌شود. هدف ما ساخت وب‌سایت‌هایی است که علاوه بر ظاهر حرفه‌ای، عملکرد دقیق و تجربه کاربری مناسبی داشته باشند.',
				'image'      => DANI_CORE_URL . 'assets/img/studio.jpg',
				'badge_label' => 'بنیان‌گذار',
				'badge_name'  => 'دانیال حسینی',
				'quote_name'  => 'دانیال حسینی',
				'quote'       => '، بنیان‌گذار DaniSite، طراح و توسعه‌دهنده‌ای است که طراحی را نقطه تلاقی استراتژی، زیبایی و فناوری می‌داند.',
				'tags'        => array( 'طراحی UI/UX', 'وردپرس و ووکامرس', 'توسعه فرانت‌اند', 'هویت دیجیتال', 'بهینه‌سازی سرعت' ),
				'button_text' => 'بیشتر درباره ما',
				'button_url'  => '',
				'id'          => 'about',
			)
		);

		if ( ! $args['button_url'] ) {
			$args['button_url'] = home_url( '/about/' );
		}

		$html  = '<section id="' . esc_attr( $args['id'] ) . '" class="dani-section dani-section--surface">';
		$html .= '<div class="dani-container dani-about__grid">';

		$html .= '<div class="dani-about__media dani-reveal">';
		$html .= '<img src="' . esc_url( $args['image'] ) . '" alt="فضای کاری استودیو دنی سایت" width="1008" height="1200" loading="lazy" decoding="async">';
		if ( $args['badge_name'] ) {
			$html .= '<div class="dani-glass dani-about__badge"><p class="dani-about__badge-label">' . esc_html( $args['badge_label'] ) . '</p><p class="dani-about__badge-name">' . esc_html( $args['badge_name'] ) . '</p></div>';
		}
		$html .= '</div>';

		$html .= '<div class="dani-about__body">';
		$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'] ) );
		$html .= '<div class="dani-about__quote dani-reveal"><p><strong>' . esc_html( $args['quote_name'] ) . '</strong>' . esc_html( $args['quote'] ) . '</p></div>';
		if ( ! empty( $args['tags'] ) ) {
			$html .= '<div class="dani-tags dani-reveal">';
			foreach ( (array) $args['tags'] as $tag ) {
				$html .= '<span class="dani-tag">' . esc_html( $tag ) . '</span>';
			}
			$html .= '</div>';
		}
		if ( $args['button_text'] ) {
			$html .= '<div class="dani-about__cta">' . Dani_Blocks::render_button( array( 'label' => $args['button_text'], 'url' => $args['button_url'], 'variant' => 'ghost' ) ) . '</div>';
		}
		$html .= '</div></div></section>';

		return $html;
	}

	/* ---------------------------------------------------------------------
	 * Workflow
	 * ------------------------------------------------------------------ */

	/**
	 * Process steps.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_workflow( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => 'PROCESS',
				'title'   => 'از اولین گفت‌وگو تا لحظه رونمایی.',
				'text'    => '',
				'steps'   => array(),
				'surface' => false,
			)
		);

		$steps = ! empty( $args['steps'] ) ? $args['steps'] : Dani_Query::steps();

		$html  = '<section class="dani-section' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '">';
		$html .= '<div class="dani-container">';
		$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'] ) );
		$html .= '<ol class="dani-steps">';
		foreach ( $steps as $i => $step ) {
			$html .= '<li class="dani-step dani-reveal" data-dani-delay="' . esc_attr( (string) ( $i * 80 ) ) . '">';
			$html .= '<span class="dani-step__dot" aria-hidden="true"></span>';
			$html .= '<span class="dani-step__num">' . esc_html( $step['n'] ) . '</span>';
			$html .= '<h3 class="dani-step__title">' . esc_html( $step['title'] ) . '</h3>';
			$html .= '<p class="dani-step__text">' . esc_html( $step['desc'] ) . '</p>';
			$html .= '</li>';
		}
		$html .= '</ol></div></section>';

		return $html;
	}

	/* ---------------------------------------------------------------------
	 * Testimonials
	 * ------------------------------------------------------------------ */

	/**
	 * Testimonials slider.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_testimonials( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => 'TESTIMONIALS',
				'title'   => 'اعتماد، با تجربه واقعی ساخته می‌شود.',
				'text'    => '',
				'items'   => array(),
				'limit'   => 5,
				'surface' => true,
			)
		);

		$items = ! empty( $args['items'] ) ? $args['items'] : Dani_Query::quotes( $args['limit'] );

		if ( empty( $items ) ) {
			return '';
		}

		$html  = '<section class="dani-section' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '">';
		$html .= '<div class="dani-container">';
		$html .= '<div class="dani-quotes" data-dani-quotes>';
		$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'], 'center' => true ) );
		foreach ( array_values( $items ) as $i => $item ) {
			$html .= Dani_Blocks::render_quote( array( 'item' => $item, 'index' => $i ) );
		}
		if ( count( $items ) > 1 ) {
			$html .= '<div class="dani-quotes__nav">';
			$html .= '<button type="button" class="dani-icon-btn" data-dani-quote-prev aria-label="نظر قبلی">' . dani_icon( 'chevron-right' ) . '</button>';
			$html .= '<span class="dani-quotes__count" data-dani-quote-count data-dani-quote-total="' . esc_attr( dani_fa_number( count( $items ) ) ) . '">۱ / ' . esc_html( dani_fa_number( count( $items ) ) ) . '</span>';
			$html .= '<button type="button" class="dani-icon-btn" data-dani-quote-next aria-label="نظر بعدی">' . dani_icon( 'chevron-left' ) . '</button>';
			$html .= '</div>';
		}
		$html .= '</div></div></section>';

		return $html;
	}

	/* ---------------------------------------------------------------------
	 * Team / statistics / logos
	 * ------------------------------------------------------------------ */

	/**
	 * Team grid.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_team( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => 'TEAM',
				'title'   => 'آدم‌هایی که پشت هر پروژه هستند.',
				'text'    => '',
				'items'   => array(),
				'limit'   => 6,
				'surface' => false,
			)
		);

		$items = ! empty( $args['items'] ) ? $args['items'] : Dani_Query::team( $args['limit'] );

		if ( empty( $items ) ) {
			return '';
		}

		$html  = '<section class="dani-section' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '">';
		$html .= '<div class="dani-container">';
		$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'] ) );
		$html .= '<div class="dani-team" style="margin-top:3rem">';
		foreach ( $items as $item ) {
			$html .= Dani_Blocks::render_member( array( 'item' => $item ) );
		}
		$html .= '</div></div></section>';

		return $html;
	}

	/**
	 * Statistics row.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_stats( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'items'   => array(),
				'surface' => false,
			)
		);

		$items = ! empty( $args['items'] ) ? $args['items'] : Dani_Query::stats();

		$html  = '<section class="dani-section dani-section--tight' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '"><div class="dani-container"><div class="dani-stats">';
		foreach ( $items as $item ) {
			$html .= Dani_Blocks::render_stat( array( 'item' => $item ) );
		}
		$html .= '</div></div></section>';

		return $html;
	}

	/**
	 * Logo strip.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_logos( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'images' => array(),
				'title'  => 'برندهایی که با ما رشد کرده‌اند',
				'text'   => '',
			)
		);

		$html = '<section class="dani-section dani-section--tight"><div class="dani-container" style="text-align:center">';
		if ( $args['title'] ) {
			$html .= '<p class="dani-eyebrow" style="margin-bottom:2rem">' . esc_html( $args['title'] ) . '</p>';
		}
		$html .= '<div class="dani-logos">';
		foreach ( (array) $args['images'] as $image ) {
			$url = is_array( $image ) ? $image['url'] : $image;
			$alt = is_array( $image ) && isset( $image['alt'] ) ? $image['alt'] : 'لوگوی مشتری';
			if ( $url ) {
				$html .= '<img src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy" decoding="async">';
			}
		}
		$html .= '</div></div></section>';

		return $html;
	}

	/* ---------------------------------------------------------------------
	 * FAQ / CTA / blog / contact
	 * ------------------------------------------------------------------ */

	/**
	 * FAQ accordion.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_faq( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => 'FAQ',
				'title'   => 'پرسش‌هایی که پیش از شروع می‌پرسید.',
				'text'    => 'اگر پاسخ سؤال‌تان این‌جا نبود، در تماس با ما با کمال میل پاسخ می‌دهیم.',
				'items'   => array(),
				'limit'   => 8,
				'surface' => false,
			)
		);

		$items = ! empty( $args['items'] ) ? $args['items'] : Dani_Query::faqs( $args['limit'] );

		if ( empty( $items ) ) {
			return '';
		}

		$html  = '<section class="dani-section' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '">';
		$html .= '<div class="dani-container">';
		$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'], 'center' => true ) );
		$html .= '<div class="dani-faq" data-dani-faq="single">';
		foreach ( array_values( $items ) as $i => $item ) {
			$html .= Dani_Blocks::render_faq_item( array( 'item' => $item, 'open' => 0 === $i ) );
		}
		$html .= '</div></div></section>';

		return $html;
	}

	/**
	 * Final call to action.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_cta( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'title'       => 'شاید این، شروع یک همکاری متفاوت باشد.',
				'text'        => 'ایده‌تان را با ما در میان بگذارید. برای ساختن تجربه دیجیتال بعدی آماده‌ایم.',
				'primary_label' => 'شروع یک پروژه جدید',
				'primary_url' => '',
				'second_label' => '',
				'second_url'  => '',
			)
		);

		if ( ! $args['primary_url'] ) {
			$args['primary_url'] = 'mailto:' . antispambot( dani_option( 'email' ) );
		}

		$html  = '<section class="dani-section dani-cta-wrap" id="contact">';
		$html .= '<div class="dani-cta">';
		$html .= '<div class="dani-cta__blob dani-cta__blob--1" aria-hidden="true"></div><div class="dani-cta__blob dani-cta__blob--2" aria-hidden="true"></div>';
		$html .= '<div class="dani-glass dani-cta__inner">';
		$html .= '<h2 class="dani-cta__title">' . esc_html( $args['title'] ) . '</h2>';
		$html .= '<p class="dani-cta__text">' . esc_html( $args['text'] ) . '</p>';
		$html .= '<div class="dani-cta__actions">';
		$html .= Dani_Blocks::render_button( array( 'label' => $args['primary_label'], 'url' => $args['primary_url'], 'size' => 'lg' ) );
		if ( $args['second_label'] ) {
			$html .= Dani_Blocks::render_button( array( 'label' => $args['second_label'], 'url' => $args['second_url'], 'variant' => 'ghost', 'size' => 'lg' ) );
		}
		$html .= '</div></div></div></section>';

		return $html;
	}

	/**
	 * Blog grid.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_blog( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow'    => 'JOURNAL',
				'title'      => 'تازه‌ترین نوشته‌ها',
				'text'       => 'محتوایی برای کسب‌وکارهایی که می‌خواهند در فضای دیجیتال متمایز دیده شوند.',
				'limit'      => 3,
				'category'   => '',
				'columns'    => 3,
				'button'     => true,
				'button_text' => 'همه نوشته‌ها',
				'button_url' => '',
				'surface'    => true,
			)
		);

		$items = Dani_Query::posts( $args['limit'], $args['category'] );

		$blog_url = get_permalink( get_option( 'page_for_posts' ) );
		if ( ! $blog_url ) {
			$blog_url = home_url( '/blog/' );
		}

		$html  = '<section class="dani-section' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '">';
		$html .= '<div class="dani-container">';
		$html .= '<div class="dani-work__head">';
		$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'] ) );
		if ( $args['button'] ) {
			$html .= Dani_Blocks::render_button( array( 'label' => $args['button_text'], 'url' => $args['button_url'] ? $args['button_url'] : $blog_url, 'variant' => 'ghost' ) );
		}
		$html .= '</div>';

		if ( empty( $items ) ) {
			$html .= '<p class="dani-notice" style="margin-top:2.5rem">هنوز نوشته‌ای منتشر نشده است. پس از انتشار اولین مقاله، این بخش خودکار پر می‌شود.</p>';
		} else {
			$html .= '<div class="dani-posts' . ( 3 === (int) $args['columns'] ? ' dani-posts--3' : '' ) . '" style="margin-top:3rem">';
			foreach ( $items as $item ) {
				$html .= Dani_Blocks::render_post_card( array( 'item' => $item ) );
			}
			$html .= '</div>';
		}

		$html .= '</div></section>';

		return $html;
	}

	/**
	 * Contact section: details plus the styled form.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_contact( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => 'CONTACT',
				'title'   => 'درباره پروژه‌تان حرف بزنیم.',
				'text'    => 'هر همکاری از یک گفت‌وگوی کوتاه شروع می‌شود. فرم را پر کنید یا مستقیم تماس بگیرید.',
				'surface' => false,
			)
		);

		$html  = '<section class="dani-section' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '">';
		$html .= '<div class="dani-container dani-contact__grid">';
		$html .= '<div>';
		$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'] ) );
		$html .= '<div class="dani-contact__info">';

		$rows = array(
			array( 'icon' => 'mail', 'label' => 'ایمیل', 'value' => '<a href="mailto:' . esc_attr( antispambot( dani_option( 'email' ) ) ) . '" dir="ltr">' . esc_html( antispambot( dani_option( 'email' ) ) ) . '</a>' ),
			array( 'icon' => 'phone', 'label' => 'تلفن', 'value' => '<a href="tel:' . esc_attr( dani_option( 'phone_link' ) ) . '" dir="ltr">' . esc_html( dani_option( 'phone' ) ) . '</a>' ),
			array( 'icon' => 'map-pin', 'label' => 'نشانی', 'value' => esc_html( dani_option( 'address' ) ) ),
			array( 'icon' => 'clock', 'label' => 'ساعات پاسخ‌گویی', 'value' => esc_html( dani_option( 'hours' ) ) ),
		);

		foreach ( $rows as $row ) {
			$html .= '<div class="dani-contact__item">' . dani_icon( $row['icon'] ) . '<div><p class="dani-contact__label">' . esc_html( $row['label'] ) . '</p><p class="dani-contact__value">' . $row['value'] . '</p></div></div>';
		}
		$html .= '</div>';

		$socials = dani_get_socials();
		if ( ! empty( $socials ) ) {
			$html .= '<div class="dani-socials" style="margin-top:1.5rem">';
			foreach ( $socials as $social ) {
				$html .= Dani_Blocks::render_social( array( 'item' => $social ) );
			}
			$html .= '</div>';
		}

		$html .= '</div>';
		$html .= '<div>' . Dani_Forms::form() . '</div>';
		$html .= '</div></section>';

		return $html;
	}

	/* ---------------------------------------------------------------------
	 * Media
	 * ------------------------------------------------------------------ */

	/**
	 * Gallery grid.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_gallery( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => '',
				'title'   => '',
				'text'    => '',
				'images'  => array(),
				'surface' => false,
			)
		);

		$html  = '<section class="dani-section' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '"><div class="dani-container">';
		if ( $args['title'] ) {
			$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'] ) );
		}
		$html .= '<div class="dani-gallery"' . ( $args['title'] ? ' style="margin-top:2.5rem"' : '' ) . '>';
		foreach ( (array) $args['images'] as $i => $image ) {
			$url = is_array( $image ) ? $image['url'] : $image;
			$alt = is_array( $image ) && isset( $image['alt'] ) ? $image['alt'] : 'تصویر گالری';
			$html .= Dani_Blocks::render_gallery_item( array( 'image' => $url, 'alt' => $alt, 'wide' => 0 === $i % 5 ) );
		}
		$html .= '</div></div></section>';

		return $html;
	}

	/**
	 * Before / after section.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_before_after( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow' => 'TRANSFORMATION',
				'title'   => 'قبل و بعد یک بازطراحی.',
				'text'    => 'دستگیره را بکشید و تفاوت را ببینید.',
				'surface' => true,
			)
		);

		$html  = '<section class="dani-section' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '"><div class="dani-container">';
		$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'], 'center' => true ) );
		$html .= '<div style="margin-top:3rem">' . Dani_Blocks::render_before_after( $args ) . '</div>';
		$html .= '</div></section>';

		return $html;
	}

	/**
	 * Image block.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_image( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'url'   => '',
				'alt'   => '',
				'ratio' => '',
				'class' => '',
			)
		);

		if ( ! $args['url'] ) {
			return '';
		}

		$style = $args['ratio'] ? ' style="aspect-ratio:' . esc_attr( $args['ratio'] ) . ';object-fit:cover;width:100%"' : '';

		return '<figure class="dani-section dani-section--tight"><div class="dani-container"><img class="' . esc_attr( $args['class'] ) . '" src="' . esc_url( $args['url'] ) . '" alt="' . esc_attr( $args['alt'] ) . '" loading="lazy" decoding="async"' . $style . '></div></figure>';
	}

	/**
	 * Video block (self-hosted or oEmbed).
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_video( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'url'    => '',
				'poster' => '',
				'embed'  => '',
			)
		);

		$html = '<section class="dani-section dani-section--tight"><div class="dani-container">';

		if ( $args['embed'] ) {
			$html .= '<div class="dani-video-embed" style="position:relative;aspect-ratio:16/9;border-radius:var(--radius-3xl);overflow:hidden">' . wp_oembed_get( $args['embed'] ) . '</div>';
		} elseif ( $args['url'] ) {
			$html .= sprintf(
				'<video class="dani-video" controls preload="metadata" playsinline%1$s style="width:100%%;border-radius:var(--radius-3xl)"><source src="%2$s" type="video/mp4"></video>',
				$args['poster'] ? ' poster="' . esc_url( $args['poster'] ) . '"' : '',
				esc_url( $args['url'] )
			);
		}

		$html .= '</div></section>';

		return $html;
	}

	/**
	 * Scroll-animation content block.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_scroll_animation( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'eyebrow'   => '',
				'title'     => '',
				'text'      => '',
				'direction' => 'up',
				'delay'     => 0,
				'surface'   => false,
			)
		);

		$html  = '<section class="dani-section' . ( $args['surface'] ? ' dani-section--surface' : '' ) . '"><div class="dani-container">';
		$html .= '<div class="dani-scroll-fx dani-scroll-fx--' . esc_attr( $args['direction'] ) . '" data-dani-delay="' . esc_attr( (string) absint( $args['delay'] ) ) . '">';
		$html .= Dani_Blocks::render_head( array( 'eyebrow' => $args['eyebrow'], 'title' => $args['title'], 'text' => $args['text'], 'center' => true ) );
		$html .= '</div></div></section>';

		return $html;
	}

	/* ---------------------------------------------------------------------
	 * Header / navigation / footer widgets
	 * ------------------------------------------------------------------ */

	/**
	 * Header bar (for landing pages or Elementor-built headers).
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_header( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'inline'    => true,
				'cta_label' => dani_option( 'cta_label' ),
				'cta_url'   => dani_option( 'cta_url' ),
			)
		);

		$items = self::nav_items();

		$html  = '<header class="dani-header' . ( $args['inline'] ? ' dani-header--inline' : '' ) . '"><nav class="dani-nav" aria-label="منوی اصلی">';
		$html .= dani_logo();
		$html .= '<ul class="dani-nav__list">';
		foreach ( $items as $item ) {
			$html .= '<li><a class="dani-nav__link' . ( dani_is_current_url( $item['url'] ) ? ' is-active' : '' ) . '" href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['label'] ) . '</a></li>';
		}
		$html .= '</ul>';
		$html .= '<div class="dani-nav__actions">';
		$html .= '<button type="button" class="dani-theme-toggle" data-dani-theme aria-label="تغییر حالت روشن و تیره" aria-pressed="false">' . dani_icon( 'moon', array( 'class' => 'dani-icon-moon' ) ) . dani_icon( 'sun', array( 'class' => 'dani-icon-sun' ) ) . '</button>';
		if ( $args['cta_label'] ) {
			$html .= '<a class="dani-btn dani-btn--primary dani-nav__cta" href="' . esc_url( $args['cta_url'] ) . '">' . esc_html( $args['cta_label'] ) . '</a>';
		}
		$html .= '<button type="button" class="dani-nav__toggle" data-dani-menu-toggle aria-expanded="false" aria-controls="dani-mobile-menu-w" aria-label="منو">' . dani_icon( 'menu' ) . '</button>';
		$html .= '</div></nav>';
		$html .= '<div class="dani-mobile-menu" id="dani-mobile-menu-w" data-dani-menu><ul>';
		foreach ( $items as $i => $item ) {
			$html .= '<li class="dani-mobile-menu__item"><a class="dani-mobile-menu__link" href="' . esc_url( $item['url'] ) . '"><span>' . esc_html( $item['label'] ) . '</span><span class="dani-mobile-menu__index">' . esc_html( dani_fa_number( str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ) ) . '</span></a></li>';
		}
		$html .= '</ul>';
		if ( $args['cta_label'] ) {
			$html .= '<a class="dani-btn dani-btn--primary dani-btn--lg" href="' . esc_url( $args['cta_url'] ) . '">' . esc_html( $args['cta_label'] ) . '</a>';
		}
		$html .= '</div></header>';

		return $html;
	}

	/**
	 * Navigation links only.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_navigation( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'style' => 'inline',
			)
		);

		$html = '<nav class="dani-section dani-section--tight" aria-label="ناوبری"><div class="dani-container"><ul class="dani-nav__list" style="display:flex;gap:.35rem;flex-wrap:wrap">';
		foreach ( self::nav_items() as $item ) {
			$html .= '<li><a class="dani-nav__link' . ( dani_is_current_url( $item['url'] ) ? ' is-active' : '' ) . '" href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['label'] ) . '</a></li>';
		}
		$html .= '</ul></div></nav>';

		return $html;
	}

	/**
	 * Primary navigation items as label/url pairs.
	 *
	 * @return array
	 */
	public static function nav_items() {
		$locations = get_nav_menu_locations();
		$menu_id   = isset( $locations['primary'] ) ? $locations['primary'] : 0;
		$items     = array();

		if ( $menu_id ) {
			foreach ( (array) wp_get_nav_menu_items( $menu_id ) as $item ) {
				if ( (int) $item->menu_item_parent !== 0 ) {
					continue;
				}
				$items[] = array( 'label' => $item->title, 'url' => $item->url );
			}
		}

		if ( empty( $items ) ) {
			$items = dani_default_menu_items();
		}

		return $items;
	}

	/**
	 * Footer widget markup.
	 *
	 * @param array $args Options.
	 * @return string
	 */
	public static function render_footer( $args = array() ) {
		ob_start();
		get_template_part( 'template-parts/site-footer' );
		$footer = ob_get_clean();

		return $footer;
	}

	/* ---------------------------------------------------------------------
	 * Whole homepage
	 * ------------------------------------------------------------------ */

	/**
	 * The Lovable homepage composition, section by section.
	 *
	 * @param array $args Unused.
	 * @return string
	 */
	public static function render_home( $args = array() ) {
		$sections = array(
			self::render_hero( array( 'video' => dani_option( 'hero_video' ), 'video_mobile' => dani_option( 'hero_video_mobile' ), 'poster' => dani_option( 'hero_video_poster' ) ) ),
			self::render_services(),
			self::render_experience(),
			self::render_portfolio(),
			self::render_about(),
			self::render_workflow(),
			self::render_testimonials(),
			self::render_cta(),
		);

		return implode( '', $sections );
	}
}
