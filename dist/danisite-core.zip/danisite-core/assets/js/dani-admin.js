/* global jQuery, wp */
( function ( $ ) {
	"use strict";

	$( document ).on( "click", "[data-dani-media-select]", function ( e ) {
		e.preventDefault();
		var wrap = $( this ).closest( ".dani-media-field" );
		var frame = wp.media( {
			title: daniAdmin.choose,
			button: { text: daniAdmin.use },
			library: { type: "image" },
			multiple: false,
		} );
		frame.on( "select", function () {
			var attachment = frame.state().get( "selection" ).first().toJSON();
			var url = attachment.sizes && attachment.sizes.medium ? attachment.sizes.medium.url : attachment.url;
			wrap.find( "[data-dani-media-input]" ).val( attachment.id );
			wrap.find( ".dani-media-preview" ).html( '<img src="' + url + '" alt="">' );
		} );
		frame.open();
	} );

	$( document ).on( "click", "[data-dani-media-clear]", function ( e ) {
		e.preventDefault();
		var wrap = $( this ).closest( ".dani-media-field" );
		wrap.find( "[data-dani-media-input]" ).val( "" );
		wrap.find( ".dani-media-preview" ).empty();
	} );
}( jQuery ) );
