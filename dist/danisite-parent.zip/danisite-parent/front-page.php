<?php
/**
 * Front page.
 *
 * Renders whatever the demo importer (or the site owner) has built for the
 * static front page; falls back to the bundled homepage sections so the theme
 * is never empty.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

get_header();

if ( 'posts' === get_option( 'show_on_front' ) ) {
	if ( shortcode_exists( 'dani_home' ) ) {
		echo do_shortcode( '[dani_home]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	} else {
		get_template_part( 'template-parts/home-fallback' );
	}
} else {
	while ( have_posts() ) :
		the_post();
		$dani_content = get_the_content();

		if ( dani_is_built_with_elementor( get_the_ID() ) ) {
			echo '<div class="dani-front-content">';
			the_content();
			echo '</div>';
		} elseif ( has_blocks( $dani_content ) || has_shortcode( $dani_content, 'dani_home' ) ) {
			echo '<div class="dani-front-content">';
			the_content();
			echo '</div>';
		} elseif ( shortcode_exists( 'dani_home' ) ) {
			echo do_shortcode( '[dani_home]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} elseif ( trim( $dani_content ) ) {
			get_template_part( 'template-parts/page-header', null, array(
				'title'   => get_the_title(),
				'eyebrow' => 'DANISITE',
			) );
			echo '<section class="dani-section"><div class="dani-container"><div class="dani-prose">';
			the_content();
			echo '</div></div></section>';
		} else {
			get_template_part( 'template-parts/home-fallback' );
		}
	endwhile;
}

get_footer();
