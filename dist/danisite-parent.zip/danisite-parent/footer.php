<?php
/**
 * Closing main element and footer.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;
?>
	</main>
	<?php get_template_part( 'template-parts/site-footer' ); ?>
</div>
<?php wp_footer(); ?>
</body>
</html>
