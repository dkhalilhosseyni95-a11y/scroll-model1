/*!
 * DaniSite front-end behaviour — dependency free, deferred, ~4KB gzipped.
 * Reveal on scroll, sticky header state, mobile menu, theme toggle,
 * FAQ accordion, testimonial slider, portfolio carousel, before/after.
 */
(function () {
  "use strict";

  var doc = document;
  var html = doc.documentElement;

  function ready(fn) {
    if (doc.readyState !== "loading") { fn(); }
    else { doc.addEventListener("DOMContentLoaded", fn); }
  }

  /* ---------- Scroll reveal ---------- */
  function initReveal() {
    var items = doc.querySelectorAll(".dani-reveal, .dani-scroll-fx");
    if (!items.length) { return; }
    if (!("IntersectionObserver" in window) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      Array.prototype.forEach.call(items, function (el) { el.classList.add("is-visible"); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) { return; }
        var el = entry.target;
        var delay = parseInt(el.getAttribute("data-dani-delay") || "0", 10);
        if (el.style.transitionDelay === "" && delay > 0) { el.style.transitionDelay = delay + "ms"; }
        el.classList.add("is-visible");
        io.unobserve(el);
      });
    }, { rootMargin: "0px 0px -10% 0px", threshold: 0.05 });
    Array.prototype.forEach.call(items, function (el) { io.observe(el); });
  }

  /* ---------- Sticky header ---------- */
  function initHeader() {
    var nav = doc.querySelector(".dani-nav");
    var header = doc.querySelector(".dani-header");
    if (!nav) { return; }
    var onScroll = function () {
      nav.classList.toggle("is-scrolled", window.scrollY > 24);
      if (header) { header.classList.toggle("is-scrolled", window.scrollY > 24); }
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  /* ---------- Mobile menu ---------- */
  function initMenu() {
    var toggle = doc.querySelector("[data-dani-menu-toggle]");
    var menu = doc.querySelector("[data-dani-menu]");
    if (!toggle || !menu) { return; }
    var setOpen = function (open) {
      menu.classList.toggle("is-open", open);
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
      doc.body.style.overflow = open ? "hidden" : "";
    };
    toggle.addEventListener("click", function () {
      setOpen(!menu.classList.contains("is-open"));
    });
    Array.prototype.forEach.call(menu.querySelectorAll("a"), function (a) {
      a.addEventListener("click", function () { setOpen(false); });
    });
    doc.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && menu.classList.contains("is-open")) { setOpen(false); }
    });
  }

  /* ---------- Theme toggle ---------- */
  function initTheme() {
    Array.prototype.forEach.call(doc.querySelectorAll("[data-dani-theme]"), function (btn) {
      btn.addEventListener("click", function () {
        var next = !html.classList.contains("dark");
        html.classList.toggle("dark", next);
        btn.setAttribute("aria-pressed", next ? "true" : "false");
        try { localStorage.setItem("danisite-theme", next ? "dark" : "light"); } catch (e) {}
      });
    });
  }

  /* ---------- FAQ accordion ---------- */
  function initFaq() {
    Array.prototype.forEach.call(doc.querySelectorAll("[data-dani-faq]"), function (root) {
      var items = root.querySelectorAll(".dani-faq__item");
      Array.prototype.forEach.call(items, function (item) {
        var btn = item.querySelector(".dani-faq__q");
        if (!btn) { return; }
        btn.addEventListener("click", function () {
          var open = item.classList.contains("is-open");
          if (root.getAttribute("data-dani-faq") === "single") {
            Array.prototype.forEach.call(items, function (other) {
              other.classList.remove("is-open");
              var b = other.querySelector(".dani-faq__q");
              if (b) { b.setAttribute("aria-expanded", "false"); }
            });
          }
          item.classList.toggle("is-open", !open);
          btn.setAttribute("aria-expanded", !open ? "true" : "false");
        });
      });
    });
  }

  /* ---------- Testimonials slider ---------- */
  function initQuotes() {
    Array.prototype.forEach.call(doc.querySelectorAll("[data-dani-quotes]"), function (root) {
      var slides = root.querySelectorAll("[data-dani-quote]");
      if (slides.length < 2) { return; }
      var index = 0;
      var counter = root.querySelector("[data-dani-quote-count]");
      function show(next) {
        index = (next + slides.length) % slides.length;
        Array.prototype.forEach.call(slides, function (s, i) {
          s.hidden = i !== index;
        });
        if (counter) {
          counter.textContent = counter.getAttribute("data-dani-quote-total") ?
            slideNum(index + 1) + " / " + counter.getAttribute("data-dani-quote-total") : (index + 1) + " / " + slides.length;
        }
      }
      function slideNum(n) {
        var fa = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
        return String(n).replace(/[0-9]/g, function (d) { return fa[+d]; });
      }
      Array.prototype.forEach.call(root.querySelectorAll("[data-dani-quote-prev]"), function (b) {
        b.addEventListener("click", function () { show(index - 1); });
      });
      Array.prototype.forEach.call(root.querySelectorAll("[data-dani-quote-next]"), function (b) {
        b.addEventListener("click", function () { show(index + 1); });
      });
      show(0);
    });
  }

  /* ---------- Portfolio carousel ---------- */
  function initCarousels() {
    Array.prototype.forEach.call(doc.querySelectorAll("[data-dani-carousel]"), function (root) {
      var track = root.querySelector(".dani-carousel__track");
      if (!track) { return; }
      var slides = track.children;
      if (!slides.length) { return; }
      var index = 0;
      var counter = root.querySelector("[data-dani-carousel-count]");
      var total = slides.length;
      function step() {
        if (!slides[0]) { return 0; }
        var gap = parseFloat(getComputedStyle(track).columnGap || "24") || 24;
        return slides[0].getBoundingClientRect().width + gap;
      }
      function update() {
        var viewport = track.parentElement.getBoundingClientRect().width;
        var perView = Math.max(1, Math.round(viewport / step()) || 1);
        var max = Math.max(0, total - perView);
        if (index > max) { index = max; }
        if (index < 0) { index = 0; }
        track.style.transform = "translateX(" + (index * step() * (doc.dir === "rtl" ? 1 : -1)) + "px)";
        if (counter) { counter.textContent = (index + 1) + " / " + total; }
      }
      root.querySelectorAll("[data-dani-carousel-next]").forEach(function (b) {
        b.addEventListener("click", function () { index += 1; update(); });
      });
      root.querySelectorAll("[data-dani-carousel-prev]").forEach(function (b) {
        b.addEventListener("click", function () { index -= 1; update(); });
      });
      window.addEventListener("resize", update);
      update();
    });
  }

  /* ---------- Before / after ---------- */
  function initBeforeAfter() {
    Array.prototype.forEach.call(doc.querySelectorAll("[data-dani-ba]"), function (root) {
      var after = root.querySelector(".dani-ba__after");
      var handle = root.querySelector(".dani-ba__handle");
      if (!after || !handle) { return; }
      function setFromClientX(clientX) {
        var rect = root.getBoundingClientRect();
        var ratio = ((clientX - rect.left) / rect.width) * 100;
        ratio = Math.max(2, Math.min(98, ratio));
        after.style.clipPath = "inset(0 0 0 " + ratio + "%)";
        handle.style.insetInlineStart = ratio + "%";
      }
      var dragging = false;
      var start = function (e) {
        dragging = true;
        var x = e.touches ? e.touches[0].clientX : e.clientX;
        setFromClientX(x);
      };
      var move = function (e) {
        if (!dragging) { return; }
        var x = e.touches ? e.touches[0].clientX : e.clientX;
        setFromClientX(x);
      };
      var end = function () { dragging = false; };
      root.addEventListener("mousedown", start);
      root.addEventListener("touchstart", start, { passive: true });
      window.addEventListener("mousemove", move);
      window.addEventListener("touchmove", move, { passive: true });
      window.addEventListener("mouseup", end);
      window.addEventListener("touchend", end);
      handle.setAttribute("role", "slider");
      handle.setAttribute("tabindex", "0");
      handle.setAttribute("aria-valuemin", "0");
      handle.setAttribute("aria-valuemax", "100");
      handle.addEventListener("keydown", function (e) {
        var current = parseFloat(handle.style.insetInlineStart) || 50;
        if (e.key === "ArrowLeft") { current -= 4; }
        else if (e.key === "ArrowRight") { current += 4; }
        else { return; }
        e.preventDefault();
        var rect = root.getBoundingClientRect();
        setFromClientX(rect.left + (rect.width * Math.max(2, Math.min(98, current))) / 100);
      });
    });
  }

  /* ---------- Portfolio filtering ---------- */
  function initFilters() {
    Array.prototype.forEach.call(doc.querySelectorAll("[data-dani-filter]"), function (root) {
      var chips = root.querySelectorAll("[data-dani-filter-chip]");
      var items = root.querySelectorAll("[data-dani-filter-item]");
      Array.prototype.forEach.call(chips, function (chip) {
        chip.addEventListener("click", function () {
          var value = chip.getAttribute("data-dani-filter-chip");
          Array.prototype.forEach.call(chips, function (c) { c.classList.toggle("is-active", c === chip); });
          Array.prototype.forEach.call(items, function (item) {
            var match = value === "all" || item.getAttribute("data-dani-filter-item") === value;
            item.hidden = !match;
          });
        });
      });
    });
  }

  /* ---------- Hero video sound ---------- */
  function initHeroSound() {
    Array.prototype.forEach.call(doc.querySelectorAll("[data-dani-sound]"), function (btn) {
      var video = doc.getElementById(btn.getAttribute("data-dani-sound"));
      if (!video) { return; }
      btn.addEventListener("click", function () {
        video.muted = !video.muted;
        btn.setAttribute("data-muted", video.muted ? "true" : "false");
        if (!video.muted) { video.play().catch(function () {}); }
      });
    });
  }

  /* ---------- Lazy hero video source ---------- */
  function initHeroVideo() {
    Array.prototype.forEach.call(doc.querySelectorAll("video[data-dani-src]"), function (video) {
      var load = function () {
        var mobile = window.matchMedia("(max-width: 767px)").matches;
        var src = video.getAttribute(mobile && video.getAttribute("data-dani-src-mobile") ? "data-dani-src-mobile" : "data-dani-src");
        if (src && !video.getAttribute("src")) {
          video.setAttribute("src", src);
          video.play().catch(function () {});
        }
      };
      if ("requestIdleCallback" in window) { window.requestIdleCallback(load); }
      else { setTimeout(load, 300); }
    });
  }

  ready(function () {
    initReveal();
    initHeader();
    initMenu();
    initTheme();
    initFaq();
    initQuotes();
    initCarousels();
    initBeforeAfter();
    initFilters();
    initHeroSound();
    initHeroVideo();
  });
})();
