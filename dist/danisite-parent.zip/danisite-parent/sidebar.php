<?php
/**
 * Sidebar.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_active_sidebar( 'sidebar-blog' ) ) {
	return;
}
?>
<aside class="dani-sidebar" aria-label="<?php esc_attr_e( 'ستون کنار', 'danisite' ); ?>">
	<?php dynamic_sidebar( 'sidebar-blog' ); ?>
</aside>
