<?php
/**
 * Shared page hero for inner pages.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

$dani_title = isset( $args['title'] ) ? $args['title'] : get_the_title();
$dani_text  = isset( $args['text'] ) ? $args['text'] : '';
$dani_eyebrow = isset( $args['eyebrow'] ) ? $args['eyebrow'] : 'DANISITE';
?>
<section class="dani-page-hero">
	<div class="dani-container dani-page-hero__inner">
		<?php dani_breadcrumbs(); ?>
		<p class="dani-eyebrow" style="margin-top:1.25rem"><?php echo esc_html( $dani_eyebrow ); ?></p>
		<h1 class="dani-page-hero__title"><?php echo esc_html( $dani_title ); ?></h1>
		<?php if ( $dani_text ) : ?>
			<p class="dani-page-hero__text"><?php echo esc_html( $dani_text ); ?></p>
		<?php endif; ?>
	</div>
</section>
