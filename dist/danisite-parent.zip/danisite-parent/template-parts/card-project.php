<?php
/**
 * Portfolio project card.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

$dani_cat   = '';
$dani_terms = get_the_terms( get_the_ID(), 'dani_project_cat' );
if ( ! empty( $dani_terms ) && ! is_wp_error( $dani_terms ) ) {
	$dani_cat = $dani_terms[0]->name;
}
$dani_client = dani_meta( get_the_ID(), 'project_client' );
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'dani-project' ); ?>>
	<a class="dani-project__link" href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( get_the_title() ); ?>">
		<div class="dani-project__media dani-project__aspect-4-3">
			<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'dani-card', array( 'loading' => 'lazy', 'decoding' => 'async' ) ); ?>
			<?php else : ?>
				<span class="dani-post__media--empty" aria-hidden="true"><?php echo dani_icon( 'image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<?php endif; ?>
			<span class="dani-glass dani-project__badge"><?php echo esc_html( $dani_cat ? $dani_cat : 'نمونه نمایشی' ); ?></span>
			<span class="dani-project__go" aria-hidden="true"><?php echo dani_icon( 'arrow-up-left' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
		</div>
		<div class="dani-project__foot">
			<div>
				<h3 class="dani-project__title"><?php the_title(); ?></h3>
				<p class="dani-project__desc"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( get_the_excerpt() ), 16 ) ); ?></p>
			</div>
			<?php if ( $dani_client ) : ?>
				<span class="dani-project__cat"><?php echo esc_html( $dani_client ); ?></span>
			<?php endif; ?>
		</div>
	</a>
</article>
