<?php
/**
 * Shared final call-to-action block.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="dani-section dani-cta-wrap" id="contact">
	<div class="dani-cta">
		<div class="dani-cta__blob dani-cta__blob--1" aria-hidden="true"></div>
		<div class="dani-cta__blob dani-cta__blob--2" aria-hidden="true"></div>
		<div class="dani-glass dani-cta__inner">
			<h2 class="dani-cta__title"><?php esc_html_e( 'شاید این، شروع یک همکاری متفاوت باشد.', 'danisite' ); ?></h2>
			<p class="dani-cta__text"><?php esc_html_e( 'ایده‌تان را با ما در میان بگذارید. برای ساختن تجربه دیجیتال بعدی آماده‌ایم.', 'danisite' ); ?></p>
			<div class="dani-cta__actions">
				<a class="dani-btn dani-btn--primary dani-btn--lg" href="mailto:<?php echo esc_attr( antispambot( dani_option( 'email' ) ) ); ?>"><?php esc_html_e( 'شروع یک پروژه جدید', 'danisite' ); ?></a>
				<a class="dani-btn dani-btn--ghost dani-btn--lg" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'تماس با ما', 'danisite' ); ?></a>
			</div>
		</div>
	</div>
</section>
