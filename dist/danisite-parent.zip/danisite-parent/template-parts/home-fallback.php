<?php
/**
 * Minimal homepage used only when neither the demo importer nor a static front
 * page exists yet. The full designed homepage is provided by DaniSite Core.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="dani-hero">
	<div class="dani-hero__bg" aria-hidden="true"></div>
	<div class="dani-hero__content">
		<p class="dani-eyebrow dani-hero__eyebrow"><?php echo esc_html( dani_option( 'hero_eyebrow' ) ); ?></p>
		<h1 class="dani-hero__title">
			<?php esc_html_e( 'معمولی دیده نشوید.', 'danisite' ); ?><br>
			<span class="dani-gradient-text"><?php esc_html_e( 'متفاوت به یاد بمانید.', 'danisite' ); ?></span>
		</h1>
		<p class="dani-hero__text"><?php esc_html_e( 'هر همکاری، فرصتی برای ساختن یک تجربه متفاوت است. ما با ترکیب خلاقیت، طراحی و تکنولوژی، تصویری ماندگار از برند شما در دنیای دیجیتال می‌سازیم.', 'danisite' ); ?></p>
		<div class="dani-hero__actions">
			<a class="dani-btn dani-btn--primary dani-btn--lg" href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>"><?php esc_html_e( 'مشاهده نمونه‌کارها', 'danisite' ); ?></a>
			<a class="dani-btn dani-btn--glass dani-btn--lg" href="<?php echo esc_url( dani_option( 'cta_url' ) ); ?>"><?php esc_html_e( 'شروع همکاری', 'danisite' ); ?></a>
		</div>
	</div>
</section>

<section class="dani-section">
	<div class="dani-container">
		<?php dani_section_head( array(
			'eyebrow' => 'JOURNAL',
			'title'   => 'تازه‌ترین نوشته‌ها',
			'text'    => 'محتوایی برای کسب‌وکارهایی که می‌خواهند در فضای دیجیتال متمایز دیده شوند.',
		) ); ?>
		<div class="dani-posts dani-posts--3" style="margin-top:3rem">
			<?php
			$dani_latest = new WP_Query( array(
				'post_type'           => 'post',
				'posts_per_page'      => 3,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			) );
			while ( $dani_latest->have_posts() ) :
				$dani_latest->the_post();
				get_template_part( 'template-parts/card-post' );
			endwhile;
			wp_reset_postdata();
			?>
		</div>
	</div>
</section>

<?php get_template_part( 'template-parts/cta' ); ?>
