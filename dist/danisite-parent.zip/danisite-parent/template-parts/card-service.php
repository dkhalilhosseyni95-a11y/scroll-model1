<?php
/**
 * Service card.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

$dani_icon  = dani_meta( get_the_ID(), 'service_icon', 'sparkles' );
$dani_price = dani_meta( get_the_ID(), 'service_price' );
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'dani-card' ); ?>>
	<span class="dani-card__icon" aria-hidden="true"><?php echo dani_icon( $dani_icon ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
	<h3 class="dani-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
	<p class="dani-card__text"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( get_the_excerpt() ), 22 ) ); ?></p>
	<?php if ( $dani_price ) : ?>
		<p class="dani-card__price"><?php echo esc_html( $dani_price ); ?></p>
	<?php endif; ?>
	<a class="dani-card__link" href="<?php the_permalink(); ?>">
		<?php esc_html_e( 'جزئیات خدمت', 'danisite' ); ?>
		<?php echo dani_icon( 'arrow-left' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</a>
</article>
