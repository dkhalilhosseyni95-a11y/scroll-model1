<?php
/**
 * Blog post card.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'dani-post' ); ?>>
	<a class="dani-post__media<?php echo has_post_thumbnail() ? '' : ' dani-post__media--empty'; ?>" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
		<?php dani_thumbnail( 'dani-card' ); ?>
	</a>
	<div class="dani-post__body">
		<?php dani_post_meta(); ?>
		<h3 class="dani-post__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<p class="dani-post__excerpt"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
		<a class="dani-post__more" href="<?php the_permalink(); ?>">
			<?php esc_html_e( 'ادامه مطلب', 'danisite' ); ?>
			<?php echo dani_icon( 'arrow-left' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</a>
	</div>
</article>
