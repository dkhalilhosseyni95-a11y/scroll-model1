<?php
/**
 * Site header: fixed glass navigation shared by every template.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;
?>
<header class="dani-header">
	<nav class="dani-nav" aria-label="<?php esc_attr_e( 'منوی اصلی', 'danisite' ); ?>">
		<?php dani_logo(); ?>

		<?php
		if ( has_nav_menu( 'primary' ) ) {
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'depth'          => 2,
				'menu_class'     => 'dani-nav__list',
			) );
		} else {
			dani_nav_fallback( array( 'theme_location' => 'primary' ) );
		}
		?>

		<div class="dani-nav__actions">
			<button type="button" class="dani-theme-toggle" data-dani-theme aria-label="<?php esc_attr_e( 'تغییر حالت روشن و تیره', 'danisite' ); ?>" aria-pressed="false">
				<?php echo dani_icon( 'moon', array( 'class' => 'dani-icon-moon' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php echo dani_icon( 'sun', array( 'class' => 'dani-icon-sun' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</button>

			<a class="dani-btn dani-btn--primary dani-nav__cta" href="<?php echo esc_url( dani_option( 'cta_url' ) ); ?>"><?php echo esc_html( dani_option( 'cta_label' ) ); ?></a>

			<button type="button" class="dani-nav__toggle" data-dani-menu-toggle aria-expanded="false" aria-controls="dani-mobile-menu" aria-label="<?php esc_attr_e( 'منو', 'danisite' ); ?>">
				<?php echo dani_icon( 'menu' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</button>
		</div>
	</nav>

	<div class="dani-mobile-menu" id="dani-mobile-menu" data-dani-menu>
		<ul>
			<?php
			$mobile_items = array();
			if ( has_nav_menu( 'primary' ) ) {
				$locations = get_nav_menu_locations();
				$menu_id   = isset( $locations['primary'] ) ? $locations['primary'] : 0;
				$items     = $menu_id ? wp_get_nav_menu_items( $menu_id ) : array();
				foreach ( (array) $items as $item ) {
					if ( (int) $item->menu_item_parent !== 0 ) {
						continue;
					}
					$mobile_items[] = array( 'label' => $item->title, 'url' => $item->url );
				}
			}
			if ( empty( $mobile_items ) ) {
				$mobile_items = dani_default_menu_items();
			}
			$index = 0;
			foreach ( $mobile_items as $item ) :
				$index++;
				?>
				<li class="dani-mobile-menu__item">
					<a class="dani-mobile-menu__link" href="<?php echo esc_url( $item['url'] ); ?>">
						<span><?php echo esc_html( $item['label'] ); ?></span>
						<span class="dani-mobile-menu__index"><?php echo esc_html( dani_fa_number( str_pad( (string) $index, 2, '0', STR_PAD_LEFT ) ) ); ?></span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
		<a class="dani-btn dani-btn--primary dani-btn--lg" href="<?php echo esc_url( dani_option( 'cta_url' ) ); ?>"><?php echo esc_html( dani_option( 'cta_label' ) ); ?></a>
	</div>
</header>
