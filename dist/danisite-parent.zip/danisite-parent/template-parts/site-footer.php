<?php
/**
 * Site footer.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;
?>
<footer class="dani-footer">
	<div class="dani-container dani-footer__grid">
		<div class="dani-footer__brand">
			<?php dani_logo(); ?>
			<p class="dani-footer__about"><?php echo esc_html( dani_option( 'brand_desc' ) ); ?></p>
			<div class="dani-footer__socials">
				<?php foreach ( dani_get_socials() as $social ) : ?>
					<a class="dani-social" href="<?php echo esc_url( $social['url'] ); ?>" target="_blank" rel="noopener noreferrer">
						<?php echo dani_icon( $social['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php echo esc_html( $social['label'] ); ?></span>
					</a>
				<?php endforeach; ?>
			</div>
		</div>

		<nav class="dani-footer__col--links" aria-label="<?php esc_attr_e( 'پیوندها', 'danisite' ); ?>">
			<p class="dani-footer__title"><?php esc_html_e( 'پیوندها', 'danisite' ); ?></p>
			<?php
			if ( has_nav_menu( 'footer' ) ) {
				wp_nav_menu( array(
					'theme_location' => 'footer',
					'container'      => false,
					'depth'          => 1,
					'menu_class'     => 'dani-footer__links',
				) );
			} else {
				echo '<ul class="dani-footer__links">';
				foreach ( dani_default_menu_items() as $item ) {
					echo '<li><a href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['label'] ) . '</a></li>';
				}
				echo '</ul>';
			}
			?>
		</nav>

		<div class="dani-footer__col--services">
			<p class="dani-footer__title"><?php esc_html_e( 'خدمات', 'danisite' ); ?></p>
			<ul class="dani-footer__links">
				<?php foreach ( dani_footer_services() as $service ) : ?>
					<li><a href="<?php echo esc_url( $service['url'] ); ?>"><?php echo esc_html( $service['title'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>

		<div class="dani-footer__col--contact">
			<p class="dani-footer__title"><?php esc_html_e( 'تماس', 'danisite' ); ?></p>
			<ul class="dani-footer__links">
				<li><a href="mailto:<?php echo esc_attr( antispambot( dani_option( 'email' ) ) ); ?>" dir="ltr"><?php echo esc_html( antispambot( dani_option( 'email' ) ) ); ?></a></li>
				<li><a href="tel:<?php echo esc_attr( dani_option( 'phone_link' ) ); ?>" dir="ltr"><?php echo esc_html( dani_option( 'phone' ) ); ?></a></li>
				<li><?php echo esc_html( dani_option( 'address' ) ); ?></li>
				<li><?php echo esc_html( dani_option( 'hours' ) ); ?></li>
			</ul>
		</div>
	</div>

	<div class="dani-footer__bottom">
		<p><?php echo esc_html( dani_option( 'footer_note' ) ); ?></p>
		<?php
		if ( has_nav_menu( 'legal' ) ) {
			wp_nav_menu( array(
				'theme_location' => 'legal',
				'container'      => false,
				'depth'          => 1,
				'menu_class'     => 'dani-footer__legal',
			) );
		}
		?>
		<p><?php echo esc_html( dani_option( 'copyright' ) ); ?></p>
	</div>
</footer>
