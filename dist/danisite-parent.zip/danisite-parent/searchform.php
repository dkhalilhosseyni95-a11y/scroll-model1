<?php
/**
 * Search form.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

$dani_id = 'dani-search-' . wp_unique_id();
?>
<form role="search" method="get" class="dani-search__form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $dani_id ); ?>"><?php esc_html_e( 'جست‌وجو در سایت', 'danisite' ); ?></label>
	<input type="search" id="<?php echo esc_attr( $dani_id ); ?>" class="dani-input" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'جست‌وجو در سایت…', 'danisite' ); ?>" required>
	<button type="submit" class="dani-btn dani-btn--primary">
		<?php echo dani_icon( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<span><?php esc_html_e( 'جست‌وجو', 'danisite' ); ?></span>
	</button>
</form>
