<?php
/**
 * Archives for posts and the DaniSite custom post types.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

get_header();

$dani_type = get_post_type() ? get_post_type() : 'post';
?>
<section class="dani-page-hero">
	<div class="dani-container dani-page-hero__inner">
		<?php dani_breadcrumbs(); ?>
		<p class="dani-eyebrow" style="margin-top:1.25rem"><?php echo esc_html( is_tax() || is_category() || is_tag() ? 'ARCHIVE' : 'DANISITE' ); ?></p>
		<h1 class="dani-page-hero__title"><?php echo esc_html( dani_archive_title() ); ?></h1>
		<p class="dani-page-hero__text"><?php echo esc_html( dani_archive_description() ); ?></p>
	</div>
</section>

<section class="dani-section">
	<div class="dani-container">
		<?php if ( have_posts() ) : ?>
			<?php if ( 'dani_project' === $dani_type ) : ?>
				<div class="dani-work__grid dani-work__grid--archive">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/card-project' );
					endwhile;
					?>
				</div>
			<?php elseif ( 'dani_service' === $dani_type ) : ?>
				<div class="dani-cards dani-cards--3">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/card-service' );
					endwhile;
					?>
				</div>
			<?php else : ?>
				<div class="dani-posts dani-posts--3">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/card-post' );
					endwhile;
					?>
				</div>
			<?php endif; ?>

			<?php dani_pagination(); ?>
		<?php else : ?>
			<div class="dani-notice"><?php esc_html_e( 'موردی برای نمایش وجود ندارد.', 'danisite' ); ?></div>
		<?php endif; ?>
	</div>
</section>
<?php
get_footer();
