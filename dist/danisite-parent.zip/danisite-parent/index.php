<?php
/**
 * Blog index — used for the posts page and the fallback archives.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<section class="dani-page-hero">
	<div class="dani-container dani-page-hero__inner">
		<?php dani_breadcrumbs(); ?>
		<p class="dani-eyebrow" style="margin-top:1.25rem">JOURNAL</p>
		<h1 class="dani-page-hero__title"><?php echo esc_html( is_home() && ! is_front_page() && get_option( 'page_for_posts' ) ? get_the_title( get_option( 'page_for_posts' ) ) : 'وبلاگ' ); ?></h1>
		<p class="dani-page-hero__text"><?php esc_html_e( 'یادداشت‌ها، تحلیل‌ها و تجربه‌های تیم دنی سایت در طراحی، توسعه و رشد دیجیتال.', 'danisite' ); ?></p>
	</div>
</section>

<section class="dani-section">
	<div class="dani-container">
		<?php if ( have_posts() ) : ?>
			<div class="dani-posts dani-posts--3">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/card-post' );
				endwhile;
				?>
			</div>
			<?php dani_pagination(); ?>
		<?php else : ?>
			<div class="dani-notice"><?php esc_html_e( 'هنوز نوشته‌ای منتشر نشده است.', 'danisite' ); ?></div>
		<?php endif; ?>
	</div>
</section>
<?php
get_footer();
