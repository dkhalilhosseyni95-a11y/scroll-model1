<?php
/**
 * Comments template.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

if ( post_password_required() ) {
	return;
}
?>
<div id="comments" class="dani-comments" style="margin-top:2rem">
	<?php if ( have_comments() ) : ?>
		<h2 class="dani-head__title" style="font-size:1.5rem">
			<?php
			printf(
				/* translators: %s: comment count */
				esc_html__( '%s دیدگاه', 'danisite' ),
				esc_html( dani_fa_number( get_comments_number() ) )
			);
			?>
		</h2>
		<ol class="dani-comment-list" style="margin-top:1.5rem;display:grid;gap:1.25rem">
			<?php
			wp_list_comments( array(
				'style'       => 'ol',
				'short_ping'  => true,
				'avatar_size' => 48,
			) );
			?>
		</ol>
		<?php the_comments_pagination( array( 'class' => 'dani-pagination' ) ); ?>
	<?php endif; ?>

	<?php
	comment_form( array(
		'class_form'         => 'dani-form',
		'title_reply_before' => '<h2 class="dani-head__title" style="font-size:1.25rem">',
		'title_reply_after'  => '</h2>',
		'class_submit'       => 'dani-btn dani-btn--primary',
		'comment_field'      => '<p class="dani-field"><label class="dani-field__label" for="comment">' . esc_html__( 'دیدگاه', 'danisite' ) . ' <span>*</span></label><textarea id="comment" class="dani-textarea" name="comment" required></textarea></p>',
	) );
	?>
</div>
