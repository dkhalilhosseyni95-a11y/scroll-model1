<?php
/**
 * Document head and header.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#content"><?php esc_html_e( 'پرش به محتوا', 'danisite' ); ?></a>
<div id="page" class="dani-site">
	<?php get_template_part( 'template-parts/site-header' ); ?>
	<main id="content" class="dani-main">
