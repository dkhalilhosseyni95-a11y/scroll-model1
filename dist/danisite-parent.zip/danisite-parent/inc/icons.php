<?php
/**
 * Inline SVG icon system.
 *
 * A single hidden sprite is printed once in the footer and every icon is a
 * <use> reference, so icons cost no extra requests and no icon font.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

/**
 * Return the paths for a named icon.
 *
 * @param string $name Icon key.
 * @return string
 */
function dani_icon_path( $name ) {
	$icons = array(
		'arrow-left'     => '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
		'arrow-right'    => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
		'arrow-up-left'  => '<path d="M7 17 17 7"/><path d="M7 7h10v10"/>',
		'chevron-left'   => '<path d="m15 18-6-6 6-6"/>',
		'chevron-right'  => '<path d="m9 18 6-6-6-6"/>',
		'plus'           => '<path d="M12 5v14"/><path d="M5 12h14"/>',
		'menu'           => '<path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h16"/>',
		'x'              => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
		'moon'           => '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
		'sun'            => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
		'mail'           => '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
		'phone'          => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
		'map-pin'        => '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
		'instagram'      => '<rect width="20" height="20" x="2" y="2" rx="5"/><circle cx="12" cy="12" r="4"/><path d="M17.5 6.5h.01"/>',
		'linkedin'       => '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/>',
		'telegram'       => '<path d="m22 3-9.5 18-2.4-7.1L3 11.5 22 3Z"/><path d="M10.1 13.9 20 5"/>',
		'whatsapp'       => '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
		'x-social'       => '<path d="M4 4l7.5 9.5L4.5 20"/><path d="M20 4l-7.5 9.5L19.5 20"/>',
		'search'         => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
		'check'          => '<path d="M20 6 9 17l-5-5"/>',
		'play'           => '<path d="M7 4.5v15l12-7.5-12-7.5Z"/>',
		'volume-x'       => '<path d="M11 5 6.5 8.6H3v6.8h3.5L11 19V5Z"/><path d="m22 9-6 6"/><path d="m16 9 6 6"/>',
		'volume-2'       => '<path d="M11 5 6.5 8.6H3v6.8h3.5L11 19V5Z"/><path d="M16 9a5 5 0 0 1 0 6"/><path d="M19.4 5.6a9 9 0 0 1 0 12.8"/>',
		'calendar'       => '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
		'clock'          => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
		'layers'         => '<path d="m12 2 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5"/><path d="m3 17 9 5 9-5"/>',
		'sparkles'       => '<path d="m12 3 1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z"/><path d="M5 17.5 5.8 19.2 7.5 20l-1.7.8L5 22.5l-.8-1.7L2.5 20l1.7-.8Z"/>',
		'code'           => '<path d="m16 18 6-6-6-6"/><path d="m8 6-6 6 6 6"/>',
		'gauge'          => '<path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/>',
		'shield'         => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>',
		'palette'        => '<circle cx="13.5" cy="6.5" r=".5"/><circle cx="17.5" cy="10.5" r=".5"/><circle cx="8.5" cy="7.5" r=".5"/><circle cx="6.5" cy="12.5" r=".5"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.6-.7 1.6-1.7 0-.4-.2-.8-.4-1.1-.3-.3-.4-.6-.4-1.1a1.6 1.6 0 0 1 1.6-1.7h2c3 0 5.6-2.5 5.6-5.5C22 6 17.5 2 12 2Z"/>',
		'trending-up'    => '<path d="M16 7h6v6"/><path d="m22 7-8.5 8.5-5-5L2 17"/>',
		'message'        => '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
		'user'           => '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
		'star'           => '<path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2Z"/>',
		'external'       => '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
		'image'          => '<rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/>',
		'bag'            => '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>',
		'globe'          => '<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10Z"/>',
		'monitor'        => '<rect width="20" height="14" x="2" y="3" rx="2"/><path d="M8 21h8"/><path d="M12 17v4"/>',
		'rocket'         => '<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09Z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2Z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>',
		'sliders'        => '<path d="M4 21v-7"/><path d="M4 10V3"/><path d="M12 21v-9"/><path d="M12 8V3"/><path d="M20 21v-5"/><path d="M20 12V3"/><path d="M1 14h6"/><path d="M9 8h6"/><path d="M17 16h6"/>',
		'quote'          => '<path d="M9 7H5a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h2v2a2 2 0 0 1-2 2"/><path d="M20 7h-4a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h2v2a2 2 0 0 1-2 2"/>',
	);

	$path = isset( $icons[ $name ] ) ? $icons[ $name ] : $icons['sparkles'];

	return $path;
}

/**
 * Build an inline icon.
 *
 * @param string $name  Icon key.
 * @param array  $args  Optional. class, size (int), echo (bool).
 * @return string
 */
function dani_icon( $name, $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'class' => '',
			'size'  => 24,
		)
	);

	$class = trim( 'dani-i dani-i--' . sanitize_html_class( $name ) . ' ' . $args['class'] );
	$size  = max( 8, (int) $args['size'] );

	$svg = sprintf(
		'<svg class="%1$s" width="%2$d" height="%2$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="#dani-i-%3$s"></use></svg>',
		esc_attr( $class ),
		$size,
		esc_attr( $name )
	);

	return $svg;
}

/**
 * Print a single symbol so <use> works without a sprite file.
 *
 * @param string $name Icon key.
 * @return void
 */
function dani_icon_symbol( $name ) {
	printf(
		'<symbol id="dani-i-%1$s" viewBox="0 0 24 24">%2$s</symbol>',
		esc_attr( $name ),
		dani_icon_path( $name ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG markup.
	);
}

/**
 * Output the hidden sprite once per page.
 *
 * @return void
 */
function dani_print_icon_sprite() {
	static $printed = false;
	if ( $printed || is_admin() ) {
		return;
	}
	$printed = true;
	$names   = array(
		'arrow-left', 'arrow-right', 'arrow-up-left', 'chevron-left', 'chevron-right', 'plus', 'menu', 'x',
		'moon', 'sun', 'mail', 'phone', 'map-pin', 'instagram', 'linkedin', 'telegram', 'whatsapp', 'x-social',
		'search', 'check', 'play', 'volume-x', 'volume-2', 'calendar', 'clock', 'layers', 'sparkles', 'code',
		'gauge', 'shield', 'palette', 'trending-up', 'message', 'user', 'star', 'external', 'image', 'bag',
		'globe', 'monitor', 'rocket', 'sliders', 'quote',
	);
	echo '<svg xmlns="http://www.w3.org/2000/svg" style="position:absolute;width:0;height:0;overflow:hidden" aria-hidden="true" focusable="false">';
	foreach ( $names as $name ) {
		dani_icon_symbol( $name );
	}
	echo '</svg>';
}
add_action( 'wp_footer', 'dani_print_icon_sprite', 5 );
