<?php
/**
 * Front-end assets.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

/**
 * Enqueue styles, script and the tiny pre-paint bootstrap.
 *
 * @return void
 */
function dani_enqueue_assets() {
	$uri = get_template_directory_uri();

	wp_enqueue_style( 'dani-base', $uri . '/assets/css/dani-base.css', array(), DANI_VERSION );
	wp_enqueue_style( 'dani-components', $uri . '/assets/css/dani-components.css', array( 'dani-base' ), DANI_VERSION );

	wp_enqueue_script( 'dani-front', $uri . '/assets/js/dani.js', array(), DANI_VERSION, true );
	wp_script_add_data( 'dani-front', 'strategy', 'defer' );
}
add_action( 'wp_enqueue_scripts', 'dani_enqueue_assets' );

/**
 * Preload the variable font so text paints with the real typeface.
 *
 * @return void
 */
function dani_preload_font() {
	printf(
		'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
		esc_url( get_template_directory_uri() . '/assets/fonts/Vazirmatn-var.woff2' )
	);
}
add_action( 'wp_head', 'dani_preload_font', 2 );

/**
 * Marks the document as JS capable and restores the saved colour scheme before paint.
 *
 * @return void
 */
function dani_head_bootstrap() {
	?>
	<script>
	(function(){try{var d=document.documentElement;d.classList.add('dani-js');var s=localStorage.getItem('danisite-theme');if(s==='dark'){d.classList.add('dark');}}catch(e){}})();
	</script>
	<?php
}
add_action( 'wp_head', 'dani_head_bootstrap', 1 );

/**
 * Keep the admin bar from covering the fixed header.
 *
 * @return void
 */
function dani_admin_bar_css() {
	if ( ! is_admin_bar_showing() ) {
		return;
	}
	echo '<style id="dani-adminbar">.dani-header{top:32px}@media screen and (max-width:782px){.dani-header{top:46px}}</style>';
}
add_action( 'wp_head', 'dani_admin_bar_css', 20 );

/**
 * Small performance and hygiene tweaks that never change visible behaviour.
 *
 * @return void
 */
function dani_performance_tweaks() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10 );
}
add_action( 'init', 'dani_performance_tweaks' );

/**
 * Drop the heavy block stylesheet on pages that contain no core blocks.
 *
 * Elementor pages render their own markup, so `wp-block-library` only adds
 * weight there. Classic content keeps it.
 *
 * @return void
 */
function dani_conditionally_dequeue_block_styles() {
	if ( is_admin() ) {
		return;
	}

	$post_id = get_queried_object_id();
	$keep    = true;

	if ( $post_id && dani_is_built_with_elementor( $post_id ) ) {
		$keep = false;
	}

	if ( ! $keep ) {
		wp_dequeue_style( 'wp-block-library' );
		wp_dequeue_style( 'wp-block-library-theme' );
		wp_dequeue_style( 'classic-theme-styles' );
	}
}
add_action( 'wp_enqueue_scripts', 'dani_conditionally_dequeue_block_styles', 100 );

/**
 * Add a `defer`-friendly filter for the WordPress embed script.
 *
 * @return void
 */
function dani_dequeue_wp_embed() {
	wp_deregister_script( 'wp-embed' );
}
add_action( 'wp_footer', 'dani_dequeue_wp_embed' );
