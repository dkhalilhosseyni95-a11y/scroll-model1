<?php
/**
 * Elementor integration for the theme.
 *
 * Only loaded when Elementor is active (see functions.php). Keeps the theme
 * compatible with Elementor's theme locations without requiring Elementor Pro.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the theme's Elementor locations.
 *
 * @param object $elementor_theme_manager Elementor theme manager.
 * @return void
 */
function dani_register_elementor_theme_locations( $elementor_theme_manager ) {
	$elementor_theme_manager->register_all_core_location();
}
add_action( 'elementor/theme/register_locations', 'dani_register_elementor_theme_locations' );

/**
 * Use the theme's canvas for Elementor full-width templates.
 *
 * @return void
 */
function dani_elementor_body_class( $classes ) {
	if ( is_singular() && dani_is_built_with_elementor( get_the_ID() ) ) {
		$classes[] = 'dani-built-with-elementor';
	}

	return $classes;
}
add_filter( 'body_class', 'dani_elementor_body_class' );

/**
 * Keep Elementor's default section spacing out of the way; our widgets own the
 * rhythm, which keeps pages pixel-identical to the Lovable design.
 *
 * @return void
 */
function dani_elementor_layout_css() {
	wp_add_inline_style(
		'dani-components',
		'.dani-elementor-content .elementor-section,.dani-elementor-content .elementor-top-section{padding-top:0;padding-bottom:0}'
		. '.dani-elementor-content .elementor-column-gap-default>.elementor-column>.elementor-element-populated{padding:0}'
		. '.dani-elementor-content .elementor-widget-container>section:first-child{margin-top:0}'
	);
}
add_action( 'wp_enqueue_scripts', 'dani_elementor_layout_css', 20 );
