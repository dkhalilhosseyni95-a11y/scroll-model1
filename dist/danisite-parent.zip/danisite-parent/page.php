<?php
/**
 * Single page.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
	the_post();

	if ( dani_is_built_with_elementor( get_the_ID() ) ) {
		echo '<div class="dani-elementor-content">';
		the_content();
		echo '</div>';
	} else {
		get_template_part( 'template-parts/page-header', null, array(
			'title'   => get_the_title(),
			'text'    => has_excerpt() ? get_the_excerpt() : '',
			'eyebrow' => 'DANISITE',
		) );
		?>
		<section class="dani-section">
			<div class="dani-container">
				<div class="dani-article">
					<div class="dani-prose">
						<?php the_content(); ?>
					</div>
					<?php
					wp_link_pages( array(
						'before' => '<nav class="dani-pagination">',
						'after'  => '</nav>',
					) );
					?>
				</div>
			</div>
		</section>
		<?php
	}

	if ( comments_open() || get_comments_number() ) {
		echo '<section class="dani-section dani-section--tight dani-section--surface"><div class="dani-container"><div class="dani-article">';
		comments_template();
		echo '</div></div></section>';
	}
endwhile;

get_footer();
