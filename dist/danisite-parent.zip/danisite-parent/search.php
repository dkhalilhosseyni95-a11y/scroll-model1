<?php
/**
 * Search results.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<section class="dani-page-hero">
	<div class="dani-container dani-page-hero__inner">
		<?php dani_breadcrumbs(); ?>
		<p class="dani-eyebrow" style="margin-top:1.25rem">SEARCH</p>
		<h1 class="dani-page-hero__title"><?php esc_html_e( 'جست‌وجو', 'danisite' ); ?></h1>
	</div>
</section>

<section class="dani-section">
	<div class="dani-container">
		<div class="dani-search">
			<?php get_search_form(); ?>

			<p class="dani-search__info">
				<?php
				if ( have_posts() ) {
					printf(
						/* translators: 1: result count, 2: query */
						esc_html__( '%1$s نتیجه برای «%2$s»', 'danisite' ),
						esc_html( dani_fa_number( (int) $GLOBALS['wp_query']->found_posts ) ),
						esc_html( get_search_query() )
					);
				} else {
					printf(
						/* translators: %s: query */
						esc_html__( 'نتیجه‌ای برای «%s» پیدا نشد. عبارت دیگری را امتحان کنید.', 'danisite' ),
						esc_html( get_search_query() )
					);
				}
				?>
			</p>

			<?php if ( have_posts() ) : ?>
				<div class="dani-search__results">
					<?php
					while ( have_posts() ) :
						the_post();
						$dani_pt = get_post_type_object( get_post_type() );
						?>
						<article class="dani-search__result">
							<p class="dani-search__result-type"><?php echo esc_html( $dani_pt ? $dani_pt->labels->singular_name : 'نوشته' ); ?></p>
							<h2 class="dani-search__result-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
							<p class="dani-search__result-excerpt"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( get_the_excerpt() ), 30 ) ); ?></p>
						</article>
					<?php endwhile; ?>
				</div>
				<?php dani_pagination(); ?>
			<?php endif; ?>
		</div>
	</div>
</section>
<?php
get_footer();
