<?php
/**
 * 404 — page not found.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<section class="dani-404">
	<div>
		<p class="dani-404__code dani-gradient-text">۴۰۴</p>
		<h1 class="dani-404__title"><?php esc_html_e( 'این صفحه پیدا نشد.', 'danisite' ); ?></h1>
		<p class="dani-404__text"><?php esc_html_e( 'ممکن است نشانی تغییر کرده باشد یا صفحه حذف شده باشد. از این‌جا ادامه دهید:', 'danisite' ); ?></p>
		<div class="dani-404__actions">
			<a class="dani-btn dani-btn--primary dani-btn--lg" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'بازگشت به خانه', 'danisite' ); ?></a>
			<a class="dani-btn dani-btn--ghost dani-btn--lg" href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>"><?php esc_html_e( 'نمونه‌کارها', 'danisite' ); ?></a>
		</div>
		<div class="dani-search" style="margin-top:3rem">
			<?php get_search_form(); ?>
		</div>
	</div>
</section>
<?php
get_footer();
