<?php
/**
 * DaniSite theme bootstrap.
 *
 * @package DaniSite
 */

defined( 'ABSPATH' ) || exit;

require_once get_template_directory() . '/inc/setup.php';
require_once get_template_directory() . '/inc/icons.php';
require_once get_template_directory() . '/inc/assets.php';
require_once get_template_directory() . '/inc/template-tags.php';

/**
 * Load the theme's Elementor integration when Elementor is active.
 *
 * @return void
 */
function dani_load_integrations() {
	if ( did_action( 'elementor/loaded' ) ) {
		require_once get_template_directory() . '/inc/elementor.php';
	}
}
add_action( 'init', 'dani_load_integrations', 20 );

/**
 * Content width for oEmbeds.
 *
 * @return void
 */
function dani_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'dani_content_width', 1120 );
}
add_action( 'after_setup_theme', 'dani_content_width', 0 );
