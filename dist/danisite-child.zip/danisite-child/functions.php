<?php
/**
 * DaniSite Child theme bootstrap.
 *
 * The child theme only loads its own stylesheet; everything else is inherited
 * from the parent theme so there is a single source of truth for the design.
 *
 * @package DaniSite_Child
 */

defined( 'ABSPATH' ) || exit;

/**
 * Enqueue the child stylesheet after the parent theme.
 *
 * @return void
 */
function danisite_child_styles() {
	wp_enqueue_style(
		'danisite-child',
		get_stylesheet_directory_uri() . '/style.css',
		array( 'dani-components' ),
		wp_get_theme()->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'danisite_child_styles', 20 );

/**
 * Child theme text domain.
 *
 * @return void
 */
function danisite_child_setup() {
	load_child_theme_textdomain( 'danisite-child', get_stylesheet_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'danisite_child_setup' );

/**
 * Example of a safe override: template parts can be replaced by copying them
 * into this child theme (get_stylesheet_directory() wins over the parent).
 *
 * Filter example — change the reading time label without touching the parent:
 *
 * add_filter( 'dani_reading_time_label', function () { return 'دقیقه'; } );
 */
